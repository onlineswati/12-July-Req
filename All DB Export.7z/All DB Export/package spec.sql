--------------------------------------------------------
--  File created - Wednesday-July-12-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package PKG_BULK_SUPPRESSION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_BULK_SUPPRESSION" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

   PROCEDURE HM_BULK_SUPPRESSION ( PN_BATCH_ID        IN  NUMBER,
                                   PV_MATCH_RULE_CODE  IN VARCHAR2,
                                   PV_MATCH_RULE_TYPE  IN VARCHAR2,
                                   PV_REMARK           IN VARCHAR2,
                                   PV_ACTION           IN VARCHAR2,
                                   PV_USER_ID           IN VARCHAR2,
                                   PN_COUNT OUT NUMBER
                             );
                              
END PKG_BULK_SUPPRESSION; 

/
--------------------------------------------------------
--  DDL for Package PKG_BULK_SUPPRESSION_PR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_BULK_SUPPRESSION_PR" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

   PROCEDURE HM_BULK_SUPPRESSION ( PN_BATCH_ID        IN  NUMBER,
                                   PV_MATCH_RULE_CODE  IN VARCHAR2,
                                   PV_MATCH_RULE_TYPE  IN VARCHAR2,
                                   PV_REMARK           IN VARCHAR2,
                                   PV_ACTION           IN VARCHAR2,
                                   PV_USER_ID           IN VARCHAR2,
                                   PN_COUNT OUT NUMBER
                             );
                              
END PKG_BULK_SUPPRESSION_PR;

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_BULK_SUPPRESSION_PR FOR HMCORE.PKG_BULK_SUPPRESSION_PR;
GRANT EXECUTE ON HMCORE.PKG_BULK_SUPPRESSION_PR TO RL_INQ_MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PKG_COMM_INQ_SUMMARY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COMM_INQ_SUMMARY" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
   PROCEDURE HM_COMM_INQ_SUMMARY_FOR_REVIEW (BATCH_ID   IN    NUMBER,
                              CUR_HM_COMM_SUMMARY     OUT ref_cursor,
                               CUR_COMM_IND_SUMMARY     OUT ref_cursor,
                            CUR_COMM_ORG_SUMMARY     OUT ref_cursor
                              );
                             
END PKG_COMM_INQ_SUMMARY; 

/
--------------------------------------------------------
--  DDL for Package PKG_COMM_INQ_SUMMARY_PR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COMM_INQ_SUMMARY_PR" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
   PROCEDURE HM_COMM_INQ_SUMMARY_FOR_REVIEW (BATCH_ID   IN    NUMBER,
                              CUR_HM_COMM_SUMMARY     OUT ref_cursor,
                               CUR_COMM_IND_SUMMARY     OUT ref_cursor,
                            CUR_COMM_ORG_SUMMARY     OUT ref_cursor
                              );
                             
END PKG_COMM_INQ_SUMMARY_PR;

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_COMM_INQ_SUMMARY_PR FOR HMCORE.PKG_COMM_INQ_SUMMARY_PR;
GRANT EXECUTE ON HMCORE.PKG_COMM_INQ_SUMMARY_PR TO RL_INQ_MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PKG_COM_IOI_COMPL_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_IOI_COMPL_DATA_V1" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_IOI_COMPL_DATA_V1; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_IOI_COMPL_DATA_V1 FOR HMCORE.PKG_COM_IOI_COMPL_DATA_V1;

GRANT EXECUTE ON HMCORE.PKG_COM_IOI_COMPL_DATA_V1 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_IOI_COMPL_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_IOI_COMPL_DATA_V2" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_IOI_COMPL_DATA_V2; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_IOI_COMPL_DATA_V2 FOR HMCORE.PKG_COM_IOI_COMPL_DATA_V2;

GRANT EXECUTE ON HMCORE.PKG_COM_IOI_COMPL_DATA_V2 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_IOI_COMPL_DATA_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_IOI_COMPL_DATA_V3" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_IOI_COMPL_DATA_V3; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_IOI_COMPL_DATA_V3 FOR HMCORE.PKG_COM_IOI_COMPL_DATA_V3;

GRANT EXECUTE ON HMCORE.PKG_COM_IOI_COMPL_DATA_V3 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_PR_IOI_COMPL_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_PR_IOI_COMPL_DATA_V1" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_PR_IOI_COMPL_DATA_V1; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_PR_IOI_COMPL_DATA_V1 FOR HMCORE.PKG_COM_PR_IOI_COMPL_DATA_V1;

GRANT EXECUTE ON HMCORE.PKG_COM_PR_IOI_COMPL_DATA_V1 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_R_IOI_COMPL_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_R_IOI_COMPL_DATA_V1" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_R_IOI_COMPL_DATA_V1; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_R_IOI_COMPL_DATA_V1 FOR HMCORE.PKG_COM_R_IOI_COMPL_DATA_V1;

GRANT EXECUTE ON HMCORE.PKG_COM_R_IOI_COMPL_DATA_V1 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_R_IOI_COMPL_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_R_IOI_COMPL_DATA_V2" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_R_IOI_COMPL_DATA_V2; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_R_IOI_COMPL_DATA_V2 FOR HMCORE.PKG_COM_R_IOI_COMPL_DATA_V2;

GRANT EXECUTE ON HMCORE.PKG_COM_R_IOI_COMPL_DATA_V2 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_R_IOI_COMPL_DATA_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_R_IOI_COMPL_DATA_V3" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_R_IOI_COMPL_DATA_V3; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_R_IOI_COMPL_DATA_V3 FOR HMCORE.PKG_COM_R_IOI_COMPL_DATA_V3;

GRANT EXECUTE ON HMCORE.PKG_COM_R_IOI_COMPL_DATA_V3 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_COM_R_IOI_COMPL_DATA_V4
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_COM_R_IOI_COMPL_DATA_V4" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag    IN NUMBER
                              );
                              
END PKG_COM_R_IOI_COMPL_DATA_V4; 

/*+

CREATE SYNONYM APP_INQ_MATCH.PKG_COM_R_IOI_COMPL_DATA_V4 FOR HMCORE.PKG_COM_R_IOI_COMPL_DATA_V4;

GRANT EXECUTE ON HMCORE.PKG_COM_R_IOI_COMPL_DATA_V4 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V1" 
IS
   TYPE ref_cursor IS REF CURSOR;

   PROCEDURE PR_POPULATE_DATA(pv_report_id             IN  VARCHAR2,
                              pv_product_id            OUT VARCHAR2,
                              CUR_MFI_HMCONSUMER       OUT ref_cursor,
                              CUR_MFI_HMADDRESS        OUT ref_cursor,
                              CUR_MFI_HMPHONE          OUT ref_cursor,
                              CUR_MFI_HMACCOUNT        OUT ref_cursor,
                              CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                              CUR_MFI_GROUP            OUT ref_cursor,
                              CUR_CNS_HMCONSUMER       OUT ref_cursor,
                              CUR_CNS_HMADDRESS        OUT ref_cursor,
                              CUR_CNS_HMPHONE          OUT ref_cursor,
                              CUR_CNS_HMACCOUNT        OUT ref_cursor,
                              CUR_CNS_HMSECURITY       OUT ref_cursor,
                              CUR_IOI_HMCONSUMER       OUT ref_cursor,
                              pv_err_status            OUT VARCHAR2
                             );

END PKG_CSR_COMPLETE_DATA_V1; 

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V10
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V10" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_cns_score                 OUT NUMBER,
                                gv_cns_reason                OUT VARCHAR2,
                                gv_cns_name                  OUT VARCHAR2,
                                gn_mfi_score                 OUT NUMBER,
                                gv_mfi_reason                OUT VARCHAR2,
                                gv_mfi_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_V10;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V10 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V10;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V10 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V11
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V11" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_cns_score                 OUT NUMBER,
                                gv_cns_reason                OUT VARCHAR2,
                                gv_cns_name                  OUT VARCHAR2,
                                gn_mfi_score                 OUT NUMBER,
                                gv_mfi_reason                OUT VARCHAR2,
                                gv_mfi_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_v11;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V11 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V11;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V11 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V13
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V13" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_cns_score                 OUT NUMBER,
                                gv_cns_reason                OUT VARCHAR2,
                                gv_cns_name                  OUT VARCHAR2,
                                gn_mfi_score                 OUT NUMBER,
                                gv_mfi_reason                OUT VARCHAR2,
                                gv_mfi_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_V13;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V13 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V13;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V13 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V1_TMP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V1_TMP" 
IS
   TYPE ref_cursor IS REF CURSOR;

   PROCEDURE PR_POPULATE_DATA(pv_report_id             IN  VARCHAR2,
                              pv_product_id            OUT VARCHAR2,
                              CUR_MFI_HMCONSUMER       OUT ref_cursor,
                              CUR_MFI_HMADDRESS        OUT ref_cursor,
                              CUR_MFI_HMPHONE          OUT ref_cursor,
                              CUR_MFI_HMACCOUNT        OUT ref_cursor,
                              CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                              CUR_MFI_GROUP            OUT ref_cursor,
                              CUR_CNS_HMCONSUMER       OUT ref_cursor,
                              CUR_CNS_HMADDRESS        OUT ref_cursor,
                              CUR_CNS_HMPHONE          OUT ref_cursor,
                              CUR_CNS_HMACCOUNT        OUT ref_cursor,
                              CUR_CNS_HMSECURITY       OUT ref_cursor,
                              CUR_IOI_HMCONSUMER       OUT ref_cursor,
                              pv_err_status            OUT VARCHAR2
                             );

END PKG_CSR_COMPLETE_DATA_V1_TMP; 

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V2" 
IS
   TYPE ref_cursor IS REF CURSOR;

   PROCEDURE PR_POPULATE_DATA(pv_report_id             IN  VARCHAR2,
                              pv_product_id            OUT VARCHAR2,
                              CUR_MFI_HMCONSUMER       OUT ref_cursor,
                              CUR_MFI_HMADDRESS        OUT ref_cursor,
                              CUR_MFI_HMPHONE          OUT ref_cursor,
                              CUR_MFI_HMACCOUNT        OUT ref_cursor,
                              CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                              CUR_MFI_GROUP            OUT ref_cursor,
                              CUR_CNS_HMCONSUMER       OUT ref_cursor,
                              CUR_CNS_HMADDRESS        OUT ref_cursor,
                              CUR_CNS_HMPHONE          OUT ref_cursor,
                              CUR_CNS_HMACCOUNT        OUT ref_cursor,
                              CUR_CNS_HMSECURITY       OUT ref_cursor,
                              CUR_IOI_HMCONSUMER       OUT ref_cursor,
                              pv_err_status            OUT VARCHAR2,
                              gn_score                 OUT NUMBER,
                              gv_reason                OUT VARCHAR2,
                              gv_name                  OUT VARCHAR2
                             );
                             
END PKG_CSR_COMPLETE_DATA_V2;

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V2 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V2;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V2 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V3" 
IS
   TYPE ref_cursor IS REF CURSOR;

   PROCEDURE PR_POPULATE_DATA(pv_report_id             IN  VARCHAR2,
                              pv_product_id            OUT VARCHAR2,
                              CUR_MFI_HMCONSUMER       OUT ref_cursor,
                              CUR_MFI_HMADDRESS        OUT ref_cursor,
                              CUR_MFI_HMPHONE          OUT ref_cursor,
                              CUR_MFI_HMACCOUNT        OUT ref_cursor,
                              CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                              CUR_MFI_GROUP            OUT ref_cursor,
                              CUR_CNS_HMCONSUMER       OUT ref_cursor,
                              CUR_CNS_HMADDRESS        OUT ref_cursor,
                              CUR_CNS_HMPHONE          OUT ref_cursor,
                              CUR_CNS_HMACCOUNT        OUT ref_cursor,
                              CUR_CNS_HMSECURITY       OUT ref_cursor,
                              CUR_IOI_HMCONSUMER       OUT ref_cursor,
                              pv_err_status            OUT VARCHAR2,
                              gn_score                 OUT NUMBER,
                              gv_reason                OUT VARCHAR2,
                              gv_name                  OUT VARCHAR2
                             );
                             
END PKG_CSR_COMPLETE_DATA_V3;

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V3 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V3;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V3 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V4
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V4" 
IS
   TYPE ref_cursor IS REF CURSOR;

   PROCEDURE PR_POPULATE_DATA(pv_report_id             IN  VARCHAR2,
                              pv_product_id            OUT VARCHAR2,
                              CUR_MFI_HMCONSUMER       OUT ref_cursor,
                              CUR_MFI_HMADDRESS        OUT ref_cursor,
                              CUR_MFI_HMPHONE          OUT ref_cursor,
                              CUR_MFI_HMACCOUNT        OUT ref_cursor,
                              CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                              CUR_MFI_GROUP            OUT ref_cursor,
                              CUR_CNS_HMCONSUMER       OUT ref_cursor,
                              CUR_CNS_HMADDRESS        OUT ref_cursor,
                              CUR_CNS_HMPHONE          OUT ref_cursor,
                              CUR_CNS_HMACCOUNT        OUT ref_cursor,
                              CUR_CNS_HMSECURITY       OUT ref_cursor,
                              CUR_IOI_HMCONSUMER       OUT ref_cursor,
                              pv_err_status            OUT VARCHAR2,
                              gn_score                 OUT NUMBER,
                              gv_reason                OUT VARCHAR2,
                              gv_name                  OUT VARCHAR2
                             );
                             
END PKG_CSR_COMPLETE_DATA_V4;

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V4 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V4;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V4 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V5
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V5" 
IS
   TYPE ref_cursor IS REF CURSOR;

   PROCEDURE PR_POPULATE_DATA(pv_report_id             IN  VARCHAR2,
                              pv_product_id            OUT VARCHAR2,
                              CUR_MFI_HMCONSUMER       OUT ref_cursor,
                              CUR_MFI_HMADDRESS        OUT ref_cursor,
                              CUR_MFI_HMPHONE          OUT ref_cursor,
                              CUR_MFI_HMACCOUNT        OUT ref_cursor,
                              CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                              CUR_MFI_GROUP            OUT ref_cursor,
                              CUR_CNS_HMCONSUMER       OUT ref_cursor,
                              CUR_CNS_HMADDRESS        OUT ref_cursor,
                              CUR_CNS_HMPHONE          OUT ref_cursor,
                              CUR_CNS_HMACCOUNT        OUT ref_cursor,
                              CUR_CNS_HMSECURITY       OUT ref_cursor,
                              CUR_IOI_HMCONSUMER       OUT ref_cursor,
                              pv_err_status            OUT VARCHAR2,
                              gn_score                 OUT NUMBER,
                              gv_reason                OUT VARCHAR2,
                              gv_name                  OUT VARCHAR2
                             );
                             
END PKG_CSR_COMPLETE_DATA_V5;

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V5 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V5;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V5 TO RL_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V6
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V6" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_score                 OUT NUMBER,
                                gv_reason                OUT VARCHAR2,
                                gv_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_V6;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V6 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V6;
GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V6 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V7
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V7" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_cns_score                 OUT NUMBER,
                                gv_cns_reason                OUT VARCHAR2,
                                gv_cns_name                  OUT VARCHAR2,
                                gn_mfi_score                 OUT NUMBER,
                                gv_mfi_reason                OUT VARCHAR2,
                                gv_mfi_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_V7;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V7 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V7;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V7 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V8
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V8" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_cns_score                 OUT NUMBER,
                                gv_cns_reason                OUT VARCHAR2,
                                gv_cns_name                  OUT VARCHAR2,
                                gn_mfi_score                 OUT NUMBER,
                                gv_mfi_reason                OUT VARCHAR2,
                                gv_mfi_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_V8;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V8 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V8;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V8 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_CSR_COMPLETE_DATA_V9
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_CSR_COMPLETE_DATA_V9" 
IS
    TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_POPULATE_DATA (pv_report_id             IN  VARCHAR2,
                                pv_product_id            OUT VARCHAR2,
                                CUR_MFI_HMCONSUMER       OUT ref_cursor,
                                CUR_MFI_HMADDRESS        OUT ref_cursor,
                                CUR_MFI_HMPHONE          OUT ref_cursor,
                                CUR_MFI_HMACCOUNT        OUT ref_cursor,
                                CUR_MFI_GRP_ACCOUNT      OUT ref_cursor,
                                CUR_MFI_GROUP            OUT ref_cursor,
                                CUR_CNS_HMCONSUMER       OUT ref_cursor,
                                CUR_CNS_HMADDRESS        OUT ref_cursor,
                                CUR_CNS_HMPHONE          OUT ref_cursor,
                                CUR_CNS_HMACCOUNT        OUT ref_cursor,
                                CUR_CNS_HMSECURITY       OUT ref_cursor,
                                CUR_IOI_HMCONSUMER       OUT ref_cursor,
                                pv_err_status            OUT VARCHAR2,
                                gn_cns_score                 OUT NUMBER,
                                gv_cns_reason                OUT VARCHAR2,
                                gv_cns_name                  OUT VARCHAR2,
                                gn_mfi_score                 OUT NUMBER,
                                gv_mfi_reason                OUT VARCHAR2,
                                gv_mfi_name                  OUT VARCHAR2);
                             
END PKG_CSR_COMPLETE_DATA_V9;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_CSR_COMPLETE_DATA_V9 FOR HMCORE.PKG_CSR_COMPLETE_DATA_V9;

GRANT EXECUTE ON HMCORE.PKG_CSR_COMPLETE_DATA_V9 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_DELETE_SUMMARY_CNS_DATA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_DELETE_SUMMARY_CNS_DATA" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

   PROCEDURE HM_DELETE_SUMMARY_CNS_DATA (pn_batch_id  IN  NUMBER
                              );
                              
END PKG_DELETE_SUMMARY_CNS_DATA; 

/
--------------------------------------------------------
--  DDL for Package PKG_DELETE_SUMMARY_CNS_DATA_12
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_DELETE_SUMMARY_CNS_DATA_12" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

   PROCEDURE HM_DELETE_SUMMARY_CNS_DATA (pn_batch_id  IN  NUMBER);
                              
END PKG_DELETE_SUMMARY_CNS_DATA_12; 

/
--------------------------------------------------------
--  DDL for Package PKG_GET_COMM_REQ_DATA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_GET_COMM_REQ_DATA" 
IS
   TYPE REF_CURSOR IS REF CURSOR;

   PROCEDURE HM_COMM_REQ_DATA (COMM_RAW_REQUEST_ID    IN     NUMBER,
                              CUR_ORGN_DETAILS       OUT REF_CURSOR,
                              CUR_ORGN_ADDR_DETAILS       OUT REF_CURSOR,
                              CUR_ORGN_PHN_DETAILS       OUT REF_CURSOR,
                              CUR_INDV_DETAILS     OUT REF_CURSOR,
                              CUR_INDV_ADDR_DETAILS        OUT REF_CURSOR,
                              CUR_INDV_PHONE_DETAILS          OUT REF_CURSOR,
                              CUR_APP_DETAILS        OUT REF_CURSOR, 
                              err_status           OUT VARCHAR2);
END PKG_GET_COMM_REQ_DATA; 

/
--------------------------------------------------------
--  DDL for Package PKG_GET_COMM_REQ_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_GET_COMM_REQ_DATA_V1" 
IS
   TYPE REF_CURSOR IS REF CURSOR;

   PROCEDURE HM_COMM_REQ_DATA (COMM_RAW_REQUEST_ID    IN     NUMBER,
                              CUR_ORGN_DETAILS       OUT REF_CURSOR,
                              CUR_ORGN_ADDR_DETAILS       OUT REF_CURSOR,
                              CUR_ORGN_PHN_DETAILS       OUT REF_CURSOR,
                              CUR_INDV_DETAILS     OUT REF_CURSOR,
                              CUR_INDV_ADDR_DETAILS        OUT REF_CURSOR,
                              CUR_INDV_PHONE_DETAILS          OUT REF_CURSOR,
                              CUR_APP_DETAILS        OUT REF_CURSOR, 
                              err_status           OUT VARCHAR2);
END PKG_GET_COMM_REQ_DATA_V1; 


/*+
CREATE SYNONYM APP_INQ_MATCH.PKG_GET_COMM_REQ_DATA_V1 FOR HMCORE.PKG_GET_COMM_REQ_DATA_V1;

GRANT EXECUTE ON HMCORE.PKG_GET_COMM_REQ_DATA_V1 TO RL_INQ_MATCH;

*/

/
--------------------------------------------------------
--  DDL for Package PKG_GET_COMM_REQ_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_GET_COMM_REQ_DATA_V2" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HM_COMM_REQ_DATA (COMM_RAW_REQUEST_ID      IN  NUMBER,
                                CUR_ORGN_DETAILS         OUT REF_CURSOR,
                                CUR_ORGN_ADDR_DETAILS    OUT REF_CURSOR,
                                CUR_ORGN_PHN_DETAILS     OUT REF_CURSOR,
                                CUR_INDV_DETAILS         OUT REF_CURSOR,
                                CUR_INDV_ADDR_DETAILS    OUT REF_CURSOR,
                                CUR_INDV_PHONE_DETAILS   OUT REF_CURSOR,
                                CUR_APP_DETAILS          OUT REF_CURSOR, 
                                err_status               OUT VARCHAR2);
END PKG_GET_COMM_REQ_DATA_V2; 

/
--------------------------------------------------------
--  DDL for Package PKG_GET_COMM_REQ_DATA_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_GET_COMM_REQ_DATA_V3" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HM_COMM_REQ_DATA (COMM_RAW_REQUEST_ID      IN  NUMBER,
                                CUR_ORGN_DETAILS         OUT REF_CURSOR,
                                CUR_ORGN_ADDR_DETAILS    OUT REF_CURSOR,
                                CUR_ORGN_PHN_DETAILS     OUT REF_CURSOR,
                                CUR_INDV_DETAILS         OUT REF_CURSOR,
                                CUR_INDV_ADDR_DETAILS    OUT REF_CURSOR,
                                CUR_INDV_PHONE_DETAILS   OUT REF_CURSOR,
                                CUR_APP_DETAILS          OUT REF_CURSOR, 
                                err_status               OUT VARCHAR2);
END PKG_GET_COMM_REQ_DATA_V3; 


/*CREATE SYNONYM APP_INQ_MATCH.PKG_GET_COMM_REQ_DATA_V3 FOR HMCORE.PKG_GET_COMM_REQ_DATA_V3;
GRANT EXECUTE ON HMCORE.PKG_GET_COMM_REQ_DATA_V3 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_ADD_MATCH_INVOL_P
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_ADD_MATCH_INVOL_P" 
IS
   TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_INQ_ADD_FINDINGS ( pv_cand_ids IN VARCHAR2,
                                    pv_region IN VARCHAR2,
                                    pcur_hmcandidate OUT ref_cursor,
                                    pv_error OUT VARCHAR2
                                  );

END PKG_INQ_ADD_MATCH_INVOL_P; 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_ADD_MATCH_INVOL_P0999
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_ADD_MATCH_INVOL_P0999" 
IS
   TYPE ref_cursor IS REF CURSOR;

    PROCEDURE PR_INQ_ADD_FINDINGS ( pv_cand_ids IN VARCHAR2,
                                    pv_region IN VARCHAR2,
                                    pcur_hmcandidate OUT ref_cursor,
                                    pv_error OUT VARCHAR2
                                  );

END PKG_INQ_ADD_MATCH_INVOL_P0999; 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_COMM_BULK_SUMMARY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_COMM_BULK_SUMMARY" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
  
   PROCEDURE HM_INQ_BULK_SUMM_FOR_REVIEW (BATCH_ID   IN    NUMBER,
                              CUR_HMSUMMARY      OUT ref_cursor
                              );
                              
END PKG_INQ_COMM_BULK_SUMMARY; 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_CR_DETAILS_CNS_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_CR_DETAILS_CNS_V1" 
IS

       TYPE ref_cursor IS REF CURSOR;
       
       
       PROCEDURE  PR_CREATE_INQUIRY (
                                       pn_inq_batch_id IN  NUMBER,
                                       CUR_INQ_FORMAT  OUT ref_cursor,
                                       lv_err_msg      OUT VARCHAR2
                                     );

END PKG_INQ_CR_DETAILS_CNS_V1;


/*
CREATE SYNONYM APP_INQ_MATCH.PKG_INQ_CR_DETAILS_CNS_V1 FOR HMCORE.PKG_INQ_CR_DETAILS_CNS_V1;
GRANT EXECUTE ,DEBUG ON HMCORE.PKG_INQ_CR_DETAILS_CNS_V1 TO RL_INQ_MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_CR_DETAILS_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_CR_DETAILS_V1" 
IS

       TYPE ref_cursor IS REF CURSOR;
       
       
       PROCEDURE  PR_CREATE_INQUIRY (
                                       pn_inq_batch_id IN  NUMBER,
                                       CUR_INQ_FORMAT  OUT ref_cursor,
                                       lv_err_msg      OUT VARCHAR2
                                     );

END PKG_INQ_CR_DETAILS_V1;


/*
CREATE SYNONYM APP_INQ_MATCH.PKG_INQ_CR_DETAILS_V1 FOR HMCORE.PKG_INQ_CR_DETAILS_V1;
GRANT EXECUTE ,DEBUG ON HMCORE.PKG_INQ_CR_DETAILS_V1 TO  RL_REVIEW_SELECT,RL_MFI_INQ_SELECT,RL_INQ_MATCH,MATCH,MATCH_CP,MATCH_FETCH,APP_INQ_MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_CR_RID_DETAILS_CNS_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_CR_RID_DETAILS_CNS_V1" 
IS

       TYPE ref_cursor IS REF CURSOR;
       
       
       PROCEDURE  PR_CREATE_INQUIRY (
                                       pn_inq_report_id IN  NUMBER,
                                       CUR_INQ_FORMAT  OUT ref_cursor,
                                       lv_err_msg      OUT VARCHAR2
                                     );

END PKG_INQ_CR_RID_DETAILS_CNS_V1;


/*
CREATE SYNONYM APP_INQ_MATCH.PKG_INQ_CR_RID_DETAILS_CNS_V1 FOR HMCORE.PKG_INQ_CR_RID_DETAILS_CNS_V1;
GRANT EXECUTE ,DEBUG ON HMCORE.PKG_INQ_CR_RID_DETAILS_CNS_V1 TO RL_INQ_MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_CR_RID_DETAILS_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_CR_RID_DETAILS_V1" 
IS

       TYPE ref_cursor IS REF CURSOR;
       
       
       PROCEDURE  PR_CREATE_INQUIRY (
                                       pn_inq_report_id IN  NUMBER,
                                       CUR_INQ_FORMAT  OUT ref_cursor,
                                       lv_err_msg      OUT VARCHAR2
                                     );

END PKG_INQ_CR_RID_DETAILS_V1;


/*
CREATE SYNONYM APP_INQ_MATCH.PKG_INQ_CR_RID_DETAILS_V1 FOR HMCORE.PKG_INQ_CR_RID_DETAILS_V1;
GRANT EXECUTE ,DEBUG ON HMCORE.PKG_INQ_CR_RID_DETAILS_V1 TO  RL_REVIEW_SELECT,RL_MFI_INQ_SELECT,RL_INQ_MATCH,MATCH,MATCH_CP,MATCH_FETCH,APP_INQ_MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_REQUEST" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
  
   PROCEDURE HM_INQ_REQUEST_FOR_REPROCESS (BATCH_ID   IN    NUMBER,
                              CUR_HMREQUEST      OUT ref_cursor
                              );
                              
END PKG_INQ_REQUEST; 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_REQUEST_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_REQUEST_V2" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
  
   PROCEDURE HM_INQ_REQUEST_FOR_REPROCESS (BATCH_ID   IN    NUMBER,
                              CUR_HMREQUEST      OUT ref_cursor
                              );
                              
END PKG_INQ_REQUEST_V2; 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_REQUEST_V2_PR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_REQUEST_V2_PR" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
  
   PROCEDURE HM_INQ_REQUEST_FOR_REPROCESS (BATCH_ID   IN    NUMBER,
                              CUR_HMREQUEST      OUT ref_cursor
                              );
                              
END PKG_INQ_REQUEST_V2_PR;
/*
CREATE SYNONYM APP_INQ_MATCH.PKG_INQ_REQUEST_V2_PR FOR HMCORE.PKG_INQ_REQUEST_V2_PR;
GRANT EXECUTE ON HMCORE.PKG_INQ_REQUEST_V2_PR TO RL_INQ_MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_REQUEST_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_REQUEST_V3" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
  
   PROCEDURE HM_INQ_REQUEST_FOR_REPROCESS (BATCH_ID   IN    NUMBER,
                              CUR_HMREQUEST      OUT ref_cursor,
                              PN_FORCIBLY_RUN_FLAG NUMBER
                              );
                              
END PKG_INQ_REQUEST_V3; 

/*
CREATE SYNONYM APP_INQ_MATCH.PKG_INQ_REQUEST_V3 FOR HMCORE.PKG_INQ_REQUEST_V3;

GRANT EXECUTE ON HMCORE.PKG_INQ_REQUEST_V3 TO RL_INQ_MATCH;

*/

/
--------------------------------------------------------
--  DDL for Package PKG_INQ_SUMMARY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_INQ_SUMMARY" 
IS
 TYPE ref_cursor IS REF CURSOR;
 
  
   PROCEDURE HM_INQ_SUMMARY_FOR_REVIEW (BATCH_ID   IN    NUMBER,
                              CUR_HMSUMMARY      OUT ref_cursor
                              );
                              
END PKG_INQ_SUMMARY; 

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_COMPLETE_DATA
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_COMPLETE_DATA" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2
                              );
                              
END PKG_IOI_COMPLETE_DATA; 

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_COMPLETE_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_COMPLETE_DATA_V1" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2
                              );
                              
END PKG_IOI_COMPLETE_DATA_V1; 

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_COMPLETE_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_COMPLETE_DATA_V2" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_COMPLETE_DATA_V2; 

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_COMPLETE_DATA_V2_TMP
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_COMPLETE_DATA_V2_TMP" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_COMPLETE_DATA_V2_TMP; 

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_COMPLETE_DATA_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_COMPLETE_DATA_V3" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_COMPLETE_DATA_V3;

/*CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_COMPLETE_DATA_V3 FOR HMCORE.PKG_IOI_COMPLETE_DATA_V3;
GRANT EXECUTE,DEBUG ON HMCORE.PKG_IOI_COMPLETE_DATA_V3 TO RL_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_PR_COMPLETE_DATA_TEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_PR_COMPLETE_DATA_TEST" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_PR_COMPLETE_DATA_TEST; 


/*

CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_PR_COMPLETE_DATA_TEST FOR HMCORE.PKG_IOI_PR_COMPLETE_DATA_TEST;

GRANT EXECUTE ON HMCORE.PKG_IOI_PR_COMPLETE_DATA_TEST TO RL_INQ_MATCH;

*/

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_PR_COMPLETE_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_PR_COMPLETE_DATA_V1" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_PR_COMPLETE_DATA_V1; 


/*

CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_PR_COMPLETE_DATA_V1 FOR HMCORE.PKG_IOI_PR_COMPLETE_DATA_V1;

GRANT EXECUTE ON HMCORE.PKG_IOI_PR_COMPLETE_DATA_V1 TO RL_INQ_MATCH;

*/

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_PR_COMPLETE_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_PR_COMPLETE_DATA_V2" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_PR_COMPLETE_DATA_V2; 


/*

CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_PR_COMPLETE_DATA_V2 FOR HMCORE.PKG_IOI_PR_COMPLETE_DATA_V2;

GRANT EXECUTE ON HMCORE.PKG_IOI_PR_COMPLETE_DATA_V2 TO RL_INQ_MATCH;

*/

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_RETRO_COMPLETE_DATA_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_RETRO_COMPLETE_DATA_V1" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_RETRO_COMPLETE_DATA_V1; 


/*CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_RETRO_COMPLETE_DATA_V1 FOR HMCORE.PKG_IOI_RETRO_COMPLETE_DATA_V1;

GRANT EXECUTE ON HMCORE.PKG_IOI_RETRO_COMPLETE_DATA_V1 TO APP_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_RETRO_COMPLETE_DATA_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_RETRO_COMPLETE_DATA_V2" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_RETRO_COMPLETE_DATA_V2; 


/*CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_RETRO_COMPLETE_DATA_V2 FOR HMCORE.PKG_IOI_RETRO_COMPLETE_DATA_V2;

GRANT EXECUTE ON HMCORE.PKG_IOI_RETRO_COMPLETE_DATA_V2 TO APP_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_IOI_RETRO_COMPLETE_DATA_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_IOI_RETRO_COMPLETE_DATA_V3" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    PROCEDURE HMCONSUMER_DATA (
                                    pn_inquiry_id        IN NUMBER,
                                    pv_candidate_idin    IN  VARCHAR2,
                                    pv_inquiry_dt        IN  VARCHAR2,
                                    cur_hmconsumer       OUT sys_refcursor,
                                    pv_err_status        OUT VARCHAR2,
                                    pv_reprocess_flag   IN NUMBER
                              );
                              
END PKG_IOI_RETRO_COMPLETE_DATA_V3; 


/*CREATE SYNONYM APP_INQ_MATCH.PKG_IOI_RETRO_COMPLETE_DATA_V3 FOR HMCORE.PKG_IOI_RETRO_COMPLETE_DATA_V3;

GRANT EXECUTE ON HMCORE.PKG_IOI_RETRO_COMPLETE_DATA_V3 TO APP_INQ_MATCH;*/

/
--------------------------------------------------------
--  DDL for Package PKG_MATCH_CORRECTION_REQUEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PKG_MATCH_CORRECTION_REQUEST" 
IS
 TYPE ref_cursor IS REF CURSOR;

  
   PROCEDURE HM_MATCH_CORRECTION_REQUEST (INQUIRY_ID   IN     VARCHAR2,
                              CUR_HMAPP_DETAIL      OUT ref_cursor,
                              CUR_HMAPP_ADDRESS     OUT ref_cursor,
                              CUR_HMAPP_PHONE      OUT ref_cursor
                              );
                              
                              
END PKG_MATCH_CORRECTION_REQUEST;
--Body 

/
--------------------------------------------------------
--  DDL for Package PK_ANALYTICS_PROCESS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_ANALYTICS_PROCESS" 
AS

Gv_file_dir VARCHAR2(100):='CIBIL_LOG';
Gv_log_file_name VARCHAR2(100);

gv_cns_final_ana_tbl VARCHAR2(100);
gv_mfi_final_ana_tbl VARCHAR2(100);
gv_comm_final_ana_tbl VARCHAR2(100);
gv_final_to_email_ids VARCHAR2(10000):='cloverdba@highmark.in,payal.kulkarni@highmark.in,smita.gamare@highmark.in,umaid.sonday@highmark.in,aniket.boricha@highmark.in,rajendra.dhome@highmark.in';
gv_final_cc_email_ids VARCHAR2(10000):='nikunj.bhagat@highmark.in,pinkesh.ambavat@highmark.in,vikas.mane@highmark.in,prashant.verma@highmark.in,abhijeet.singh@highmark.in';
    
EX_PARAMETER_ERROR EXCEPTION; 

    PROCEDURE PR_START_ANALYTICS (pv_bureau VARCHAR2);
    PROCEDURE PR_CNS_MONTHY_ANA_TBL;
    PROCEDURE PR_MFI_MONTHY_ANA_TBL;
    PROCEDURE PR_COMM_MONTHY_ANA_TBL;
    PROCEDURE PR_INSERT_CLOSED_ACCCOUNTS (pv_bureau IN VARCHAR2,
                                          pv_month IN VARCHAR2 DEFAULT NULL
                                         );

END PK_ANALYTICS_PROCESS; 

/
--------------------------------------------------------
--  DDL for Package PK_AUDIT_TRACKER
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_AUDIT_TRACKER" 
AS

    PROCEDURE PR_AUDIT_MASTER_INSERT(
                                        pv_what      VARCHAR2,
                                        pn_node      NUMBER   DEFAULT 1
                                    );

    PROCEDURE PR_AUDIT_RESTART;
    
    PROCEDURE PR_AUDIT_STATUS_UPDATE(
                                        pn_audit_id NUMBER,
                                        pv_status   VARCHAR2,
                                        pv_err_msg  VARCHAR2 DEFAULT NULL
                                    );

    PROCEDURE PR_START_JOB (
                                pv_jobs_sqls      IN  VARCHAR2,
                                pn_node           IN  NUMBER DEFAULT 1,
                                pn_job_id         OUT NUMBER,
                                pv_user_id        OUT VARCHAR2
                           );

    PROCEDURE PR_CHECK_RUNNING(
                                    pn_audit_id NUMBER,
                                    pn_job_id IN  NUMBER
                              );
                                                                         
END PK_AUDIT_TRACKER; 

/
--------------------------------------------------------
--  DDL for Package PK_CNS_DUMP_CREATION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CNS_DUMP_CREATION" 
IS

    FUNCTION FN_CREATE_DUMP( pn_batch_id NUMBER,
                             pv_partition_name VARCHAR2,
                             pv_report_id VARCHAR2 DEFAULT NULL,
                             pv_bank_name  VARCHAR2 DEFAULT NULL,
                             pv_cand_seln_type VARCHAR2 DEFAULT NULL,
                             pv_cand_seln_rule VARCHAR2 DEFAULT NULL
                           )
    RETURN VARCHAR2;
    
    PROCEDURE PR_CNS_DUMP( pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_report_id VARCHAR2,
                           pv_bank_name  VARCHAR2,
                           pv_cand_seln_type VARCHAR2,
                           pv_cand_seln_rule VARCHAR2,
                           pv_data_file VARCHAR2,
                           pn_dump_file_seq NUMBER
                         );
                         
    PROCEDURE PR_CNS_DUMP_FILE( pn_batch_id NUMBER,
                               pv_partition_name VARCHAR2,
                               pv_bank_name  VARCHAR2,
                               pv_data_file  VARCHAR2,
                               pv_tbl_name       VARCHAR2,
                               pv_recall_condition VARCHAR2,
                               pn_dump_file_seq NUMBER
                             );

    
END; 

/
--------------------------------------------------------
--  DDL for Package PK_CNS_INQ_ALERT_PRODUCT_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CNS_INQ_ALERT_PRODUCT_V1" 
AS
    gv_file_dir       VARCHAR2(100) := 'ALERT_LOG';
    gv_log_dir        VARCHAR2(100) := 'ALERT_LOG';
    gv_log_file_name  VARCHAR2(100) := 'INQ_CNS_ALERT_PROC_'||TO_CHAR(SYSDATE,'DDMMYYYY');

    NORMAL_EXT        EXCEPTION;
    FINAL_EXT         EXCEPTION;
    
    TYPE CUR_SELECT IS REF CURSOR;
    
    procedure PR_ALERT_TRACK_SETUP_PROCESS;

    procedure PR_ALERT_SETUP_PROCESS(  pv_product_code IN VARCHAR2,
                                       pv_report_id IN VARCHAR2,
                                       pv_consumer_name in varchar2 ,
                                       pv_alert_type IN VARCHAR2,
                                       pd_alert_start_date IN DATE,
                                       pd_alert_end_date IN DATE,
                                       pn_alert_frequency IN VARCHAR2,
                                       pv_err  out varchar2 );
                                  
    PROCEDURE PR_ALERT_GENERATE_PROCESS (pv_report_id IN VARCHAR2,
                                         pv_customer        IN VARCHAR2  
                                         );
    PROCEDURE PR_INSERT_DEFAULT_ACC_ALERT (PV_REPORT_ID         IN VARCHAR2,
                                           pv_customer          IN VARCHAR2 );                                      
    
    PROCEDURE PR_INSERT_SKIP_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                         pv_customer          IN VARCHAR2 );  
                                        
    PROCEDURE PR_INSERT_PAYMENT_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                            pv_customer          IN VARCHAR2 );                                                                                                                                                   

    PROCEDURE PR_INSERT_INQUIRY_ACC_ALERT ( pv_report_id         IN VARCHAR2,
                                            pv_customer          IN VARCHAR2 );                                                                                                                                                   

    PROCEDURE PR_INSERT_CLOSE_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                          pv_customer          IN VARCHAR2  );  
     
                                   
    PROCEDURE PR_INSERT_DISBURSE_ACC_ALERT (  PV_REPORT_ID         IN VARCHAR2,
                                              pv_customer          IN VARCHAR2 );  

    PROCEDURE PR_INSERT_UTILISE_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                            pv_customer          IN VARCHAR2 );  

    PROCEDURE PR_INSERT_UTILISE_R_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                             pv_customer          IN VARCHAR2 );                                  
   
    FUNCTION FN_FIND_RUNNING_DPD (pv_payment_history IN VARCHAR2,
                                  pv_ot_dpd          IN VARCHAR2)
    RETURN NUMBER;
       
    PROCEDURE PR_ALERT_OUT_PROCESS  ( pv_report_id          IN VARCHAR2, 
                                      pv_alertout           OUT CUR_SELECT,
                                      pv_err                OUT VARCHAR2,
                                      pv_consumer_name      OUT VARCHAR2,
                                      pv_back_dt            IN DATE DEFAULT NULL);                                 

END;

/*
CREATE SYNONYM APP_INQ_MATCH.PK_CNS_INQ_ALERT_PRODUCT_V1 FOR HMCORE.PK_CNS_INQ_ALERT_PRODUCT_V1;
GRANT EXECUTE ON HMCORE.PK_CNS_INQ_ALERT_PRODUCT_V1 TO RL_INQ_MATCH,APP_INQ_MATCH;
  

*/

/
--------------------------------------------------------
--  DDL for Package PK_CNS_INQ_ALERT_PRODUCT_V1_T
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CNS_INQ_ALERT_PRODUCT_V1_T" 
AS
    gv_file_dir       VARCHAR2(100) := 'ALERT_LOG';
    gv_log_dir        VARCHAR2(100) := 'ALERT_LOG';
    gv_log_file_name  VARCHAR2(100) := 'INQ_CNS_ALERT_PROC_'||TO_CHAR(SYSDATE,'DDMMYYYY');

    NORMAL_EXT        EXCEPTION;
    FINAL_EXT         EXCEPTION;
    
    TYPE CUR_SELECT IS REF CURSOR;
    
    procedure PR_ALERT_TRACK_SETUP_PROCESS;

    procedure PR_ALERT_SETUP_PROCESS(  pv_product_code IN VARCHAR2,
                                       pv_report_id IN VARCHAR2,
                                       pv_consumer_name in varchar2 ,
                                       pv_alert_type IN VARCHAR2,
                                       pd_alert_start_date IN DATE,
                                       pd_alert_end_date IN DATE,
                                       pn_alert_frequency IN VARCHAR2,
                                       pv_err  out varchar2 );
                                  
    PROCEDURE PR_ALERT_GENERATE_PROCESS (pv_report_id IN VARCHAR2,
                                         pv_customer        IN VARCHAR2  
                                         );
    PROCEDURE PR_INSERT_DEFAULT_ACC_ALERT (PV_REPORT_ID         IN VARCHAR2,
                                           pv_customer          IN VARCHAR2 );                                      
    
    PROCEDURE PR_INSERT_SKIP_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                         pv_customer          IN VARCHAR2 );  
                                        
    PROCEDURE PR_INSERT_PAYMENT_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                            pv_customer          IN VARCHAR2 );                                                                                                                                                   

    PROCEDURE PR_INSERT_INQUIRY_ACC_ALERT ( pv_report_id         IN VARCHAR2,
                                            pv_customer          IN VARCHAR2 );                                                                                                                                                   

    PROCEDURE PR_INSERT_CLOSE_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                          pv_customer          IN VARCHAR2  );  
     
                                   
    PROCEDURE PR_INSERT_DISBURSE_ACC_ALERT (  PV_REPORT_ID         IN VARCHAR2,
                                              pv_customer          IN VARCHAR2 );  

    PROCEDURE PR_INSERT_UTILISE_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                            pv_customer          IN VARCHAR2 );  

    PROCEDURE PR_INSERT_UTILISE_R_ACC_ALERT ( PV_REPORT_ID         IN VARCHAR2,
                                             pv_customer          IN VARCHAR2 );                                  
   
    FUNCTION FN_FIND_RUNNING_DPD (pv_payment_history IN VARCHAR2,
                                  pv_ot_dpd          IN VARCHAR2)
    RETURN NUMBER;
       
    PROCEDURE PR_ALERT_OUT_PROCESS  ( pv_report_id          IN VARCHAR2, 
                                      pv_alertout           OUT CUR_SELECT,
                                      pv_err                OUT VARCHAR2,
                                      pv_consumer_name      OUT VARCHAR2,
                                      pv_back_dt            IN DATE DEFAULT NULL);                                 

END;

/*
CREATE SYNONYM APP_INQ_MATCH.PK_CNS_INQ_ALERT_PRODUCT_V1 FOR HMCORE.PK_CNS_INQ_ALERT_PRODUCT_V1;
GRANT EXECUTE ON HMCORE.PK_CNS_INQ_ALERT_PRODUCT_V1 TO RL_INQ_MATCH,APP_INQ_MATCH;

alter table HMCORE.CHM_MASTER_INQ_ALERT_DETAILS add ( response_frequency number);
alter table HMCORE.CHM_MASTER_INQ_ALERT_DETAILS add ( response_last_run_dt date);
alter table HMCORE.CHM_MASTER_INQ_ALERT_DETAILS add ( consumer_name VARCHAR2(1000));

*/

/
--------------------------------------------------------
--  DDL for Package PK_COMM_IOI_IOT_LOAD_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_COMM_IOI_IOT_LOAD_V1" 
AS 

   TYPE CUR_SELECT  IS REF CURSOR;
   GN_TOTAL_IOT_TABLE_CNT NUMBER := 3;
   gv_error_msg VARCHAR2(4000);
    
    PROCEDURE PR_CALL_IOT_BATCH( pn_batchid NUMBER,
                                 pv_file_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
    
    PROCEDURE PR_IOT_BATCH_ID_STATUS( pn_batchid NUMBER,
                                      pv_file_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
    
   /*PROCEDURE PR_PROD_MOVE_STD_CNS_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );*/

   PROCEDURE PR_PROD_MOVE_STD_CNS_CNS_IOT( 
                                           pn_batchid IN  NUMBER,
                                           pv_file_dir    IN VARCHAR2, 
                                           pv_log_file_name   IN VARCHAR2  
                                         );

/*   PROCEDURE PR_PROD_MOVE_STD_CNS_REL_IOT( 
                                           pn_batchid IN  NUMBER,
                                           pv_file_dir    IN VARCHAR2, 
                                           pv_log_file_name   IN VARCHAR2  
                                         );*/
                                      
   PROCEDURE PR_PROD_MOVE_STD_PHN_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );
                                     
   PROCEDURE PR_PROD_MOVE_STD_ADR_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );

    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );
                                      
END PK_COMM_IOI_IOT_LOAD_V1; 
 

/
--------------------------------------------------------
--  DDL for Package PK_COMM_IOI_LTC_LOAD_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_COMM_IOI_LTC_LOAD_V1" 
AS

    gv_error_msg VARCHAR2(4000);
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 18;
    GN_TOTAL_IOT_TABLE_CNT NUMBER := 3;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    GN_TOTAL_INQ_COUNT NUMBER := 0;
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pd_inq_from_dt      DATE,
                                    pd_inq_to_dt        DATE,
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pv_mfi_id           VARCHAR2 DEFAULT NULL,
                                    pn_node NUMBER DEFAULT 1
                                  );
                
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pd_inq_from_dt  DATE,
                                   pd_inq_to_dt    DATE,
                                   pn_batch_id     NUMBER,
                                   pv_temp_tbl     VARCHAR2,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1                                                               
                                 );

    PROCEDURE PR_LTC_BATCH_ID_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
                                    
    PROCEDURE PR_LTC_PARALLEL_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );

    PROCEDURE PR_CALL_LTC_BATCH( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
                                                              
    PROCEDURE PR_LTC_ID_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );                               
                              
    PROCEDURE PR_LTC_PHONE_CLUSTER( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
 
    PROCEDURE PR_LTC_SP_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SC_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SCL_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                ); 

    PROCEDURE PR_LTC_CNS_name_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );
 
    PROCEDURE PR_LTC_FULL_PHONE_CLUSTER( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );
 
    PROCEDURE PR_LTC_PHONE_LINK( pn_batch_id NUMBER,
                                 pn_total_job NUMBER,
                                 pn_mod NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );
   
    PROCEDURE PR_LTC_CNS_NAME_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_FULL_PHONE_LINK( pn_batch_id NUMBER,
                                      pn_total_job NUMBER,
                                      pn_mod NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );


    PROCEDURE PR_LTC_SP_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SC_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SCL_LINK( pn_batch_id NUMBER,
                               pn_total_job NUMBER,
                               pn_mod NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_ID_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

   

    PROCEDURE PR_LTC_NAME_PHN_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
    
    PROCEDURE PR_LTC_NAME_SC_LINK(  pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );                                  

    /*PROCEDURE PR_LTC_PIN_PHONE_LINK( pn_batch_id NUMBER,
                                     pn_total_job NUMBER,
                                     pn_mod NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                   );*/
 
    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );

END PK_COMM_IOI_LTC_LOAD_V1; 

/*
CREATE SYNONYM APP_INQ_MATCH.PK_COMM_IOI_LTC_LOAD_V1 FOR HMCORE.PK_COMM_IOI_LTC_LOAD_V1;

GRANT EXECUTE ON HMCORE.PK_COMM_IOI_LTC_LOAD_V1 TO app_inq_match,match,match_cp;
*/

/
--------------------------------------------------------
--  DDL for Package PK_CP_COM_IOI_BUREAU_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_COM_IOI_BUREAU_V1" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
     
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                         
  PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                                                     
    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER,
                                  pn_name_key_cnt NUMBER);
                                    
  

    PROCEDURE PR_NAME_SC_POOL(  pv_ltc_nm_sc VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_sc_count OUT NUMBER);
                          
    PROCEDURE PR_NAME_SP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_sp_count OUT NUMBER 
                           );

    PROCEDURE PR_NAME_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER,
                           pn_name_key_cnt NUMBER
                          );
                          
      

END PK_CP_com_IOI_BUREAU_V1; 


/*CREATE SYNONYM APP_INQ_MATCH.PK_CP_COM_IOI_BUREAU_V1 FOR HMCORE.PK_CP_COM_IOI_BUREAU_V1;
GRANT EXECUTE ON  HMCORE.PK_CP_COM_IOI_BUREAU_V1 TO RL_INQ_MATCH,MATCH,APP_INQ_MATCH,MATCH_CP;

CREATE SYNONYM APP_INQ_MATCH.PK_CP_COM_IOI_BUREAU_V1 FOR HMCORE.PK_CP_COM_IOI_BUREAU_V1;

GRANT EXECUTE ON HMCORE.PK_CP_COM_IOI_BUREAU_V1 TO RL_INQ_MATCH;

CREATE SYNONYM MATCH_CP.PK_CP_COM_IOI_BUREAU_V1 FOR HMCORE.PK_CP_COM_IOI_BUREAU_V1;

GRANT EXECUTE ON HMCORE.PK_CP_COM_IOI_BUREAU_V1 TO MATCH_CP;

CREATE SYNONYM MATCH.PK_CP_COM_IOI_BUREAU_V1 FOR HMCORE.PK_CP_COM_IOI_BUREAU_V1;

GRANT EXECUTE ON HMCORE.PK_CP_COM_IOI_BUREAU_V1 TO MATCH;
*/


 

/
--------------------------------------------------------
--  DDL for Package PK_CP_IOI_BUREAU_V11
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_IOI_BUREAU_V11" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
    PROCEDURE PR_RUN_NAME_DOB_POOL(pv_ltc_nm_comp_dob VARCHAR2,
                                   pv_inquiry_id VARCHAR2,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2,
                                   pv_log_flag VARCHAR2,
                                   pn_nm_comp_dob_count OUT NUMBER,
                                   pn_name_key_cnt NUMBER );
                                    
    PROCEDURE PR_NAME_DOB_DIST_POOL(pv_ltc_nm_sc_part_dob VARCHAR2,
                                    pv_ltc_nm_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_nm_part_dob_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_NAME_AGE_POOL(pv_ltc_nm_sc_age VARCHAR2,
                               pv_ltc_nm_pin_age VARCHAR2,
                               pv_inquiry_id VARCHAR2,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2,
                               pv_log_flag VARCHAR2,
                               pn_nage_count OUT NUMBER,
                               pn_name_key_cnt NUMBER );

    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER,
                                  pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                        
    PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                            
    PROCEDURE PR_PHONE_DOB_POOL ( pv_ltc_phone_part_dob VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

                                
    PROCEDURE PR_PHONE_AGE_POOL ( pv_ltc_phone_age VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

    PROCEDURE PR_NAME_RELATION_POOL(pv_ltc_nm_sc_rel VARCHAR2,
                                    pv_ltc_nm_pin_rel VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    ln_nm_rel_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER,
                                    pn_rel_key_cnt NUMBER
                                   );

    PROCEDURE PR_SCP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scp_count OUT NUMBER 
                           );

    PROCEDURE PR_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER,
                           pn_name_key_cnt NUMBER
                          );
                          
    PROCEDURE PR_PIN_PART_DOB_POOL( pv_ltc_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_pin_part_dob_count OUT NUMBER
                                   );

    PROCEDURE PR_PIN_PHONE_POOL( pv_ltc_pin_phone VARCHAR2,
                                 pv_inquiry_id VARCHAR2,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pv_log_flag VARCHAR2,
                                 pn_pin_phone_count OUT NUMBER
                                );

    PROCEDURE PR_TEXT_POOL( pv_str_all_val_clns_std VARCHAR2,
                            pv_str_statecode VARCHAR2,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2
                          );

END PK_CP_IOI_BUREAU_V11; 

/
--------------------------------------------------------
--  DDL for Package PK_CP_IOI_BUREAU_V12
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_IOI_BUREAU_V12" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
    PROCEDURE PR_RUN_NAME_DOB_POOL(pv_ltc_nm_comp_dob VARCHAR2,
                                   pv_inquiry_id VARCHAR2,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2,
                                   pv_log_flag VARCHAR2,
                                   pn_nm_comp_dob_count OUT NUMBER,
                                   pn_name_key_cnt NUMBER );
                                    
    PROCEDURE PR_NAME_DOB_DIST_POOL(pv_ltc_nm_sc_part_dob VARCHAR2,
                                    pv_ltc_nm_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_nm_part_dob_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_NAME_AGE_POOL(pv_ltc_nm_sc_age VARCHAR2,
                               pv_ltc_nm_pin_age VARCHAR2,
                               pv_inquiry_id VARCHAR2,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2,
                               pv_log_flag VARCHAR2,
                               pn_nage_count OUT NUMBER,
                               pn_name_key_cnt NUMBER );

    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER,
                                  pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                        
    PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                            
    PROCEDURE PR_PHONE_DOB_POOL ( pv_ltc_phone_part_dob VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

                                
    PROCEDURE PR_PHONE_AGE_POOL ( pv_ltc_phone_age VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

    PROCEDURE PR_NAME_RELATION_POOL(pv_ltc_nm_sc_rel VARCHAR2,
                                    pv_ltc_nm_pin_rel VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    ln_nm_rel_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER,
                                    pn_rel_key_cnt NUMBER
                                   );

    PROCEDURE PR_SCP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scp_count OUT NUMBER 
                           );

    PROCEDURE PR_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER,
                           pn_name_key_cnt NUMBER
                          );
                          
    PROCEDURE PR_PIN_PART_DOB_POOL( pv_ltc_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_pin_part_dob_count OUT NUMBER
                                   );

    PROCEDURE PR_PIN_PHONE_POOL( pv_ltc_pin_phone VARCHAR2,
                                 pv_inquiry_id VARCHAR2,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pv_log_flag VARCHAR2,
                                 pn_pin_phone_count OUT NUMBER
                                );

    PROCEDURE PR_TEXT_POOL( pv_str_all_val_clns_std VARCHAR2,
                            pv_str_statecode VARCHAR2,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2
                          );

END PK_CP_IOI_BUREAU_V12; 

/
--------------------------------------------------------
--  DDL for Package PK_CP_IOI_BUREAU_V13
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_IOI_BUREAU_V13" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
    PROCEDURE PR_RUN_NAME_DOB_POOL(pv_ltc_nm_comp_dob VARCHAR2,
                                   pv_inquiry_id VARCHAR2,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2,
                                   pv_log_flag VARCHAR2,
                                   pn_nm_comp_dob_count OUT NUMBER,
                                   pn_name_key_cnt NUMBER );
                                    
    PROCEDURE PR_NAME_DOB_DIST_POOL(pv_ltc_nm_sc_part_dob VARCHAR2,
                                    pv_ltc_nm_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_nm_part_dob_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_NAME_AGE_POOL(pv_ltc_nm_sc_age VARCHAR2,
                               pv_ltc_nm_pin_age VARCHAR2,
                               pv_inquiry_id VARCHAR2,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2,
                               pv_log_flag VARCHAR2,
                               pn_nage_count OUT NUMBER,
                               pn_name_key_cnt NUMBER );

    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER,
                                  pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                        
    PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                            
    PROCEDURE PR_PHONE_DOB_POOL ( pv_ltc_phone_part_dob VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

                                
    PROCEDURE PR_PHONE_AGE_POOL ( pv_ltc_phone_age VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

    PROCEDURE PR_NAME_RELATION_POOL(pv_ltc_nm_sc_rel VARCHAR2,
                                    pv_ltc_nm_pin_rel VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    ln_nm_rel_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER,
                                    pn_rel_key_cnt NUMBER
                                   );

    PROCEDURE PR_SCP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scp_count OUT NUMBER 
                           );

    PROCEDURE PR_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER,
                           pn_name_key_cnt NUMBER
                          );
                          
    PROCEDURE PR_PIN_PART_DOB_POOL( pv_ltc_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_pin_part_dob_count OUT NUMBER
                                   );

    PROCEDURE PR_PIN_PHONE_POOL( pv_ltc_pin_phone VARCHAR2,
                                 pv_inquiry_id VARCHAR2,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pv_log_flag VARCHAR2,
                                 pn_pin_phone_count OUT NUMBER
                                );

    PROCEDURE PR_TEXT_POOL( pv_str_all_val_clns_std VARCHAR2,
                            pv_str_statecode VARCHAR2,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2
                          );

END PK_CP_IOI_BUREAU_V13; 



/*
CREATE SYNONYM APP_INQ_MATCH.PK_CP_IOI_BUREAU_V13 FOR HMCORE.PK_CP_IOI_BUREAU_V13;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V13 TO RL_INQ_MATCH;

CREATE SYNONYM MATCH_CP.PK_CP_IOI_BUREAU_V13 FOR HMCORE.PK_CP_IOI_BUREAU_V13;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V13 TO MATCH_CP;

CREATE SYNONYM MATCH.PK_CP_IOI_BUREAU_V13 FOR HMCORE.PK_CP_IOI_BUREAU_V13;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V13 TO MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PK_CP_IOI_BUREAU_V14
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_IOI_BUREAU_V14" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
    PROCEDURE PR_RUN_NAME_DOB_POOL(pv_ltc_nm_comp_dob VARCHAR2,
                                   pv_inquiry_id VARCHAR2,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2,
                                   pv_log_flag VARCHAR2,
                                   pn_nm_comp_dob_count OUT NUMBER,
                                   pn_name_key_cnt NUMBER );
                                    
    PROCEDURE PR_NAME_DOB_DIST_POOL(pv_ltc_nm_sc_part_dob VARCHAR2,
                                    pv_ltc_nm_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_nm_part_dob_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_NAME_AGE_POOL(pv_ltc_nm_sc_age VARCHAR2,
                               pv_ltc_nm_pin_age VARCHAR2,
                               pv_inquiry_id VARCHAR2,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2,
                               pv_log_flag VARCHAR2,
                               pn_nage_count OUT NUMBER,
                               pn_name_key_cnt NUMBER );

    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER,
                                  pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                        
    PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                            
    PROCEDURE PR_PHONE_DOB_POOL ( pv_ltc_phone_part_dob VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

                                
    PROCEDURE PR_PHONE_AGE_POOL ( pv_ltc_phone_age VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

    PROCEDURE PR_NAME_RELATION_POOL(pv_ltc_nm_sc_rel VARCHAR2,
                                    pv_ltc_nm_pin_rel VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    ln_nm_rel_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER,
                                    pn_rel_key_cnt NUMBER
                                   );

    PROCEDURE PR_SCP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scp_count OUT NUMBER 
                           );

    PROCEDURE PR_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER,
                           pn_name_key_cnt NUMBER
                          );
                          
    PROCEDURE PR_PIN_PART_DOB_POOL( pv_ltc_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_pin_part_dob_count OUT NUMBER
                                   );

    PROCEDURE PR_PIN_PHONE_POOL( pv_ltc_pin_phone VARCHAR2,
                                 pv_inquiry_id VARCHAR2,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pv_log_flag VARCHAR2,
                                 pn_pin_phone_count OUT NUMBER
                                );

    PROCEDURE PR_TEXT_POOL( pv_str_all_val_clns_std VARCHAR2,
                            pv_str_statecode VARCHAR2,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2
                          );

END PK_CP_IOI_BUREAU_V14; 



/*
CREATE SYNONYM APP_INQ_MATCH.PK_CP_IOI_BUREAU_V14 FOR HMCORE.PK_CP_IOI_BUREAU_V14;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V14 TO RL_INQ_MATCH;

CREATE SYNONYM MATCH_CP.PK_CP_IOI_BUREAU_V14 FOR HMCORE.PK_CP_IOI_BUREAU_V14;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V14 TO MATCH_CP;

CREATE SYNONYM MATCH.PK_CP_IOI_BUREAU_V14 FOR HMCORE.PK_CP_IOI_BUREAU_V14;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V14 TO MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PK_CP_IOI_BUREAU_V15
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_IOI_BUREAU_V15" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
    PROCEDURE PR_RUN_NAME_DOB_POOL(pv_ltc_nm_comp_dob VARCHAR2,
                                   pv_inquiry_id VARCHAR2,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2,
                                   pv_log_flag VARCHAR2,
                                   pn_nm_comp_dob_count OUT NUMBER,
                                   pn_name_key_cnt NUMBER );
                                    
    PROCEDURE PR_NAME_DOB_DIST_POOL(pv_ltc_nm_sc_part_dob VARCHAR2,
                                    pv_ltc_nm_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_nm_part_dob_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_NAME_AGE_POOL(pv_ltc_nm_sc_age VARCHAR2,
                               pv_ltc_nm_pin_age VARCHAR2,
                               pv_inquiry_id VARCHAR2,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2,
                               pv_log_flag VARCHAR2,
                               pn_nage_count OUT NUMBER,
                               pn_name_key_cnt NUMBER );

    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER,
                                  pn_name_key_cnt NUMBER);
                                    
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                        
    PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                            
    PROCEDURE PR_PHONE_DOB_POOL ( pv_ltc_phone_part_dob VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

                                
    PROCEDURE PR_PHONE_AGE_POOL ( pv_ltc_phone_age VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

    PROCEDURE PR_NAME_RELATION_POOL(pv_ltc_nm_sc_rel VARCHAR2,
                                    pv_ltc_nm_pin_rel VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    ln_nm_rel_count OUT NUMBER,
                                    pn_name_key_cnt NUMBER,
                                    pn_rel_key_cnt NUMBER
                                   );

    PROCEDURE PR_SCP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scp_count OUT NUMBER 
                           );

    PROCEDURE PR_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER,
                           pn_name_key_cnt NUMBER
                          );
                          
    PROCEDURE PR_PIN_PART_DOB_POOL( pv_ltc_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_pin_part_dob_count OUT NUMBER
                                   );

    PROCEDURE PR_PIN_PHONE_POOL( pv_ltc_pin_phone VARCHAR2,
                                 pv_inquiry_id VARCHAR2,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pv_log_flag VARCHAR2,
                                 pn_pin_phone_count OUT NUMBER
                                );

    PROCEDURE PR_TEXT_POOL( pv_str_all_val_clns_std VARCHAR2,
                            pv_str_statecode VARCHAR2,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2
                          );

END PK_CP_IOI_BUREAU_V15; 



/*
CREATE SYNONYM APP_INQ_MATCH.PK_CP_IOI_BUREAU_V15 FOR HMCORE.PK_CP_IOI_BUREAU_V15;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V15 TO RL_INQ_MATCH;

CREATE SYNONYM MATCH_CP.PK_CP_IOI_BUREAU_V15 FOR HMCORE.PK_CP_IOI_BUREAU_V15;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V15 TO MATCH_CP;

CREATE SYNONYM MATCH.PK_CP_IOI_BUREAU_V15 FOR HMCORE.PK_CP_IOI_BUREAU_V15;

GRANT EXECUTE ON HMCORE.PK_CP_IOI_BUREAU_V15 TO MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PK_CP_L3_IOI_BUREAU_V11
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_CP_L3_IOI_BUREAU_V11" 
IS

    TYPE REF_CURSOR IS REF CURSOR; 
    
    gn_max_name_group           NUMBER ;
  
        
    PROCEDURE PR_CANDIDATE_POOL (
                                pv_name_keys          IN    VARCHAR2,
                                pv_rel_keys           IN    VARCHAR2,
                                pv_rel_type           IN    VARCHAR2,
                                pv_id                 IN    VARCHAR2,
                                pv_age_indicator      IN    VARCHAR2,
                                pv_dd                 IN    VARCHAR2,
                                pv_mm                 IN    VARCHAR2,
                                pv_cc                 IN    VARCHAR2,
                                pv_yy                 IN    VARCHAR2,
                                pv_phone_keys         IN    VARCHAR2,
                                pv_full_phone         IN    VARCHAR2,
                                pv_state              IN    VARCHAR2,
                                pv_city               IN    VARCHAR2,
                                pv_locality           IN    VARCHAR2,
                                pv_pin                IN    VARCHAR2,
                                pv_inquiry_id         IN    VARCHAR2,
                                pv_batch_indicator    IN    VARCHAR2,
                                pv_region             IN    VARCHAR2,
                                pv_search_scope       IN    VARCHAR2,
                                pv_quality_indicator  IN    VARCHAR2,
                                pv_batch_id           IN    VARCHAR2,
                                pc_inquirydata        IN    CLOB,
                                pv_error              OUT   VARCHAR2,
                                pt_ref_cur            OUT   REF_CURSOR,
                                pv_log_dir            IN    VARCHAR2 DEFAULT NULL,
                                pv_log_file_name      IN    VARCHAR2 DEFAULT NULL,
                                pv_log_flag           IN    BOOLEAN  DEFAULT FALSE                                
                              );
              
    PROCEDURE PR_RUN_NAME_DOB_POOL(pv_ltc_nm_comp_dob VARCHAR2,
                                   pv_inquiry_id VARCHAR2,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2,
                                   pv_log_flag VARCHAR2,
                                   pn_nm_comp_dob_count OUT NUMBER );
                                    
    PROCEDURE PR_NAME_DOB_DIST_POOL(pv_ltc_nm_sc_part_dob VARCHAR2,
                                    pv_ltc_nm_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_nm_part_dob_count OUT NUMBER);
                                    
    PROCEDURE PR_NAME_AGE_POOL(pv_ltc_nm_sc_age VARCHAR2,
                               pv_ltc_nm_pin_age VARCHAR2,
                               pv_inquiry_id VARCHAR2,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2,
                               pv_log_flag VARCHAR2,
                               pn_nage_count OUT NUMBER );

    PROCEDURE PR_NAME_PHONE_POOL( pv_ltc_nm_phone VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_nph_count OUT NUMBER);
                                    
    PROCEDURE PR_ID_POOL(   pv_ltc_id VARCHAR2,
                            pb_id_link_ind BOOLEAN,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2,
                            pn_id_count OUT NUMBER
                         );
                        
    PROCEDURE PR_FULL_PHONE_POOL(   pv_ltc_full_phone VARCHAR2,
                                    pb_full_phone_link_ind BOOLEAN,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_full_phone_count OUT NUMBER
                                );
                                            
    PROCEDURE PR_PHONE_DOB_POOL ( pv_ltc_phone_part_dob VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

                                
    PROCEDURE PR_PHONE_AGE_POOL ( pv_ltc_phone_age VARCHAR2,
                                  pv_inquiry_id VARCHAR2,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2,
                                  pv_log_flag VARCHAR2,
                                  pn_phage_count OUT NUMBER);

    PROCEDURE PR_NAME_RELATION_POOL(pv_ltc_nm_sc_rel VARCHAR2,
                                    pv_ltc_nm_pin_rel VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    ln_nm_rel_count OUT NUMBER
                                   );

    PROCEDURE PR_SCP_POOL( pv_ltc_nm_sp VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scp_count OUT NUMBER 
                           );

    PROCEDURE PR_SCL_POOL( pv_ltc_nm_scl VARCHAR2,
                           pv_inquiry_id VARCHAR2,
                           pv_log_dir VARCHAR2,
                           pv_log_file_name VARCHAR2,
                           pv_log_flag VARCHAR2,
                           pn_scl_count OUT NUMBER
                          );
                          
    PROCEDURE PR_PIN_PART_DOB_POOL( pv_ltc_pin_part_dob VARCHAR2,
                                    pv_inquiry_id VARCHAR2,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2,
                                    pv_log_flag VARCHAR2,
                                    pn_pin_part_dob_count OUT NUMBER
                                   );

    PROCEDURE PR_PIN_PHONE_POOL( pv_ltc_pin_phone VARCHAR2,
                                 pv_inquiry_id VARCHAR2,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pv_log_flag VARCHAR2,
                                 pn_pin_phone_count OUT NUMBER
                                );

    PROCEDURE PR_TEXT_POOL( pv_str_all_val_clns_std VARCHAR2,
                            pv_str_statecode VARCHAR2,
                            pv_inquiry_id VARCHAR2,
                            pv_log_dir VARCHAR2,
                            pv_log_file_name VARCHAR2,
                            pv_log_flag VARCHAR2
                          );

END PK_CP_L3_IOI_BUREAU_V11; 

/
--------------------------------------------------------
--  DDL for Package PK_DUMP_CREATION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_DUMP_CREATION" 
IS

    PROCEDURE PR_CNS_DUMP( pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_region VARCHAR2
                         );
                         
    PROCEDURE PR_CNS_FINAL_DUMP( pn_batch_id NUMBER,
                                 pv_region VARCHAR2
                               );
                         
    PROCEDURE PR_CREATE_EXT_TBL( pn_batch_id NUMBER,
                                 pv_region VARCHAR2
                               );
    
    PROCEDURE PR_DELETE_EXT_TBL( pn_batch_id NUMBER);

END; 

/
--------------------------------------------------------
--  DDL for Package PK_DUMP_CREATION_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_DUMP_CREATION_REPORT" 
IS

    PROCEDURE PR_CNS_DUMP( pv_report_id VARCHAR2,
                           pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_region VARCHAR2,
                           pv_cnd_scr_tbl_name VARCHAR2 DEFAULT 'HM_CAND_SCORE_LOG'
                         );
                         
    PROCEDURE PR_CNS_FINAL_DUMP( pv_report_id VARCHAR2,
                                 pn_batch_id NUMBER,
                                 pv_region VARCHAR2,
                                 pv_cnd_scr_tbl_name VARCHAR2 DEFAULT 'HM_CAND_SCORE_LOG'
                               );
                         
    PROCEDURE PR_CREATE_EXT_TBL( pn_batch_id NUMBER,
                                 pv_region VARCHAR2
                               );
    
    PROCEDURE PR_DELETE_EXT_TBL( pn_batch_id NUMBER);

END; 

/
--------------------------------------------------------
--  DDL for Package PK_DUMP_CREATION_REPORT_ID
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_DUMP_CREATION_REPORT_ID" 
IS

    PROCEDURE PR_CNS_DUMP( pv_report_id VARCHAR2,
                           pv_partition_name VARCHAR2,
                           pv_region VARCHAR2
                         );
                         
    PROCEDURE PR_CNS_FINAL_DUMP( pv_report_id VARCHAR2,
                                 pv_region VARCHAR2
                               );
                         
    PROCEDURE PR_CREATE_EXT_TBL( pn_batch_id NUMBER,
                                 pv_region VARCHAR2
                               );
    
    PROCEDURE PR_DELETE_EXT_TBL( pn_batch_id NUMBER);

END; 

/
--------------------------------------------------------
--  DDL for Package PK_DUMP_CREATION_REPORT_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_DUMP_CREATION_REPORT_V2" 
IS

    PROCEDURE PR_CNS_DUMP( pv_report_id VARCHAR2,
                           pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_region VARCHAR2
                         );
                         
    PROCEDURE PR_CNS_FINAL_DUMP( pv_report_id VARCHAR2,
                                 pn_batch_id NUMBER,
                                 pv_region VARCHAR2
                               );
                         
    PROCEDURE PR_CREATE_EXT_TBL( pn_batch_id NUMBER,
                                 pv_region VARCHAR2
                               );
    
    PROCEDURE PR_DELETE_EXT_TBL( pn_batch_id NUMBER);

END; 

/
--------------------------------------------------------
--  DDL for Package PK_INQUIRY_BILLING_V10
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_INQUIRY_BILLING_V10" 
AS
/*
    -- Determine the voucher type comparison to generate the csv based on the product type.
*/

    /*
        pv_exec_flag = 'COUNT' : This stage calculates the count for Inquiry and Portfolio and inserts this with the default values in the HM_BILLING_TRANSACTION Table.
        pv_exec_flag = 'BILL : This stage runs the Portfolio, Bulk / Alacarte modules as per the requirement and the commitment.
        pv_exec_flag = 'CSV' : This stage generates the Invoice and Appendix details required for the Final Bill generation
    */

    -- Procedure to execute the billing module MFI wise & Product wise.
    EX_VALID_DT_FAILED EXCEPTION;
    EX_TRNS_ID_VIOLATE EXCEPTION;
    TYPE REF_CURSOR IS REF CURSOR;
    
    gv_invoice_csv_file VARCHAR2(200) := 'Invoice_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';
    
    gv_appendix_csv_file VARCHAR2(200) := 'Appendix_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';

    -- Wrapper to run for all customers and products for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).       
    PROCEDURE PR_MFI_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_exec_flag       IN VARCHAR2,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_user_id         IN VARCHAR2,
                             pcur_out           OUT REF_CURSOR,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL,
                             pv_product_id      IN VARCHAR2 DEFAULT NULL
                            );

    PROCEDURE PR_CONTRACT_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL
                            );

    -- Wrapper procedure for specific customer and product for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).
    PROCEDURE PR_HM_INQUIRY_BILLING(pv_mfi_id        IN VARCHAR2,
                                    pd_inq_from_dt   IN DATE,
                                    pd_inq_to_dt     IN DATE,
                                    pv_product_id    IN VARCHAR2,
                                    pv_exec_flag     IN VARCHAR2,
                                    pn_pilot_flag    IN NUMBER,
                                    pn_chk_ext       IN NUMBER,
                                    pv_log_dir       IN VARCHAR2,
                                    pv_log_file      IN VARCHAR2,
                                    pd_valid_dt      IN DATE DEFAULT NULL
                                    );
                                
    --procedure to calculate total inquiry count and pilot_deduction count     
    PROCEDURE PR_CALC_INQ_CNT(pv_mfi_id         IN VARCHAR2,
                              pd_inq_from_dt    IN DATE,
                              pd_inq_to_dt      IN DATE,
                              pv_product_id     IN VARCHAR2,
                              lv_inq_dtl_tbl_nm IN VARCHAR2,
                              pv_log_dir        IN VARCHAR2,
                              pv_log_file       IN VARCHAR2);   
                                                                 
    -- Procedure to insert initial details and default values in HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_INIT_INSERT_BILL_TRNS(pn_trns_id       IN NUMBER,
                                       pv_mfi_id        IN VARCHAR2,
                                       pv_product_id    IN VARCHAR2,
                                       pd_inq_from_dt   IN DATE,
                                       pd_inq_to_dt     IN DATE,
                                       pn_bulk_cnt      IN NUMBER,
                                       pn_singltn_cnt   IN NUMBER,
                                       pn_inq_cnt       IN NUMBER,
                                       pn_elig_port_cnt IN NUMBER,
                                       pv_log_dir       IN VARCHAR2,
                                       pv_log_file      IN VARCHAR2,
                                       pv_from_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_to_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_time_slice_id IN NUMBER DEFAULT NULL
                                      );
                                    
    -- Procedure to calculate the alacarte count and bill for MFIs having no commitments.
    PROCEDURE PR_CALCULATE_ALACARTE(pn_trns_id      IN NUMBER,
                                    pn_pilot_flag   IN NUMBER,
                                    pd_valid_dt     IN DATE,
                                    pv_mfi_id       IN VARCHAR2,
                                    pv_product_id   IN VARCHAR2,
                                    pv_log_dir      IN VARCHAR2,
                                    pv_log_file     IN VARCHAR2);

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);

    PROCEDURE PR_BULK_BILLING_O(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);
                                   
    -- Function to calculate the ALACARTE bill.
    FUNCTION FN_CALCULATE_ALA_CARTE(pv_mfi_id      IN  VARCHAR2,
                                    pn_inq_count   IN  NUMBER,
                                    pn_trns_id     IN  NUMBER,
                                    pv_product_id  IN  VARCHAR2,
                                    pv_log_dir     IN  VARCHAR2,
                                    pv_log_file    IN  VARCHAR2)
    RETURN NUMBER;

    -- Procedure to calculate the total bill of Portfolio, Alacarte & Bulk and update to the HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_UPDATE_TOTAL_BILL(pn_trns_id  IN NUMBER,
                                   pv_log_dir  IN VARCHAR2,
                                   pv_log_file IN VARCHAR2);

    -- Procedure to generate the csv invoice for the MFI.
    PROCEDURE PR_GENERATE_INVOICE(pn_pilot_flag  IN NUMBER,
                                  pv_mfi_id      IN VARCHAR2,
                                  pv_product_id  IN VARCHAR2,
                                  pd_inq_from_dt IN DATE,
                                  pd_inq_to_dt   IN DATE,
                                  pd_valid_dt    IN DATE,
                                  pv_log_dir     IN VARCHAR2,
                                  pv_log_file    IN VARCHAR2);

    -- Procedure to generate Appendix csv for the MFI.
    PROCEDURE PR_GENERATE_APPENDIX_DETAILS(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_O(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    -- Procedure to build the HM_RATE_APPLY_SLABS table based on the HM_USER_COMMITMENTS table.
    PROCEDURE PR_RATE_APPLY_SLAB(pv_mfi_id          IN VARCHAR2,
                                 pv_product_id    IN VARCHAR2,
                                 pv_log_dir         IN VARCHAR2,
                                 pv_log_file        IN VARCHAR2);
                                 
    PROCEDURE PR_INSERT_COMMITMENT(pv_mfi_id          IN VARCHAR2,
                                   pv_product_id      IN VARCHAR2,
                                   pn_commit_ind      IN NUMBER,
                                   pn_commit_size     IN NUMBER,
                                   pd_commit_start_dt IN DATE,
                                   pd_commit_end_dt   IN DATE,
                                   pv_log_dir         IN VARCHAR2,
                                   pv_log_file        IN VARCHAR2,
                                   pv_user_id         IN VARCHAR2,
                                   pv_error           OUT VARCHAR2, 
                                   pn_rate            IN NUMBER
                                  );
                                  
    PROCEDURE PR_INSERT_UPDATE_RATE(pv_mfi_id   IN VARCHAR2,
                         pv_product_id IN VARCHAR2,
                         pv_bill_ind IN VARCHAR2,
                         pn_rate     IN NUMBER,
                         pv_log_dir  IN VARCHAR2,
                         pv_log_file IN VARCHAR2,
                         pv_user_id  IN VARCHAR2,
                         pv_error    OUT VARCHAR2
                      );

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING_TIME(
                                   pv_mfi_id      IN VARCHAR2,
                                   pv_product_id  IN VARCHAR2,
                                   pd_inq_from_dt IN DATE,
                                   pd_inq_to_dt   IN DATE,
                                   pv_log_dir     IN VARCHAR2,
                                   pv_log_file    IN VARCHAR2,
                                   pn_time_slice_id IN NUMBER
                                  );

    PROCEDURE PR_UPDATE_TOTAL_BILL_TIME(pv_mfi_id      IN VARCHAR2,
                                        pv_product_id  IN VARCHAR2,
                                        pd_inq_from_dt IN DATE,
                                        pd_inq_to_dt   IN DATE,
                                        pv_log_dir  IN VARCHAR2,
                                        pv_log_file IN VARCHAR2,
                                        pn_time_slice_id IN NUMBER
                                       );

    PROCEDURE PR_CALCULATE_ALACARTE_TIME(pn_pilot_flag   IN NUMBER,
                                         pd_valid_dt     IN DATE,
                                         pv_mfi_id       IN VARCHAR2,
                                         pv_product_id   IN VARCHAR2,
                                         pv_log_dir      IN VARCHAR2,
                                         pv_log_file     IN VARCHAR2,
                                         pd_inq_from_dt IN DATE,
                                         pd_inq_to_dt   IN DATE,
                                         pn_time_slice_id IN NUMBER
                                        );

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_T(   
                                             pv_mfi_id        IN VARCHAR2,
                                             pv_product_id    IN VARCHAR2,
                                             pd_inq_from_dt   IN DATE,
                                             pd_inq_to_dt     IN DATE,
                                             pv_log_dir       IN VARCHAR2,
                                             pv_log_file      IN VARCHAR2
                                            );
    
    PROCEDURE PR_DELETE_BILLING_TRANS(
                                        pd_inq_from_dt   IN DATE,
                                        pd_inq_to_dt     IN DATE,
                                        pv_log_dir       IN VARCHAR2,
                                        pv_log_file      IN VARCHAR2,
                                        pv_mfi_id        IN VARCHAR2 DEFAULT NULL,
                                        pv_product_id    IN VARCHAR2 DEFAULT NULL
                                     );
                                     
    PROCEDURE PR_INSERT_TIME_SLICE (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_inq_from_tm     IN VARCHAR2,
                                        pv_inq_to_tm       IN VARCHAR2,
                                        pv_log_dir         IN VARCHAR2,
                                        pv_log_file        IN VARCHAR2,
                                        pv_time_slice_size IN VARCHAR2,
                                        pv_rate            IN VARCHAR2
                                   );

    PROCEDURE PR_INSERT_UPDATE_BILLING_TYPE (
                                                pv_mfi_id          IN VARCHAR2,
                                                pv_product_id      IN VARCHAR2,
                                                pv_action          IN VARCHAR2,
                                                pn_active          IN NUMBER,
                                                pv_user_id         IN VARCHAR2,
                                                pv_error           OUT VARCHAR2
                                            );

    PROCEDURE PR_INSERT_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pn_bill            IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_UPDATE_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_update          IN VARCHAR2,
                                        pn_bill_active     IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_AUTO_UPDT_BILLING_CENTRAL(
                                            pd_inq_from_dt     IN DATE,
                                            pd_inq_to_dt       IN DATE,                                            
                                            pv_log_dir         IN VARCHAR2,
                                            pv_log_file        IN VARCHAR2
                                          );
                                          
                                                                             
END PK_INQUIRY_BILLING_V10; 


/*CREATE SYNONYM APP_BILLING.PK_INQUIRY_BILLING_V10 FOR HMCORE.PK_INQUIRY_BILLING_V10;

GRANT EXECUTE ON HMCORE.PK_INQUIRY_BILLING_V10 TO RL_BILLING;*/

/
--------------------------------------------------------
--  DDL for Package PK_INQUIRY_BILLING_V11
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_INQUIRY_BILLING_V11" 
AS
/*
    -- Determine the voucher type comparison to generate the csv based on the product type.
*/

    /*
        pv_exec_flag = 'COUNT' : This stage calculates the count for Inquiry and Portfolio and inserts this with the default values in the HM_BILLING_TRANSACTION Table.
        pv_exec_flag = 'BILL : This stage runs the Portfolio, Bulk / Alacarte modules as per the requirement and the commitment.
        pv_exec_flag = 'CSV' : This stage generates the Invoice and Appendix details required for the Final Bill generation
    */

    -- Procedure to execute the billing module MFI wise & Product wise.
    EX_VALID_DT_FAILED EXCEPTION;
    EX_TRNS_ID_VIOLATE EXCEPTION;

    TYPE REF_CURSOR IS REF CURSOR;
    
    gv_invoice_csv_file VARCHAR2(200) := 'Invoice_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';
    
    gv_appendix_csv_file VARCHAR2(200) := 'Appendix_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';

    -- Wrapper to run for all customers and products for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).       
    PROCEDURE PR_MFI_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_exec_flag       IN VARCHAR2,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_user_id         IN VARCHAR2,
                             pcur_out           OUT REF_CURSOR,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL,
                             pv_product_id      IN VARCHAR2 DEFAULT NULL
                            );

    PROCEDURE PR_CONTRACT_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL
                            );

    -- Wrapper procedure for specific customer and product for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).
    PROCEDURE PR_HM_INQUIRY_BILLING(pv_mfi_id        IN VARCHAR2,
                                    pd_inq_from_dt   IN DATE,
                                    pd_inq_to_dt     IN DATE,
                                    pv_product_id    IN VARCHAR2,
                                    pv_product_ver   IN VARCHAR2,
                                    pv_exec_flag     IN VARCHAR2,
                                    pn_pilot_flag    IN NUMBER,
                                    pn_chk_ext       IN NUMBER,
                                    pv_log_dir       IN VARCHAR2,
                                    pv_log_file      IN VARCHAR2,
                                    pd_valid_dt      IN DATE DEFAULT NULL
                                    );
                                
    --procedure to calculate total inquiry count and pilot_deduction count     
    PROCEDURE PR_CALC_INQ_CNT(pv_mfi_id         IN VARCHAR2,
                              pd_inq_from_dt    IN DATE,
                              pd_inq_to_dt      IN DATE,
                              pv_product_id     IN VARCHAR2,
                              pv_product_ver    IN VARCHAR2,
                              pv_log_dir        IN VARCHAR2,
                              pv_log_file       IN VARCHAR2,
                              pv_bill_scheme    IN VARCHAR2,
                              pd_pilot_end_dt   IN DATE,
                              pn_new_commit_id  IN NUMBER,
                              pn_old_commit_id  IN NUMBER,
                              pn_time_slice_id  IN NUMBER
                             );   
                                                                 
    -- Procedure to calculate the alacarte count and bill for MFIs having no commitments.
    PROCEDURE PR_CALCULATE_ALACARTE(pn_trns_id      IN NUMBER,
                                    pn_pilot_flag   IN NUMBER,
                                    pd_valid_dt     IN DATE,
                                    pv_mfi_id       IN VARCHAR2,
                                    pv_product_id   IN VARCHAR2,
                                    pv_product_ver  IN VARCHAR2,
                                    pv_log_dir      IN VARCHAR2,
                                    pv_log_file     IN VARCHAR2);

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pv_product_ver IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);

    PROCEDURE PR_BULK_BILLING_O(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pv_product_ver IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);
                                   
    -- Function to calculate the ALACARTE bill.
    FUNCTION FN_CALCULATE_ALA_CARTE(pv_mfi_id      IN  VARCHAR2,
                                    pn_inq_count   IN  NUMBER,
                                    pn_trns_id     IN  NUMBER,
                                    pv_product_id  IN  VARCHAR2,
                                    pv_product_ver IN  VARCHAR2,
                                    pv_log_dir     IN  VARCHAR2,
                                    pv_log_file    IN  VARCHAR2)
    RETURN NUMBER;

    -- Procedure to calculate the total bill of Portfolio, Alacarte & Bulk and update to the HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_UPDATE_TOTAL_BILL(pn_trns_id  IN NUMBER,
                                   pv_log_dir  IN VARCHAR2,
                                   pv_log_file IN VARCHAR2);

    -- Procedure to generate the csv invoice for the MFI.
    PROCEDURE PR_GENERATE_INVOICE(pn_pilot_flag  IN NUMBER,
                                  pv_mfi_id      IN VARCHAR2,
                                  pv_product_id  IN VARCHAR2,
                                  pv_product_ver IN VARCHAR2,
                                  pd_inq_from_dt IN DATE,
                                  pd_inq_to_dt   IN DATE,
                                  pd_valid_dt    IN DATE,
                                  pv_log_dir     IN VARCHAR2,
                                  pv_log_file    IN VARCHAR2);

    -- Procedure to generate Appendix csv for the MFI.
    PROCEDURE PR_GENERATE_APPENDIX_DETAILS(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pv_product_ver   IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_O(pn_trns_id     IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pv_product_ver   IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    -- Procedure to build the HM_RATE_APPLY_SLABS table based on the HM_USER_COMMITMENTS table.
    PROCEDURE PR_RATE_APPLY_SLAB(pv_mfi_id          IN VARCHAR2,
                                 pv_product_id      IN VARCHAR2,
                                 pn_cmt_id          IN NUMBER,
                                 pv_log_dir         IN VARCHAR2,
                                 pv_log_file        IN VARCHAR2);
                                 
    PROCEDURE PR_INSERT_COMMITMENT(pv_mfi_id          IN VARCHAR2,
                                   pv_product_id      IN VARCHAR2,
                                   pn_commit_ind      IN NUMBER,
                                   pn_commit_size     IN NUMBER,
                                   pd_commit_start_dt IN DATE,
                                   pd_commit_end_dt   IN DATE,
                                   pv_log_dir         IN VARCHAR2,
                                   pv_log_file        IN VARCHAR2,
                                   pv_user_id         IN VARCHAR2,
                                   pv_error           OUT VARCHAR2, 
                                   pn_rate            IN NUMBER,
                                   pv_product_ver     IN VARCHAR2 DEFAULT NULL
                                  );
                                  
    PROCEDURE PR_INSERT_UPDATE_RATE(pv_mfi_id   IN VARCHAR2,
                         pv_product_id IN VARCHAR2,
                         pv_bill_ind IN VARCHAR2,
                         pn_rate     IN NUMBER,
                         pv_log_dir  IN VARCHAR2,
                         pv_log_file IN VARCHAR2,
                         pv_user_id  IN VARCHAR2,
                         pv_error    OUT VARCHAR2
                      );

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING_TIME(
                                   pv_mfi_id      IN VARCHAR2,
                                   pv_product_id  IN VARCHAR2,
                                   pv_product_ver IN VARCHAR2,
                                   pd_inq_from_dt IN DATE,
                                   pd_inq_to_dt   IN DATE,
                                   pv_log_dir     IN VARCHAR2,
                                   pv_log_file    IN VARCHAR2,
                                   pn_time_slice_id IN NUMBER
                                  );

    PROCEDURE PR_UPDATE_TOTAL_BILL_TIME(pv_mfi_id      IN VARCHAR2,
                                        pv_product_id  IN VARCHAR2,
                                        pv_product_ver IN VARCHAR2,
                                        pd_inq_from_dt IN DATE,
                                        pd_inq_to_dt   IN DATE,
                                        pv_log_dir  IN VARCHAR2,
                                        pv_log_file IN VARCHAR2,
                                        pn_time_slice_id IN NUMBER
                                       );

    PROCEDURE PR_CALCULATE_ALACARTE_TIME(pn_pilot_flag   IN NUMBER,
                                         pd_valid_dt     IN DATE,
                                         pv_mfi_id       IN VARCHAR2,
                                         pv_product_id   IN VARCHAR2,
                                         pv_product_ver  IN VARCHAR2,
                                         pv_log_dir      IN VARCHAR2,
                                         pv_log_file     IN VARCHAR2,
                                         pd_inq_from_dt IN DATE,
                                         pd_inq_to_dt   IN DATE,
                                         pn_time_slice_id IN NUMBER
                                        );

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_T(   
                                             pv_mfi_id        IN VARCHAR2,
                                             pv_product_id    IN VARCHAR2,
                                             pv_product_ver   IN VARCHAR2,
                                             pd_inq_from_dt   IN DATE,
                                             pd_inq_to_dt     IN DATE,
                                             pv_log_dir       IN VARCHAR2,
                                             pv_log_file      IN VARCHAR2
                                            );
    
    PROCEDURE PR_INSERT_TIME_SLICE (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_inq_from_tm     IN VARCHAR2,
                                        pv_inq_to_tm       IN VARCHAR2,
                                        pv_log_dir         IN VARCHAR2,
                                        pv_log_file        IN VARCHAR2,
                                        pv_time_slice_size IN VARCHAR2,
                                        pv_rate            IN VARCHAR2
                                   );

    PROCEDURE PR_AUTO_UPDT_BILLING_CENTRAL(
                                            pd_inq_from_dt     IN DATE,
                                            pd_inq_to_dt       IN DATE,                                            
                                            pv_log_dir         IN VARCHAR2,
                                            pv_log_file        IN VARCHAR2
                                          );
                                          
                                                                             
END PK_INQUIRY_BILLING_V11; 


/*CREATE SYNONYM APP_BILLING.PK_INQUIRY_BILLING_V11 FOR HMCORE.PK_INQUIRY_BILLING_V11;

GRANT EXECUTE ON HMCORE.PK_INQUIRY_BILLING_V11 TO RL_BILLING;*/

/
--------------------------------------------------------
--  DDL for Package PK_INQUIRY_BILLING_V12
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_INQUIRY_BILLING_V12" 
AS
/*
    -- Determine the voucher type comparison to generate the csv based on the product type.
*/

    /*
        pv_exec_flag = 'COUNT' : This stage calculates the count for Inquiry and Portfolio and inserts this with the default values in the HM_BILLING_TRANSACTION Table.
        pv_exec_flag = 'BILL : This stage runs the Portfolio, Bulk / Alacarte modules as per the requirement and the commitment.
        pv_exec_flag = 'CSV' : This stage generates the Invoice and Appendix details required for the Final Bill generation
    */

    -- Procedure to execute the billing module MFI wise & Product wise.
    EX_VALID_DT_FAILED EXCEPTION;
    EX_TRNS_ID_VIOLATE EXCEPTION;
    TYPE REF_CURSOR IS REF CURSOR;
    
    gv_invoice_csv_file VARCHAR2(200) := 'Invoice_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';
    
    gv_appendix_csv_file VARCHAR2(200) := 'Appendix_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';

    -- Wrapper to run for all customers and products for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).       
    PROCEDURE PR_MFI_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_exec_flag       IN VARCHAR2,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_user_id         IN VARCHAR2,
                             pcur_out           OUT REF_CURSOR,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL,
                             pv_product_id      IN VARCHAR2 DEFAULT NULL
                            );

    PROCEDURE PR_CONTRACT_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL
                            );

    -- Wrapper procedure for specific customer and product for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).
    PROCEDURE PR_HM_INQUIRY_BILLING(pv_mfi_id        IN VARCHAR2,
                                    pd_inq_from_dt   IN DATE,
                                    pd_inq_to_dt     IN DATE,
                                    pv_product_id    IN VARCHAR2,
                                    pv_exec_flag     IN VARCHAR2,
                                    pn_pilot_flag    IN NUMBER,
                                    pn_chk_ext       IN NUMBER,
                                    pv_log_dir       IN VARCHAR2,
                                    pv_log_file      IN VARCHAR2,
                                    pd_valid_dt      IN DATE DEFAULT NULL
                                    );
                                
    --procedure to calculate total inquiry count and pilot_deduction count     
    PROCEDURE PR_CALC_INQ_CNT(pv_mfi_id         IN VARCHAR2,
                              pd_inq_from_dt    IN DATE,
                              pd_inq_to_dt      IN DATE,
                              pv_product_id     IN VARCHAR2,
                              lv_inq_dtl_tbl_nm IN VARCHAR2,
                              pv_log_dir        IN VARCHAR2,
                              pv_log_file       IN VARCHAR2);   
                                                                 
    -- Procedure to insert initial details and default values in HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_INIT_INSERT_BILL_TRNS(pn_trns_id       IN NUMBER,
                                       pv_mfi_id        IN VARCHAR2,
                                       pv_product_id    IN VARCHAR2,
                                       pd_inq_from_dt   IN DATE,
                                       pd_inq_to_dt     IN DATE,
                                       pn_bulk_cnt      IN NUMBER,
                                       pn_singltn_cnt   IN NUMBER,
                                       pn_inq_cnt       IN NUMBER,
                                       pn_elig_port_cnt IN NUMBER,
                                       pv_log_dir       IN VARCHAR2,
                                       pv_log_file      IN VARCHAR2,
                                       pv_from_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_to_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_time_slice_id IN NUMBER DEFAULT NULL
                                      );
                                    
    -- Procedure to calculate the alacarte count and bill for MFIs having no commitments.
    PROCEDURE PR_CALCULATE_ALACARTE(pn_trns_id      IN NUMBER,
                                    pn_pilot_flag   IN NUMBER,
                                    pd_valid_dt     IN DATE,
                                    pv_mfi_id       IN VARCHAR2,
                                    pv_product_id   IN VARCHAR2,
                                    pv_log_dir      IN VARCHAR2,
                                    pv_log_file     IN VARCHAR2);

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);

    PROCEDURE PR_BULK_BILLING_O(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);
                                   
    -- Function to calculate the ALACARTE bill.
    FUNCTION FN_CALCULATE_ALA_CARTE(pv_mfi_id      IN  VARCHAR2,
                                    pn_inq_count   IN  NUMBER,
                                    pn_trns_id     IN  NUMBER,
                                    pv_product_id  IN  VARCHAR2,
                                    pv_log_dir     IN  VARCHAR2,
                                    pv_log_file    IN  VARCHAR2)
    RETURN NUMBER;

    -- Procedure to calculate the total bill of Portfolio, Alacarte & Bulk and update to the HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_UPDATE_TOTAL_BILL(pn_trns_id  IN NUMBER,
                                   pv_log_dir  IN VARCHAR2,
                                   pv_log_file IN VARCHAR2);

    -- Procedure to generate the csv invoice for the MFI.
    PROCEDURE PR_GENERATE_INVOICE(pn_pilot_flag  IN NUMBER,
                                  pv_mfi_id      IN VARCHAR2,
                                  pv_product_id  IN VARCHAR2,
                                  pd_inq_from_dt IN DATE,
                                  pd_inq_to_dt   IN DATE,
                                  pd_valid_dt    IN DATE,
                                  pv_log_dir     IN VARCHAR2,
                                  pv_log_file    IN VARCHAR2);

    -- Procedure to generate Appendix csv for the MFI.
    PROCEDURE PR_GENERATE_APPENDIX_DETAILS(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_O(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    -- Procedure to build the HM_RATE_APPLY_SLABS table based on the HM_USER_COMMITMENTS table.
    PROCEDURE PR_RATE_APPLY_SLAB(pv_mfi_id          IN VARCHAR2,
                                 pv_product_id    IN VARCHAR2,
                                 pv_log_dir         IN VARCHAR2,
                                 pv_log_file        IN VARCHAR2);
                                 
    PROCEDURE PR_INSERT_COMMITMENT(pv_mfi_id          IN VARCHAR2,
                                   pv_product_id      IN VARCHAR2,
                                   pn_commit_ind      IN NUMBER,
                                   pn_commit_size     IN NUMBER,
                                   pd_commit_start_dt IN DATE,
                                   pd_commit_end_dt   IN DATE,
                                   pv_log_dir         IN VARCHAR2,
                                   pv_log_file        IN VARCHAR2,
                                   pv_user_id         IN VARCHAR2,
                                   pv_error           OUT VARCHAR2, 
                                   pn_rate            IN NUMBER
                                  );
                                  
    PROCEDURE PR_INSERT_UPDATE_RATE(pv_mfi_id   IN VARCHAR2,
                         pv_product_id IN VARCHAR2,
                         pv_bill_ind IN VARCHAR2,
                         pn_rate     IN NUMBER,
                         pv_log_dir  IN VARCHAR2,
                         pv_log_file IN VARCHAR2,
                         pv_user_id  IN VARCHAR2,
                         pv_error    OUT VARCHAR2
                      );

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING_TIME(
                                   pv_mfi_id      IN VARCHAR2,
                                   pv_product_id  IN VARCHAR2,
                                   pd_inq_from_dt IN DATE,
                                   pd_inq_to_dt   IN DATE,
                                   pv_log_dir     IN VARCHAR2,
                                   pv_log_file    IN VARCHAR2,
                                   pn_time_slice_id IN NUMBER
                                  );

    PROCEDURE PR_UPDATE_TOTAL_BILL_TIME(pv_mfi_id      IN VARCHAR2,
                                        pv_product_id  IN VARCHAR2,
                                        pd_inq_from_dt IN DATE,
                                        pd_inq_to_dt   IN DATE,
                                        pv_log_dir  IN VARCHAR2,
                                        pv_log_file IN VARCHAR2,
                                        pn_time_slice_id IN NUMBER
                                       );

    PROCEDURE PR_CALCULATE_ALACARTE_TIME(pn_pilot_flag   IN NUMBER,
                                         pd_valid_dt     IN DATE,
                                         pv_mfi_id       IN VARCHAR2,
                                         pv_product_id   IN VARCHAR2,
                                         pv_log_dir      IN VARCHAR2,
                                         pv_log_file     IN VARCHAR2,
                                         pd_inq_from_dt IN DATE,
                                         pd_inq_to_dt   IN DATE,
                                         pn_time_slice_id IN NUMBER
                                        );

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_T(   
                                             pv_mfi_id        IN VARCHAR2,
                                             pv_product_id    IN VARCHAR2,
                                             pd_inq_from_dt   IN DATE,
                                             pd_inq_to_dt     IN DATE,
                                             pv_log_dir       IN VARCHAR2,
                                             pv_log_file      IN VARCHAR2
                                            );
    
    PROCEDURE PR_DELETE_BILLING_TRANS(
                                        pd_inq_from_dt   IN DATE,
                                        pd_inq_to_dt     IN DATE,
                                        pv_log_dir       IN VARCHAR2,
                                        pv_log_file      IN VARCHAR2,
                                        pv_mfi_id        IN VARCHAR2 DEFAULT NULL,
                                        pv_product_id    IN VARCHAR2 DEFAULT NULL
                                     );
                                     
    PROCEDURE PR_INSERT_TIME_SLICE (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_inq_from_tm     IN VARCHAR2,
                                        pv_inq_to_tm       IN VARCHAR2,
                                        pv_log_dir         IN VARCHAR2,
                                        pv_log_file        IN VARCHAR2,
                                        pv_time_slice_size IN VARCHAR2,
                                        pv_rate            IN VARCHAR2
                                   );

    PROCEDURE PR_INSERT_UPDATE_BILLING_TYPE (
                                                pv_mfi_id          IN VARCHAR2,
                                                pv_product_id      IN VARCHAR2,
                                                pv_action          IN VARCHAR2,
                                                pn_active          IN NUMBER,
                                                pv_user_id         IN VARCHAR2,
                                                pv_error           OUT VARCHAR2
                                            );

    PROCEDURE PR_INSERT_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pn_bill            IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_UPDATE_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_update          IN VARCHAR2,
                                        pn_bill_active     IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_AUTO_UPDT_BILLING_CENTRAL(
                                            pd_inq_from_dt     IN DATE,
                                            pd_inq_to_dt       IN DATE,                                            
                                            pv_log_dir         IN VARCHAR2,
                                            pv_log_file        IN VARCHAR2
                                          );
                                          
                                                                             
END PK_INQUIRY_BILLING_V12; 


/*CREATE SYNONYM APP_BILLING.PK_INQUIRY_BILLING_V12 FOR HMCORE.PK_INQUIRY_BILLING_V12;

GRANT EXECUTE ON HMCORE.PK_INQUIRY_BILLING_V12 TO RL_BILLING;*/

/
--------------------------------------------------------
--  DDL for Package PK_INQUIRY_BILLING_V13
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_INQUIRY_BILLING_V13" 
AS
/*
    -- Determine the voucher type comparison to generate the csv based on the product type.
*/

    /*
        pv_exec_flag = 'COUNT' : This stage calculates the count for Inquiry and Portfolio and inserts this with the default values in the HM_BILLING_TRANSACTION Table.
        pv_exec_flag = 'BILL : This stage runs the Portfolio, Bulk / Alacarte modules as per the requirement and the commitment.
        pv_exec_flag = 'CSV' : This stage generates the Invoice and Appendix details required for the Final Bill generation
    */

    -- Procedure to execute the billing module MFI wise & Product wise.
    EX_VALID_DT_FAILED EXCEPTION;
    EX_TRNS_ID_VIOLATE EXCEPTION;

    TYPE REF_CURSOR IS REF CURSOR;
    
    gv_invoice_csv_file VARCHAR2(200) := 'Invoice_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';
    
    gv_appendix_csv_file VARCHAR2(200) := 'Appendix_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';

    -- Wrapper to run for all customers and products for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).       
    PROCEDURE PR_MFI_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_exec_flag       IN VARCHAR2,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_user_id         IN VARCHAR2,
                             pcur_out           OUT REF_CURSOR,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL,
                             pv_product_id      IN VARCHAR2 DEFAULT NULL
                            );

    PROCEDURE PR_CONTRACT_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL
                            );

    -- Wrapper procedure for specific customer and product for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).
    PROCEDURE PR_HM_INQUIRY_BILLING(pv_mfi_id        IN VARCHAR2,
                                    pd_inq_from_dt   IN DATE,
                                    pd_inq_to_dt     IN DATE,
                                    pv_product_id    IN VARCHAR2,
                                    pv_product_ver   IN VARCHAR2,
                                    pv_exec_flag     IN VARCHAR2,
                                    pn_pilot_flag    IN NUMBER,
                                    pn_chk_ext       IN NUMBER,
                                    pv_log_dir       IN VARCHAR2,
                                    pv_log_file      IN VARCHAR2,
                                    pd_valid_dt      IN DATE DEFAULT NULL
                                    );
                                
    --procedure to calculate total inquiry count and pilot_deduction count     
    PROCEDURE PR_CALC_INQ_CNT(pv_mfi_id         IN VARCHAR2,
                              pd_inq_from_dt    IN DATE,
                              pd_inq_to_dt      IN DATE,
                              pv_product_id     IN VARCHAR2,
                              pv_product_ver    IN VARCHAR2,
                              pv_log_dir        IN VARCHAR2,
                              pv_log_file       IN VARCHAR2,
                              pv_bill_scheme    IN VARCHAR2,
                              pd_pilot_end_dt   IN DATE,
                              pn_new_commit_id  IN NUMBER,
                              pn_old_commit_id  IN NUMBER,
                              pn_time_slice_id  IN NUMBER
                             );   
                                                                 
    -- Procedure to calculate the alacarte count and bill for MFIs having no commitments.
    PROCEDURE PR_CALCULATE_ALACARTE(pn_trns_id      IN NUMBER,
                                    pn_pilot_flag   IN NUMBER,
                                    pd_valid_dt     IN DATE,
                                    pv_mfi_id       IN VARCHAR2,
                                    pv_product_id   IN VARCHAR2,
                                    pv_product_ver  IN VARCHAR2,
                                    pv_log_dir      IN VARCHAR2,
                                    pv_log_file     IN VARCHAR2);

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pv_product_ver IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);

    PROCEDURE PR_BULK_BILLING_O(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pv_product_ver IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);
                                   
    -- Function to calculate the ALACARTE bill.
    FUNCTION FN_CALCULATE_ALA_CARTE(pv_mfi_id      IN  VARCHAR2,
                                    pn_inq_count   IN  NUMBER,
                                    pn_trns_id     IN  NUMBER,
                                    pv_product_id  IN  VARCHAR2,
                                    pv_product_ver IN  VARCHAR2,
                                    pv_log_dir     IN  VARCHAR2,
                                    pv_log_file    IN  VARCHAR2)
    RETURN NUMBER;

    -- Procedure to calculate the total bill of Portfolio, Alacarte & Bulk and update to the HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_UPDATE_TOTAL_BILL(pn_trns_id  IN NUMBER,
                                   pv_log_dir  IN VARCHAR2,
                                   pv_log_file IN VARCHAR2);

    -- Procedure to generate the csv invoice for the MFI.
    PROCEDURE PR_GENERATE_INVOICE(pn_pilot_flag  IN NUMBER,
                                  pv_mfi_id      IN VARCHAR2,
                                  pv_product_id  IN VARCHAR2,
                                  pv_product_ver IN VARCHAR2,
                                  pd_inq_from_dt IN DATE,
                                  pd_inq_to_dt   IN DATE,
                                  pd_valid_dt    IN DATE,
                                  pv_log_dir     IN VARCHAR2,
                                  pv_log_file    IN VARCHAR2);

    -- Procedure to generate Appendix csv for the MFI.
    PROCEDURE PR_GENERATE_APPENDIX_DETAILS(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pv_product_ver   IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_O(pn_trns_id     IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pv_product_ver   IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    -- Procedure to build the HM_RATE_APPLY_SLABS table based on the HM_USER_COMMITMENTS table.
    PROCEDURE PR_RATE_APPLY_SLAB(pv_mfi_id          IN VARCHAR2,
                                 pv_product_id      IN VARCHAR2,
                                 pn_cmt_id          IN NUMBER,
                                 pv_log_dir         IN VARCHAR2,
                                 pv_log_file        IN VARCHAR2);
                                 
    PROCEDURE PR_INSERT_COMMITMENT(pv_mfi_id          IN VARCHAR2,
                                   pv_product_id      IN VARCHAR2,
                                   pn_commit_ind      IN NUMBER,
                                   pn_commit_size     IN NUMBER,
                                   pd_commit_start_dt IN DATE,
                                   pd_commit_end_dt   IN DATE,
                                   pv_log_dir         IN VARCHAR2,
                                   pv_log_file        IN VARCHAR2,
                                   pv_user_id         IN VARCHAR2,
                                   pv_error           OUT VARCHAR2, 
                                   pn_rate            IN NUMBER,
                                   pv_product_ver     IN VARCHAR2 DEFAULT NULL
                                  );
                                  
    PROCEDURE PR_INSERT_UPDATE_RATE(pv_mfi_id   IN VARCHAR2,
                         pv_product_id IN VARCHAR2,
                         pv_bill_ind IN VARCHAR2,
                         pn_rate     IN NUMBER,
                         pv_log_dir  IN VARCHAR2,
                         pv_log_file IN VARCHAR2,
                         pv_user_id  IN VARCHAR2,
                         pv_error    OUT VARCHAR2
                      );

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING_TIME(
                                   pv_mfi_id      IN VARCHAR2,
                                   pv_product_id  IN VARCHAR2,
                                   pv_product_ver IN VARCHAR2,
                                   pd_inq_from_dt IN DATE,
                                   pd_inq_to_dt   IN DATE,
                                   pv_log_dir     IN VARCHAR2,
                                   pv_log_file    IN VARCHAR2,
                                   pn_time_slice_id IN NUMBER
                                  );

    PROCEDURE PR_UPDATE_TOTAL_BILL_TIME(pv_mfi_id      IN VARCHAR2,
                                        pv_product_id  IN VARCHAR2,
                                        pv_product_ver IN VARCHAR2,
                                        pd_inq_from_dt IN DATE,
                                        pd_inq_to_dt   IN DATE,
                                        pv_log_dir  IN VARCHAR2,
                                        pv_log_file IN VARCHAR2,
                                        pn_time_slice_id IN NUMBER
                                       );

    PROCEDURE PR_CALCULATE_ALACARTE_TIME(pn_pilot_flag   IN NUMBER,
                                         pd_valid_dt     IN DATE,
                                         pv_mfi_id       IN VARCHAR2,
                                         pv_product_id   IN VARCHAR2,
                                         pv_product_ver  IN VARCHAR2,
                                         pv_log_dir      IN VARCHAR2,
                                         pv_log_file     IN VARCHAR2,
                                         pd_inq_from_dt IN DATE,
                                         pd_inq_to_dt   IN DATE,
                                         pn_time_slice_id IN NUMBER
                                        );

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_T(   
                                             pv_mfi_id        IN VARCHAR2,
                                             pv_product_id    IN VARCHAR2,
                                             pv_product_ver   IN VARCHAR2,
                                             pd_inq_from_dt   IN DATE,
                                             pd_inq_to_dt     IN DATE,
                                             pv_log_dir       IN VARCHAR2,
                                             pv_log_file      IN VARCHAR2
                                            );
    
    PROCEDURE PR_INSERT_TIME_SLICE (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_inq_from_tm     IN VARCHAR2,
                                        pv_inq_to_tm       IN VARCHAR2,
                                        pv_log_dir         IN VARCHAR2,
                                        pv_log_file        IN VARCHAR2,
                                        pv_time_slice_size IN VARCHAR2,
                                        pv_rate            IN VARCHAR2
                                   );

    PROCEDURE PR_AUTO_UPDT_BILLING_CENTRAL(
                                            pd_inq_from_dt     IN DATE,
                                            pd_inq_to_dt       IN DATE,                                            
                                            pv_log_dir         IN VARCHAR2,
                                            pv_log_file        IN VARCHAR2
                                          );
                                          
                                                                             
END PK_INQUIRY_BILLING_V13; 


/*CREATE SYNONYM APP_BILLING.PK_INQUIRY_BILLING_V13 FOR HMCORE.PK_INQUIRY_BILLING_V13;

GRANT EXECUTE ON HMCORE.PK_INQUIRY_BILLING_V13 TO RL_BILLING;*/

/
--------------------------------------------------------
--  DDL for Package PK_INQUIRY_BILLING_V8
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_INQUIRY_BILLING_V8" 
AS
/*
    -- Determine the voucher type comparison to generate the csv based on the product type.
*/

    /*
        pv_exec_flag = 'COUNT' : This stage calculates the count for Inquiry and Portfolio and inserts this with the default values in the HM_BILLING_TRANSACTION Table.
        pv_exec_flag = 'BILL : This stage runs the Portfolio, Bulk / Alacarte modules as per the requirement and the commitment.
        pv_exec_flag = 'CSV' : This stage generates the Invoice and Appendix details required for the Final Bill generation
    */

    -- Procedure to execute the billing module MFI wise & Product wise.
    EX_VALID_DT_FAILED EXCEPTION;
    EX_TRNS_ID_VIOLATE EXCEPTION;
    TYPE REF_CURSOR IS REF CURSOR;
    
    gv_invoice_csv_file VARCHAR2(200) := 'Invoice_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';
    
    gv_appendix_csv_file VARCHAR2(200) := 'Appendix_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';

    -- Wrapper to run for all customers and products for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).       
    PROCEDURE PR_MFI_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_exec_flag       IN VARCHAR2,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_user_id         IN VARCHAR2,
                             pcur_out           OUT REF_CURSOR,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL,
                             pv_product_id      IN VARCHAR2 DEFAULT NULL
                            );

    -- Wrapper procedure for specific customer and product for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).
    PROCEDURE PR_HM_INQUIRY_BILLING(pv_mfi_id        IN VARCHAR2,
                                    pd_inq_from_dt   IN DATE,
                                    pd_inq_to_dt     IN DATE,
                                    pv_product_id    IN VARCHAR2,
                                    pv_exec_flag     IN VARCHAR2,
                                    pn_pilot_flag    IN NUMBER,
                                    pn_chk_ext       IN NUMBER,
                                    pv_log_dir       IN VARCHAR2,
                                    pv_log_file      IN VARCHAR2,
                                    pd_valid_dt      IN DATE DEFAULT NULL
                                    );
                                
    --procedure to calculate total inquiry count and pilot_deduction count     
    PROCEDURE PR_CALC_INQ_CNT(pv_mfi_id         IN VARCHAR2,
                              pd_inq_from_dt    IN DATE,
                              pd_inq_to_dt      IN DATE,
                              pv_product_id     IN VARCHAR2,
                              lv_inq_dtl_tbl_nm IN VARCHAR2,
                              pv_log_dir        IN VARCHAR2,
                              pv_log_file       IN VARCHAR2);   
                                                                 
    -- Procedure to insert initial details and default values in HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_INIT_INSERT_BILL_TRNS(pn_trns_id       IN NUMBER,
                                       pv_mfi_id        IN VARCHAR2,
                                       pv_product_id    IN VARCHAR2,
                                       pd_inq_from_dt   IN DATE,
                                       pd_inq_to_dt     IN DATE,
                                       pn_bulk_cnt      IN NUMBER,
                                       pn_singltn_cnt   IN NUMBER,
                                       pn_inq_cnt       IN NUMBER,
                                       pn_elig_port_cnt IN NUMBER,
                                       pv_log_dir       IN VARCHAR2,
                                       pv_log_file      IN VARCHAR2,
                                       pv_from_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_to_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_time_slice_id IN NUMBER DEFAULT NULL
                                      );
                                    
    -- Procedure to calculate the alacarte count and bill for MFIs having no commitments.
    PROCEDURE PR_CALCULATE_ALACARTE(pn_trns_id      IN NUMBER,
                                    pn_pilot_flag   IN NUMBER,
                                    pd_valid_dt     IN DATE,
                                    pv_mfi_id       IN VARCHAR2,
                                    pv_product_id   IN VARCHAR2,
                                    pv_log_dir      IN VARCHAR2,
                                    pv_log_file     IN VARCHAR2);

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);

    PROCEDURE PR_BULK_BILLING_O(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);
                                   
    -- Function to calculate the ALACARTE bill.
    FUNCTION FN_CALCULATE_ALA_CARTE(pv_mfi_id      IN  VARCHAR2,
                                    pn_inq_count   IN  NUMBER,
                                    pn_trns_id     IN  NUMBER,
                                    pv_product_id  IN  VARCHAR2,
                                    pv_log_dir     IN  VARCHAR2,
                                    pv_log_file    IN  VARCHAR2)
    RETURN NUMBER;

    -- Procedure to calculate the total bill of Portfolio, Alacarte & Bulk and update to the HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_UPDATE_TOTAL_BILL(pn_trns_id  IN NUMBER,
                                   pv_log_dir  IN VARCHAR2,
                                   pv_log_file IN VARCHAR2);

    -- Procedure to generate the csv invoice for the MFI.
    PROCEDURE PR_GENERATE_INVOICE(pn_pilot_flag  IN NUMBER,
                                  pv_mfi_id      IN VARCHAR2,
                                  pv_product_id  IN VARCHAR2,
                                  pd_inq_from_dt IN DATE,
                                  pd_inq_to_dt   IN DATE,
                                  pd_valid_dt    IN DATE,
                                  pv_log_dir     IN VARCHAR2,
                                  pv_log_file    IN VARCHAR2);

    -- Procedure to generate Appendix csv for the MFI.
    PROCEDURE PR_GENERATE_APPENDIX_DETAILS(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_O(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    -- Procedure to build the HM_RATE_APPLY_SLABS table based on the HM_USER_COMMITMENTS table.
    PROCEDURE PR_RATE_APPLY_SLAB(pv_mfi_id          IN VARCHAR2,
                                 pv_product_id    IN VARCHAR2,
                                 pv_log_dir         IN VARCHAR2,
                                 pv_log_file        IN VARCHAR2);
                                 
    PROCEDURE PR_INSERT_COMMITMENT(pv_mfi_id          IN VARCHAR2,
                                   pv_product_id      IN VARCHAR2,
                                   pn_commit_ind      IN NUMBER,
                                   pn_commit_size     IN NUMBER,
                                   pd_commit_start_dt IN DATE,
                                   pd_commit_end_dt   IN DATE,
                                   pv_log_dir         IN VARCHAR2,
                                   pv_log_file        IN VARCHAR2,
                                   pv_user_id         IN VARCHAR2,
                                   pv_error           OUT VARCHAR2, 
                                   pn_rate            IN NUMBER
                                  );
                                  
    PROCEDURE PR_INSERT_UPDATE_RATE(pv_mfi_id   IN VARCHAR2,
                         pv_product_id IN VARCHAR2,
                         pv_bill_ind IN VARCHAR2,
                         pn_rate     IN NUMBER,
                         pv_log_dir  IN VARCHAR2,
                         pv_log_file IN VARCHAR2,
                         pv_user_id  IN VARCHAR2,
                         pv_error    OUT VARCHAR2
                      );

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING_TIME(
                                   pv_mfi_id      IN VARCHAR2,
                                   pv_product_id  IN VARCHAR2,
                                   pd_inq_from_dt IN DATE,
                                   pd_inq_to_dt   IN DATE,
                                   pv_log_dir     IN VARCHAR2,
                                   pv_log_file    IN VARCHAR2,
                                   pn_time_slice_id IN NUMBER
                                  );

    PROCEDURE PR_UPDATE_TOTAL_BILL_TIME(pv_mfi_id      IN VARCHAR2,
                                        pv_product_id  IN VARCHAR2,
                                        pd_inq_from_dt IN DATE,
                                        pd_inq_to_dt   IN DATE,
                                        pv_log_dir  IN VARCHAR2,
                                        pv_log_file IN VARCHAR2,
                                        pn_time_slice_id IN NUMBER
                                       );

    PROCEDURE PR_CALCULATE_ALACARTE_TIME(pn_pilot_flag   IN NUMBER,
                                         pd_valid_dt     IN DATE,
                                         pv_mfi_id       IN VARCHAR2,
                                         pv_product_id   IN VARCHAR2,
                                         pv_log_dir      IN VARCHAR2,
                                         pv_log_file     IN VARCHAR2,
                                         pd_inq_from_dt IN DATE,
                                         pd_inq_to_dt   IN DATE,
                                         pn_time_slice_id IN NUMBER
                                        );

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_T(   
                                             pv_mfi_id        IN VARCHAR2,
                                             pv_product_id    IN VARCHAR2,
                                             pd_inq_from_dt   IN DATE,
                                             pd_inq_to_dt     IN DATE,
                                             pv_log_dir       IN VARCHAR2,
                                             pv_log_file      IN VARCHAR2
                                            );
    
    PROCEDURE PR_DELETE_BILLING_TRANS(
                                        pd_inq_from_dt   IN DATE,
                                        pd_inq_to_dt     IN DATE,
                                        pv_log_dir       IN VARCHAR2,
                                        pv_log_file      IN VARCHAR2,
                                        pv_mfi_id        IN VARCHAR2 DEFAULT NULL,
                                        pv_product_id    IN VARCHAR2 DEFAULT NULL
                                     );
                                     
    PROCEDURE PR_INSERT_TIME_SLICE (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_inq_from_tm     IN VARCHAR2,
                                        pv_inq_to_tm       IN VARCHAR2,
                                        pv_log_dir         IN VARCHAR2,
                                        pv_log_file        IN VARCHAR2,
                                        pv_time_slice_size IN VARCHAR2,
                                        pv_rate            IN VARCHAR2
                                   );

    PROCEDURE PR_INSERT_UPDATE_BILLING_TYPE (
                                                pv_mfi_id          IN VARCHAR2,
                                                pv_product_id      IN VARCHAR2,
                                                pv_action          IN VARCHAR2,
                                                pn_active          IN NUMBER,
                                                pv_user_id         IN VARCHAR2,
                                                pv_error           OUT VARCHAR2
                                            );

    PROCEDURE PR_INSERT_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pn_bill            IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_UPDATE_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_update          IN VARCHAR2,
                                        pn_bill_active     IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_AUTO_UPDT_BILLING_CENTRAL(
                                            pd_inq_from_dt     IN DATE,
                                            pd_inq_to_dt       IN DATE,                                            
                                            pv_log_dir         IN VARCHAR2,
                                            pv_log_file        IN VARCHAR2
                                          );
                                          
                                                                             
END PK_INQUIRY_BILLING_V8; 

/
--------------------------------------------------------
--  DDL for Package PK_INQUIRY_BILLING_V9
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_INQUIRY_BILLING_V9" 
AS
/*
    -- Determine the voucher type comparison to generate the csv based on the product type.
*/

    /*
        pv_exec_flag = 'COUNT' : This stage calculates the count for Inquiry and Portfolio and inserts this with the default values in the HM_BILLING_TRANSACTION Table.
        pv_exec_flag = 'BILL : This stage runs the Portfolio, Bulk / Alacarte modules as per the requirement and the commitment.
        pv_exec_flag = 'CSV' : This stage generates the Invoice and Appendix details required for the Final Bill generation
    */

    -- Procedure to execute the billing module MFI wise & Product wise.
    EX_VALID_DT_FAILED EXCEPTION;
    EX_TRNS_ID_VIOLATE EXCEPTION;
    TYPE REF_CURSOR IS REF CURSOR;
    
    gv_invoice_csv_file VARCHAR2(200) := 'Invoice_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';
    
    gv_appendix_csv_file VARCHAR2(200) := 'Appendix_'||TO_CHAR(SYSDATE, 'YYYY-MM-DD-HHMI')||'.csv';

    -- Wrapper to run for all customers and products for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).       
    PROCEDURE PR_MFI_BILLING(pd_inq_from_dt     IN DATE,
                             pd_inq_to_dt       IN DATE,
                             pv_exec_flag       IN VARCHAR2,
                             pv_log_dir         IN VARCHAR2,
                             pv_log_file        IN VARCHAR2,
                             pv_user_id         IN VARCHAR2,
                             pcur_out           OUT REF_CURSOR,
                             pv_mfi_id          IN VARCHAR2 DEFAULT NULL,
                             pv_product_id      IN VARCHAR2 DEFAULT NULL
                            );

    -- Wrapper procedure for specific customer and product for different process modes (PORTFOLIO, ALACARTE, BULK BILLING and INVOICE-APPENDIX GENERATION).
    PROCEDURE PR_HM_INQUIRY_BILLING(pv_mfi_id        IN VARCHAR2,
                                    pd_inq_from_dt   IN DATE,
                                    pd_inq_to_dt     IN DATE,
                                    pv_product_id    IN VARCHAR2,
                                    pv_exec_flag     IN VARCHAR2,
                                    pn_pilot_flag    IN NUMBER,
                                    pn_chk_ext       IN NUMBER,
                                    pv_log_dir       IN VARCHAR2,
                                    pv_log_file      IN VARCHAR2,
                                    pd_valid_dt      IN DATE DEFAULT NULL
                                    );
                                
    --procedure to calculate total inquiry count and pilot_deduction count     
    PROCEDURE PR_CALC_INQ_CNT(pv_mfi_id         IN VARCHAR2,
                              pd_inq_from_dt    IN DATE,
                              pd_inq_to_dt      IN DATE,
                              pv_product_id     IN VARCHAR2,
                              lv_inq_dtl_tbl_nm IN VARCHAR2,
                              pv_log_dir        IN VARCHAR2,
                              pv_log_file       IN VARCHAR2);   
                                                                 
    -- Procedure to insert initial details and default values in HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_INIT_INSERT_BILL_TRNS(pn_trns_id       IN NUMBER,
                                       pv_mfi_id        IN VARCHAR2,
                                       pv_product_id    IN VARCHAR2,
                                       pd_inq_from_dt   IN DATE,
                                       pd_inq_to_dt     IN DATE,
                                       pn_bulk_cnt      IN NUMBER,
                                       pn_singltn_cnt   IN NUMBER,
                                       pn_inq_cnt       IN NUMBER,
                                       pn_elig_port_cnt IN NUMBER,
                                       pv_log_dir       IN VARCHAR2,
                                       pv_log_file      IN VARCHAR2,
                                       pv_from_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_to_tm       IN VARCHAR2 DEFAULT NULL,
                                       pv_time_slice_id IN NUMBER DEFAULT NULL
                                      );
                                    
    -- Procedure to calculate the alacarte count and bill for MFIs having no commitments.
    PROCEDURE PR_CALCULATE_ALACARTE(pn_trns_id      IN NUMBER,
                                    pn_pilot_flag   IN NUMBER,
                                    pd_valid_dt     IN DATE,
                                    pv_mfi_id       IN VARCHAR2,
                                    pv_product_id   IN VARCHAR2,
                                    pv_log_dir      IN VARCHAR2,
                                    pv_log_file     IN VARCHAR2);

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);

    PROCEDURE PR_BULK_BILLING_O(pn_trns_id     IN NUMBER,
                              pv_mfi_id      IN VARCHAR2,
                              pv_product_id  IN VARCHAR2,
                              pd_inq_from_dt IN DATE,
                              pd_inq_to_dt   IN DATE,
                              pv_log_dir     IN VARCHAR2,
                              pv_log_file    IN VARCHAR2);
                                   
    -- Function to calculate the ALACARTE bill.
    FUNCTION FN_CALCULATE_ALA_CARTE(pv_mfi_id      IN  VARCHAR2,
                                    pn_inq_count   IN  NUMBER,
                                    pn_trns_id     IN  NUMBER,
                                    pv_product_id  IN  VARCHAR2,
                                    pv_log_dir     IN  VARCHAR2,
                                    pv_log_file    IN  VARCHAR2)
    RETURN NUMBER;

    -- Procedure to calculate the total bill of Portfolio, Alacarte & Bulk and update to the HM_BILLING_TRANSACTION Table.
    PROCEDURE PR_UPDATE_TOTAL_BILL(pn_trns_id  IN NUMBER,
                                   pv_log_dir  IN VARCHAR2,
                                   pv_log_file IN VARCHAR2);

    -- Procedure to generate the csv invoice for the MFI.
    PROCEDURE PR_GENERATE_INVOICE(pn_pilot_flag  IN NUMBER,
                                  pv_mfi_id      IN VARCHAR2,
                                  pv_product_id  IN VARCHAR2,
                                  pd_inq_from_dt IN DATE,
                                  pd_inq_to_dt   IN DATE,
                                  pd_valid_dt    IN DATE,
                                  pv_log_dir     IN VARCHAR2,
                                  pv_log_file    IN VARCHAR2);

    -- Procedure to generate Appendix csv for the MFI.
    PROCEDURE PR_GENERATE_APPENDIX_DETAILS(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_O(pn_trns_id       IN NUMBER,
                                           pv_mfi_id        IN VARCHAR2,
                                           pv_product_id    IN VARCHAR2,
                                           pd_inq_from_dt   IN DATE,
                                           pd_inq_to_dt     IN DATE,
                                           pv_log_dir       IN VARCHAR2,
                                           pv_log_file      IN VARCHAR2);

    -- Procedure to build the HM_RATE_APPLY_SLABS table based on the HM_USER_COMMITMENTS table.
    PROCEDURE PR_RATE_APPLY_SLAB(pv_mfi_id          IN VARCHAR2,
                                 pv_product_id    IN VARCHAR2,
                                 pv_log_dir         IN VARCHAR2,
                                 pv_log_file        IN VARCHAR2);
                                 
    PROCEDURE PR_INSERT_COMMITMENT(pv_mfi_id          IN VARCHAR2,
                                   pv_product_id      IN VARCHAR2,
                                   pn_commit_ind      IN NUMBER,
                                   pn_commit_size     IN NUMBER,
                                   pd_commit_start_dt IN DATE,
                                   pd_commit_end_dt   IN DATE,
                                   pv_log_dir         IN VARCHAR2,
                                   pv_log_file        IN VARCHAR2,
                                   pv_user_id         IN VARCHAR2,
                                   pv_error           OUT VARCHAR2, 
                                   pn_rate            IN NUMBER
                                  );
                                  
    PROCEDURE PR_INSERT_UPDATE_RATE(pv_mfi_id   IN VARCHAR2,
                         pv_product_id IN VARCHAR2,
                         pv_bill_ind IN VARCHAR2,
                         pn_rate     IN NUMBER,
                         pv_log_dir  IN VARCHAR2,
                         pv_log_file IN VARCHAR2,
                         pv_user_id  IN VARCHAR2,
                         pv_error    OUT VARCHAR2
                      );

    -- Procedure to calculate the Bulk bill.
    PROCEDURE PR_BULK_BILLING_TIME(
                                   pv_mfi_id      IN VARCHAR2,
                                   pv_product_id  IN VARCHAR2,
                                   pd_inq_from_dt IN DATE,
                                   pd_inq_to_dt   IN DATE,
                                   pv_log_dir     IN VARCHAR2,
                                   pv_log_file    IN VARCHAR2,
                                   pn_time_slice_id IN NUMBER
                                  );

    PROCEDURE PR_UPDATE_TOTAL_BILL_TIME(pv_mfi_id      IN VARCHAR2,
                                        pv_product_id  IN VARCHAR2,
                                        pd_inq_from_dt IN DATE,
                                        pd_inq_to_dt   IN DATE,
                                        pv_log_dir  IN VARCHAR2,
                                        pv_log_file IN VARCHAR2,
                                        pn_time_slice_id IN NUMBER
                                       );

    PROCEDURE PR_CALCULATE_ALACARTE_TIME(pn_pilot_flag   IN NUMBER,
                                         pd_valid_dt     IN DATE,
                                         pv_mfi_id       IN VARCHAR2,
                                         pv_product_id   IN VARCHAR2,
                                         pv_log_dir      IN VARCHAR2,
                                         pv_log_file     IN VARCHAR2,
                                         pd_inq_from_dt IN DATE,
                                         pd_inq_to_dt   IN DATE,
                                         pn_time_slice_id IN NUMBER
                                        );

    PROCEDURE PR_GENERATE_APPENDIX_DETAILS_T(   
                                             pv_mfi_id        IN VARCHAR2,
                                             pv_product_id    IN VARCHAR2,
                                             pd_inq_from_dt   IN DATE,
                                             pd_inq_to_dt     IN DATE,
                                             pv_log_dir       IN VARCHAR2,
                                             pv_log_file      IN VARCHAR2
                                            );
    
    PROCEDURE PR_DELETE_BILLING_TRANS(
                                        pd_inq_from_dt   IN DATE,
                                        pd_inq_to_dt     IN DATE,
                                        pv_log_dir       IN VARCHAR2,
                                        pv_log_file      IN VARCHAR2,
                                        pv_mfi_id        IN VARCHAR2 DEFAULT NULL,
                                        pv_product_id    IN VARCHAR2 DEFAULT NULL
                                     );
                                     
    PROCEDURE PR_INSERT_TIME_SLICE (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_inq_from_tm     IN VARCHAR2,
                                        pv_inq_to_tm       IN VARCHAR2,
                                        pv_log_dir         IN VARCHAR2,
                                        pv_log_file        IN VARCHAR2,
                                        pv_time_slice_size IN VARCHAR2,
                                        pv_rate            IN VARCHAR2
                                   );

    PROCEDURE PR_INSERT_UPDATE_BILLING_TYPE (
                                                pv_mfi_id          IN VARCHAR2,
                                                pv_product_id      IN VARCHAR2,
                                                pv_action          IN VARCHAR2,
                                                pn_active          IN NUMBER,
                                                pv_user_id         IN VARCHAR2,
                                                pv_error           OUT VARCHAR2
                                            );

    PROCEDURE PR_INSERT_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pn_bill            IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_UPDATE_FIXED_BILL (
                                        pv_mfi_id          IN VARCHAR2,
                                        pv_product_id      IN VARCHAR2,
                                        pv_update          IN VARCHAR2,
                                        pn_bill_active     IN NUMBER,
                                        pv_user_id         IN VARCHAR2,
                                        pv_error           OUT VARCHAR2
                                   );

    PROCEDURE PR_AUTO_UPDT_BILLING_CENTRAL(
                                            pd_inq_from_dt     IN DATE,
                                            pd_inq_to_dt       IN DATE,                                            
                                            pv_log_dir         IN VARCHAR2,
                                            pv_log_file        IN VARCHAR2
                                          );
                                          
                                                                             
END PK_INQUIRY_BILLING_V9; 

/
--------------------------------------------------------
--  DDL for Package PK_IOI_BATCH_LTC_LOAD_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_BATCH_LTC_LOAD_V1" 
AS

    gv_error_msg VARCHAR2(4000);
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 39;
    GN_TOTAL_IOT_TABLE_CNT NUMBER := 4;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    GN_TOTAL_INQ_COUNT NUMBER := 0;
    
    gv_temp_tbl1    VARCHAR2(100);
    
    gd_inq_from_dt      DATE;
    gd_inq_to_dt        DATE;
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pn_inquiry_batch_id NUMBER,
                                    pn_portfolio_id     NUMBER, 
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pn_homecredit_flag  NUMBER
                                     
                                  );
                                  
    PROCEDURE PR_LTC_INQUIRY_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2 
                                   
                                 );

    PROCEDURE PR_LTC_INQUIRY_CAND_DUMP( pv_temp_tbl     VARCHAR2,
                                        pn_batch_id     NUMBER,
                                        pv_log_dir      VARCHAR2,
                                        pv_log_file_name     VARCHAR2,
                                        IOI_TYPE VARCHAR2   );
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pn_inquiry_batch_id   NUMBER, 
                                   pn_batch_id           NUMBER,
                                   pv_temp_tbl      VARCHAR2,
                                   pv_log_dir       VARCHAR2,
                                   pv_log_file_name VARCHAR2                                                                
                                 );

    PROCEDURE PR_LTC_INQ_POPULATE_PR_IOI(    pn_portfolio_id   NUMBER,
                                             pn_inquiry_batch_id NUMBER, 
                                             pn_batch_id           NUMBER,
                                             pv_temp_tbl      VARCHAR2,
                                             pv_log_dir       VARCHAR2,
                                             pv_log_file_name VARCHAR2                                                              
                                         );
                                 
                                 
    PROCEDURE PR_LTC_BATCH_ID_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2 );
                                    
    PROCEDURE PR_LTC_PARALLEL_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2 );

    PROCEDURE PR_CALL_LTC_BATCH( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2 
                               );
                                                              
    PROCEDURE PR_LTC_ID_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );                               
                                         
    PROCEDURE PR_LTC_COMP_DOB_CLUSTER( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );
    
    PROCEDURE PR_LTC_PAR_DOB_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );                                                                                       

    PROCEDURE PR_LTC_PHONE_CLUSTER( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_AGE_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                );

    PROCEDURE PR_LTC_SP_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SC_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SCL_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                ); 

    PROCEDURE PR_LTC_CNS_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_103_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_FULL_PHONE_CLUSTER( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_REL_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_COMP_DOB_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
                                  
    PROCEDURE PR_LTC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );
                                  
    PROCEDURE PR_LTC_PHONE_LINK( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_AGE_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_CNS_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_103_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_FULL_PHONE_LINK( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_REL_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_SP_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SC_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SCL_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_ID_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_PHN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir       VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_PHN_AGE_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_PHN_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                           pn_total_job NUMBER,
                                           pn_mod NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );

    PROCEDURE PR_LTC_NAME_PIN_PAR_DOB_LINK( pn_batch_id NUMBER,
                                            pn_total_job NUMBER,
                                            pn_mod NUMBER,
                                            pv_log_dir VARCHAR2,
                                            pv_log_file_name VARCHAR2
                                          );

    PROCEDURE PR_LTC_NAME_SC_AGE_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_AGE_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_SC_REL_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_REL_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );
    
    PROCEDURE PR_LTC_NAME_COMP_DOB_LINK( pn_batch_id NUMBER,
                                         pn_total_job NUMBER,
                                         pn_mod NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_PIN_PHONE_LINK( pn_batch_id NUMBER,
                                     pn_total_job NUMBER,
                                     pn_mod NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                   );

    PROCEDURE PR_LTC_PIN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );
                                                                                                                                                                             
    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2 
                           );

END PK_IOI_BATCH_LTC_LOAD_V1; 
/*
grant execute on HMCORE.PK_IOI_BATCH_LTC_LOAD_V1 to HMCNSSTAGE,HMRACSTAGE;
*/ 

/
--------------------------------------------------------
--  DDL for Package PK_IOI_IOT_LOAD_LIVE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_IOT_LOAD_LIVE" 
AS 

   TYPE CUR_SELECT  IS REF CURSOR;
   GN_TOTAL_IOT_TABLE_CNT_IOT NUMBER := 4;
   gv_error_msg VARCHAR2(4000);
   
   
   
   gv_ADR_IOT VARCHAR2(4000);
   gv_PHN_IOT VARCHAR2(4000);
   gv_CNS_IOT_CNS VARCHAR2(4000);
   gv_CNS_IOT_REL VARCHAR2(4000);
   
   gn_proc_comp_cnt_iot NUMBER;
   
   gv_inquiry_id_iot NUMBER;
    
    PROCEDURE PR_CALL_IOT_BATCH( pn_inquiry_id NUMBER,
                                 pn_batchid NUMBER,
                                 pv_file_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
    
    PROCEDURE PR_IOT_BATCH_ID_STATUS( pn_batchid NUMBER,
                                      pv_file_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
    
   PROCEDURE PR_PROD_MOVE_STD_CNS_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );

   PROCEDURE PR_PROD_MOVE_STD_CNS_CNS_IOT( 
                                           pn_batchid IN  NUMBER,
                                           pv_file_dir    IN VARCHAR2, 
                                           pv_log_file_name   IN VARCHAR2  
                                         );

   PROCEDURE PR_PROD_MOVE_STD_CNS_REL_IOT( 
                                           pn_batchid IN  NUMBER,
                                           pv_file_dir    IN VARCHAR2, 
                                           pv_log_file_name   IN VARCHAR2  
                                         );
                                      
   PROCEDURE PR_PROD_MOVE_STD_PHN_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );
                                     
   PROCEDURE PR_PROD_MOVE_STD_ADR_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );

    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );
                                      
END PK_IOI_IOT_LOAD_LIVE; 


/*
CREATE SYNONYM APP_INQ_MATCH.PK_IOI_IOT_LOAD_LIVE FOR HMCORE.PK_IOI_IOT_LOAD_LIVE;

GRANT EXECUTE ON HMCORE.PK_IOI_IOT_LOAD_LIVE TO RL_INQ_MATCH;

CREATE SYNONYM MATCH_CP.PK_IOI_IOT_LOAD_LIVE FOR HMCORE.PK_IOI_IOT_LOAD_LIVE;

GRANT EXECUTE ON HMCORE.PK_IOI_IOT_LOAD_LIVE TO MATCH_CP;

CREATE SYNONYM MATCH.PK_IOI_IOT_LOAD_LIVE FOR HMCORE.PK_IOI_IOT_LOAD_LIVE;

GRANT EXECUTE ON HMCORE.PK_IOI_IOT_LOAD_LIVE TO MATCH;
*/ 

/
--------------------------------------------------------
--  DDL for Package PK_IOI_IOT_LOAD_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_IOT_LOAD_V3" 
AS 

   TYPE CUR_SELECT  IS REF CURSOR;
   GN_TOTAL_IOT_TABLE_CNT NUMBER := 4;
   gv_error_msg VARCHAR2(4000);
    
    PROCEDURE PR_CALL_IOT_BATCH( pn_batchid NUMBER,
                                 pv_file_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
    
    PROCEDURE PR_IOT_BATCH_ID_STATUS( pn_batchid NUMBER,
                                      pv_file_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
    
   PROCEDURE PR_PROD_MOVE_STD_CNS_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );

   PROCEDURE PR_PROD_MOVE_STD_CNS_CNS_IOT( 
                                           pn_batchid IN  NUMBER,
                                           pv_file_dir    IN VARCHAR2, 
                                           pv_log_file_name   IN VARCHAR2  
                                         );

   PROCEDURE PR_PROD_MOVE_STD_CNS_REL_IOT( 
                                           pn_batchid IN  NUMBER,
                                           pv_file_dir    IN VARCHAR2, 
                                           pv_log_file_name   IN VARCHAR2  
                                         );
                                      
   PROCEDURE PR_PROD_MOVE_STD_PHN_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );
                                     
   PROCEDURE PR_PROD_MOVE_STD_ADR_IOT( 
                                       pn_batchid IN  NUMBER,
                                       pv_file_dir    IN VARCHAR2, 
                                       pv_log_file_name   IN VARCHAR2  
                                     );

    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );
                                      
END PK_IOI_IOT_LOAD_V3; 


/*
CREATE SYNONYM APP_INQ_MATCH.PK_IOI_IOT_LOAD_V3 FOR HMCORE.PK_IOI_IOT_LOAD_V3;

GRANT EXECUTE ON HMCORE.PK_IOI_IOT_LOAD_V3 TO RL_INQ_MATCH;

CREATE SYNONYM MATCH_CP.PK_IOI_IOT_LOAD_V3 FOR HMCORE.PK_IOI_IOT_LOAD_V3;

GRANT EXECUTE ON HMCORE.PK_IOI_IOT_LOAD_V3 TO MATCH_CP;

CREATE SYNONYM MATCH.PK_IOI_IOT_LOAD_V3 FOR HMCORE.PK_IOI_IOT_LOAD_V3;

GRANT EXECUTE ON HMCORE.PK_IOI_IOT_LOAD_V3 TO MATCH;
*/

/
--------------------------------------------------------
--  DDL for Package PK_IOI_LTC_LOAD_LIVE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_LTC_LOAD_LIVE" 
AS

    gv_error_msg VARCHAR2(4000);
    
    gn_inquiry_id_live NUMBER;
    
    gn_proc_comp_cnt NUMBER;
    gn_err_flag      NUMBER;
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 39;
    GN_TOTAL_IOT_TABLE_CNT NUMBER := 4;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    GN_TOTAL_INQ_COUNT NUMBER := 0;
    
    gv_HM_LTC_ID_CLST VARCHAR2(4000);
    gv_HM_LTC_COMP_DOB_CLST VARCHAR2(4000);
    gv_HM_LTC_PART_DOB_CLST VARCHAR2(4000);
    gv_HM_LTC_PHONE_CLST VARCHAR2(4000);
    gv_HM_LTC_AGE_CLST VARCHAR2(4000);
    gv_HM_LTC_SP_CLST VARCHAR2(4000);
    gv_HM_LTC_SC_CLST VARCHAR2(4000);
    gv_HM_LTC_SCL_CLST VARCHAR2(4000);
    gv_HM_LTC_NAME_CLST_HOMOPHONE VARCHAR2(4000);
    gv_HM_LTC_NAME_CLST_SOUNDEX VARCHAR2(4000);
    gv_HM_LTC_NAME_CLST_DBLM VARCHAR2(4000);
    gv_HM_LTC_FULL_PHONE_CLST VARCHAR2(4000);
    gv_HM_LTC_REL_CLST_SOUNDEX VARCHAR2(4000);
    gv_HM_LTC_REL_CLST_HOMOPHONE VARCHAR2(4000);
    
    gv_HM_LTC_ID_LINK VARCHAR2(4000);
    gv_HM_LTC_COMP_DOB_LINK VARCHAR2(4000);
    gv_HM_LTC_PART_DOB_LINK VARCHAR2(4000);
    gv_HM_LTC_PHONE_LINK VARCHAR2(4000);
    gv_HM_LTC_AGE_LINK VARCHAR2(4000);
    gv_HM_LTC_SP_LINK VARCHAR2(4000);
    gv_HM_LTC_SC_LINK VARCHAR2(4000);
    gv_HM_LTC_SCL_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_LINK_HOMOPHONE VARCHAR2(4000);
    gv_HM_LTC_NAME_LINK_SOUNDEX VARCHAR2(4000);
    gv_HM_LTC_NAME_LINK_DBLM VARCHAR2(4000);
    gv_HM_LTC_FULL_PHONE_LINK VARCHAR2(4000);
    gv_HM_LTC_REL_LINK_SOUNDEX VARCHAR2(4000);
    gv_HM_LTC_REL_LINK_HOMOPHONE VARCHAR2(4000);

        
    gv_HM_LTC_PHONE_PART_DOB_LINK VARCHAR2(4000);
    gv_HM_LTC_PHONE_AGE_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_PHONE_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_SCL_LINK VARCHAR2(4000);
    gv_HM_LTC_NAMESCPARTDOB_LINK VARCHAR2(4000);
    gv_HM_LTC_NAMEPINPARTDOB_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_SC_AGE_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_PIN_AGE_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_SC_REL_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_PIN_REL_LINK VARCHAR2(4000);
    gv_HM_LTC_NAME_COMP_DOB_LINK VARCHAR2(4000);
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pd_inq_from_dt      DATE,
                                    pd_inq_to_dt        DATE,
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pv_mfi_id           VARCHAR2 DEFAULT NULL,
                                    pn_node NUMBER DEFAULT 1
                                  );
                                  
    PROCEDURE PR_LTC_INQUIRY_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );

    PROCEDURE PR_LTC_INQUIRY_CAND_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pd_inq_from_dt  DATE,
                                   pd_inq_to_dt    DATE,
                                   pn_batch_id     NUMBER,
                                   pv_temp_tbl     VARCHAR2,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1                                                               
                                 );

    PROCEDURE PR_LTC_BATCH_ID_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
                                    
    PROCEDURE PR_LTC_PARALLEL_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );

    PROCEDURE PR_CALL_LTC_BATCH( pn_inquiry_id NUMBER,
                                 pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
                                                              
    PROCEDURE PR_LTC_ID_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );                               
                                         
    PROCEDURE PR_LTC_COMP_DOB_CLUSTER( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );
    
    PROCEDURE PR_LTC_PAR_DOB_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );                                                                                       

    PROCEDURE PR_LTC_PHONE_CLUSTER( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_AGE_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                );

    PROCEDURE PR_LTC_SP_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SC_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SCL_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                ); 

    PROCEDURE PR_LTC_CNS_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_103_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_FULL_PHONE_CLUSTER( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_REL_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_COMP_DOB_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
                                  
    PROCEDURE PR_LTC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );
                                  
    PROCEDURE PR_LTC_PHONE_LINK( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_AGE_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_CNS_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_103_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_FULL_PHONE_LINK( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_REL_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_SP_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SC_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SCL_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_ID_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_PHN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir       VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_PHN_AGE_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_PHN_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                           pn_total_job NUMBER,
                                           pn_mod NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );

    PROCEDURE PR_LTC_NAME_PIN_PAR_DOB_LINK( pn_batch_id NUMBER,
                                            pn_total_job NUMBER,
                                            pn_mod NUMBER,
                                            pv_log_dir VARCHAR2,
                                            pv_log_file_name VARCHAR2
                                          );

    PROCEDURE PR_LTC_NAME_SC_AGE_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_AGE_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_SC_REL_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_REL_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );
    
    PROCEDURE PR_LTC_NAME_COMP_DOB_LINK( pn_batch_id NUMBER,
                                         pn_total_job NUMBER,
                                         pn_mod NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_PIN_PHONE_LINK( pn_batch_id NUMBER,
                                     pn_total_job NUMBER,
                                     pn_mod NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                   );

    PROCEDURE PR_LTC_PIN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );

END PK_IOI_LTC_LOAD_LIVE; 

/
--------------------------------------------------------
--  DDL for Package PK_IOI_LTC_LOAD_V5
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_LTC_LOAD_V5" 
AS

    gv_error_msg VARCHAR2(4000);
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 39;
    GN_TOTAL_IOT_TABLE_CNT NUMBER := 4;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    GN_TOTAL_INQ_COUNT NUMBER := 0;
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pd_inq_from_dt      DATE,
                                    pd_inq_to_dt        DATE,
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pv_mfi_id           VARCHAR2 DEFAULT NULL,
                                    pn_node NUMBER DEFAULT 1
                                  );
                                  
    PROCEDURE PR_LTC_INQUIRY_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );

    PROCEDURE PR_LTC_INQUIRY_CAND_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pd_inq_from_dt  DATE,
                                   pd_inq_to_dt    DATE,
                                   pn_batch_id     NUMBER,
                                   pv_temp_tbl     VARCHAR2,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1                                                               
                                 );

    PROCEDURE PR_LTC_BATCH_ID_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
                                    
    PROCEDURE PR_LTC_PARALLEL_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );

    PROCEDURE PR_CALL_LTC_BATCH( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
                                                              
    PROCEDURE PR_LTC_ID_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );                               
                                         
    PROCEDURE PR_LTC_COMP_DOB_CLUSTER( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );
    
    PROCEDURE PR_LTC_PAR_DOB_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );                                                                                       

    PROCEDURE PR_LTC_PHONE_CLUSTER( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_AGE_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                );

    PROCEDURE PR_LTC_SP_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SC_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SCL_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                ); 

    PROCEDURE PR_LTC_CNS_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_103_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_FULL_PHONE_CLUSTER( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_REL_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_COMP_DOB_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
                                  
    PROCEDURE PR_LTC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );
                                  
    PROCEDURE PR_LTC_PHONE_LINK( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_AGE_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_CNS_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_103_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_FULL_PHONE_LINK( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_REL_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_SP_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SC_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SCL_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_ID_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_PHN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir       VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_PHN_AGE_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_PHN_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                           pn_total_job NUMBER,
                                           pn_mod NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );

    PROCEDURE PR_LTC_NAME_PIN_PAR_DOB_LINK( pn_batch_id NUMBER,
                                            pn_total_job NUMBER,
                                            pn_mod NUMBER,
                                            pv_log_dir VARCHAR2,
                                            pv_log_file_name VARCHAR2
                                          );

    PROCEDURE PR_LTC_NAME_SC_AGE_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_AGE_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_SC_REL_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_REL_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );
    
    PROCEDURE PR_LTC_NAME_COMP_DOB_LINK( pn_batch_id NUMBER,
                                         pn_total_job NUMBER,
                                         pn_mod NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_PIN_PHONE_LINK( pn_batch_id NUMBER,
                                     pn_total_job NUMBER,
                                     pn_mod NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                   );

    PROCEDURE PR_LTC_PIN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );

END PK_IOI_LTC_LOAD_V5; 

/
--------------------------------------------------------
--  DDL for Package PK_IOI_LTC_LOAD_V5_CCC0000001
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_LTC_LOAD_V5_CCC0000001" 
AS

    gv_error_msg VARCHAR2(4000);
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 39;
    GN_TOTAL_IOT_TABLE_CNT NUMBER := 4;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    GN_TOTAL_INQ_COUNT NUMBER := 0;
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pd_inq_from_dt      DATE,
                                    pd_inq_to_dt        DATE,
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pv_mfi_id           VARCHAR2 DEFAULT NULL,
                                    pn_node NUMBER DEFAULT 1
                                  );
                                  
    PROCEDURE PR_LTC_INQUIRY_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );

    PROCEDURE PR_LTC_INQUIRY_CAND_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pd_inq_from_dt  DATE,
                                   pd_inq_to_dt    DATE,
                                   pn_batch_id     NUMBER,
                                   pv_temp_tbl     VARCHAR2,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1                                                               
                                 );

    PROCEDURE PR_LTC_BATCH_ID_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );
                                    
    PROCEDURE PR_LTC_PARALLEL_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2,
                                      pn_node NUMBER DEFAULT 1
                                    );

    PROCEDURE PR_CALL_LTC_BATCH( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2,
                                 pn_node NUMBER DEFAULT 1
                               );
                                                              
    PROCEDURE PR_LTC_ID_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );                               
                                         
    PROCEDURE PR_LTC_COMP_DOB_CLUSTER( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );
    
    PROCEDURE PR_LTC_PAR_DOB_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );                                                                                       

    PROCEDURE PR_LTC_PHONE_CLUSTER( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_AGE_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                );

    PROCEDURE PR_LTC_SP_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SC_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SCL_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                ); 

    PROCEDURE PR_LTC_CNS_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_103_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_FULL_PHONE_CLUSTER( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_REL_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_COMP_DOB_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
                                  
    PROCEDURE PR_LTC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );
                                  
    PROCEDURE PR_LTC_PHONE_LINK( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_AGE_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_CNS_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_103_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_FULL_PHONE_LINK( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_REL_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_SP_LINK( pn_batch_id NUMBER,
                              pn_total_job NUMBER,
                              pn_mod NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SC_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SCL_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_ID_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_PHN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir       VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_PHN_AGE_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_PHN_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_LINK( pn_batch_id NUMBER,
                                   pn_total_job NUMBER,
                                   pn_mod NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                           pn_total_job NUMBER,
                                           pn_mod NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );

    PROCEDURE PR_LTC_NAME_PIN_PAR_DOB_LINK( pn_batch_id NUMBER,
                                            pn_total_job NUMBER,
                                            pn_mod NUMBER,
                                            pv_log_dir VARCHAR2,
                                            pv_log_file_name VARCHAR2
                                          );

    PROCEDURE PR_LTC_NAME_SC_AGE_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_AGE_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_SC_REL_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_REL_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );
    
    PROCEDURE PR_LTC_NAME_COMP_DOB_LINK( pn_batch_id NUMBER,
                                         pn_total_job NUMBER,
                                         pn_mod NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_PIN_PHONE_LINK( pn_batch_id NUMBER,
                                     pn_total_job NUMBER,
                                     pn_mod NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                   );

    PROCEDURE PR_LTC_PIN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );

END PK_IOI_LTC_LOAD_V5_CCC0000001; 

/
--------------------------------------------------------
--  DDL for Package PK_IOI_PR_LTC_LOAD_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_IOI_PR_LTC_LOAD_V1" 
AS

    gv_error_msg VARCHAR2(4000);
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 39;
    GN_TOTAL_IOT_TABLE_CNT NUMBER := 4;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    GN_TOTAL_INQ_COUNT NUMBER := 0;
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pd_inq_from_dt      DATE,
                                    pd_inq_to_dt        DATE,
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pv_mfi_id           VARCHAR2 DEFAULT NULL,
                                    pn_node NUMBER DEFAULT 1
                                  );
                                  
    PROCEDURE PR_LTC_INQUIRY_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );

    PROCEDURE PR_LTC_INQUIRY_CAND_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1
                                 );
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pd_inq_from_dt  DATE,
                                   pd_inq_to_dt    DATE,
                                   pn_batch_id     NUMBER,
                                   pv_temp_tbl     VARCHAR2,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2,
                                   pn_node NUMBER DEFAULT 1                                                               
                                 );



    PROCEDURE PR_START_JOB (pv_jobs_sqls VARCHAR2, 
                            pn_node NUMBER DEFAULT 1
                           );

END PK_IOI_PR_LTC_LOAD_V1; 

/
--------------------------------------------------------
--  DDL for Package PK_LOAD_INQ_FILE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_LOAD_INQ_FILE" 
AS
    gn_temp_batch_id NUMBER;
    gv_file_dir VARCHAR2(100):='CIBIL_LOG';
    gv_log_file_name VARCHAR2(100);
    EX_NORMAL_RET EXCEPTION;
    TYPE HM_SOURCE_CUR IS REF CURSOR;
    gv_check_tag  CONSTANT  VARCHAR2(10) := 'PNPAPI';
    gn_tag_length CONSTANT  NUMBER(10)  :=2;
    gn_data_length CONSTANT NUMBER(10) :=2;
    EX_NULL_ACCT_NBR            EXCEPTION;
    EX_ACCT_NBR_25TO35          EXCEPTION;
    EX_ACCT_NBR_ABV_35          EXCEPTION;
    gn_batch_id NUMBER;
    gn_parse_limit NUMBER := 800000;
    gn_no_parse_processes NUMBER :=6;
    gn_commit_after         NUMBER := 10000;
    TYPE CUR_SELECT   IS REF CURSOR;
    gn_file_key NUMBER(10);
    gv_sourcefmt VARCHAR2(100) :='TUEF';
    gv_seg_id                  VARCHAR2(1000);
    gn_format_ver              NUMBER(10);
    gv_reporting_member        VARCHAR2(1000);
    gv_reporting_member_cibil  VARCHAR2(1000);
    gv_email_contacts VARCHAR2(4000);
    gv_file_name VARCHAR2(4000);
    
    TYPE FLD_VALS_ROW
    IS
    RECORD (
             PN01 VARCHAR2 (4000),
             PN02 VARCHAR2 (4000),
             PN03 VARCHAR2 (4000),
             PN04 VARCHAR2 (4000),
             PN05 VARCHAR2 (4000),
             PN07 VARCHAR2 (4000),
             PN08 VARCHAR2 (4000),
             PN09 VARCHAR2 (4000),
             PN10 VARCHAR2 (4000),
             PN11 VARCHAR2 (4000),
             PN12 VARCHAR2 (4000),
             PN13 VARCHAR2 (4000),
             PA01 VARCHAR2 (4000),
             PA02 VARCHAR2 (4000),
             PA03 VARCHAR2 (4000),
             PA04 VARCHAR2 (4000),
             PA05 VARCHAR2 (4000),
             PA06 VARCHAR2 (4000),
             PA07 VARCHAR2 (4000),
             PI01 VARCHAR2 (4000),
             CUST_ID NUMBER,
             APP_ID NUMBER,
             MEM_REF_NO   VARCHAR2(25),
             MEM_CODE     VARCHAR2(10),
             INQ_PASSWORD VARCHAR2(5),
             INQ_PURPOSE  NUMBER,
             INQ_AMT      NUMBER
           );

    TYPE FLD_VALS_TBL IS TABLE OF FLD_VALS_ROW;
PROCEDURE PR_GET_DATA_TO_BE_LOADED(pv_file_name IN VARCHAR2,
                                   pv_file_dir IN VARCHAR2,
                                   pv_log_file_name IN VARCHAR2
                                  );
FUNCTION FN_PARSE_CIBIL(
                            SOURCE_REC IN HM_SOURCE_CUR,
                            pv_file_dir IN VARCHAR2,
                            pv_log_file_name IN VARCHAR2
                           )
    RETURN FLD_VALS_TBL
    PIPELINED;
    
    PROCEDURE PR_CIBIL_FILE_LOAD_PARSE  (  pn_batchid IN NUMBER,
                                           pn_batch_seq_number IN NUMBER,
                                           pn_start    IN NUMBER,
                                           pn_end      IN NUMBER,
                                           pv_file_dir          IN VARCHAR2, 
                                           pv_log_file_name     IN VARCHAR2
                                          );

    PROCEDURE PR_CIBIL_FILE_LOAD(pn_batchid IN NUMBER,
                                 pn_batch_seq_number IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2,
                                 pv_file_type IN VARCHAR2 DEFAULT NULL
                                 );
PROCEDURE PR_START_FILE (pv_file_name IN VARCHAR2,
                         pv_file_dir IN VARCHAR2,
                         pv_log_file_name IN VARCHAR2
                        );
    

END PK_LOAD_INQ_FILE; 

/
--------------------------------------------------------
--  DDL for Package PK_MATCH_INVOL_ADD_LOAD_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MATCH_INVOL_ADD_LOAD_V1" 
AS

    gv_error_msg VARCHAR2(4000);
    
    GN_TOTAL_LTC_TABLE_CNT  NUMBER := 56;
    GN_DUMMY_MAX_PRIORITY   NUMBER := 999999999999;
    
    PROCEDURE PR_LTC_COMPLETE_LOAD( pd_inq_from_dt      DATE,
                                    pd_inq_to_dt        DATE,
                                    pv_log_dir          VARCHAR2,
                                    pv_log_file_name    VARCHAR2,
                                    pv_mfi_id           VARCHAR2 DEFAULT NULL
                                  );
                                  
    PROCEDURE PR_LTC_INQUIRY_DUMP( pv_temp_tbl     VARCHAR2,
                                   pn_batch_id     NUMBER,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2
                                 );
                                 
    PROCEDURE PR_LTC_INQ_POPULATE( pd_inq_from_dt  DATE,
                                   pd_inq_to_dt    DATE,
                                   pn_batch_id     NUMBER,
                                   pv_temp_tbl     VARCHAR2,
                                   pv_log_dir      VARCHAR2,
                                   pv_log_file_name     VARCHAR2,
                                   pv_mfi_id       VARCHAR2                                                               
                                 );

    PROCEDURE PR_LTC_BATCH_ID_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );
                                    
    PROCEDURE PR_LTC_PARALLEL_STATUS( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_CALL_LTC_BATCH( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );
                                                              
    PROCEDURE PR_LTC_ID_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );                               
                                         
    PROCEDURE PR_LTC_COMP_DOB_CLUSTER( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );
    
    PROCEDURE PR_LTC_PAR_DOB_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );                                                                                       

    PROCEDURE PR_LTC_PHONE_CLUSTER( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_AGE_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                );

    PROCEDURE PR_LTC_SP_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SC_CLUSTER( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_SCL_CLUSTER( pn_batch_id NUMBER,
                                  pv_log_dir VARCHAR2,
                                  pv_log_file_name VARCHAR2
                                ); 

    PROCEDURE PR_LTC_CNS_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_CNS_103_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_FULL_PHONE_CLUSTER( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_REL_102_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_105_CLUSTER( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_COMP_DOB_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );
                                  
    PROCEDURE PR_LTC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );
                                  
    PROCEDURE PR_LTC_PHONE_LINK( pn_batch_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );

    PROCEDURE PR_LTC_AGE_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_CNS_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_CNS_103_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_FULL_PHONE_LINK( pn_batch_id NUMBER,
                                      pv_log_dir VARCHAR2,
                                      pv_log_file_name VARCHAR2
                                    );

    PROCEDURE PR_LTC_REL_102_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_REL_105_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_SP_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SC_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_SCL_LINK( pn_batch_id NUMBER,
                               pv_log_dir VARCHAR2,
                               pv_log_file_name VARCHAR2
                             );

    PROCEDURE PR_LTC_ID_LINK( pn_batch_id NUMBER,
                              pv_log_dir VARCHAR2,
                              pv_log_file_name VARCHAR2
                            );

    PROCEDURE PR_LTC_PHN_PART_DOB_CLST( pn_batch_id NUMBER,
                                        pv_log_dir       VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_PHN_AGE_CLST( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_PHN_CLST( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_CLST( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_CLST( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SC_PAR_DOB_CLST( pn_batch_id NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );

    PROCEDURE PR_LTC_NAME_PIN_PAR_DOB_CLST( pn_batch_id NUMBER,
                                            pv_log_dir VARCHAR2,
                                            pv_log_file_name VARCHAR2
                                          );

    PROCEDURE PR_LTC_NAME_SC_AGE_CLST( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_AGE_CLST( pn_batch_id NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_SC_REL_CLST( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_REL_CLST( pn_batch_id NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_COMP_DOB_CLST( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );
                                       
    PROCEDURE PR_LTC_PIN_PHONE_CLST( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_PIN_PART_DOB_CLST( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_PHN_PART_DOB_LINK( pn_batch_id NUMBER,
                                        pv_log_dir       VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_PHN_AGE_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_PHN_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SP_LINK( pn_batch_id NUMBER,
                                   pv_log_dir VARCHAR2,
                                   pv_log_file_name VARCHAR2
                                 );

    PROCEDURE PR_LTC_NAME_SCL_LINK( pn_batch_id NUMBER,
                                    pn_total_job NUMBER,
                                    pn_mod NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_NAME_SC_PAR_DOB_LINK( pn_batch_id NUMBER,
                                           pn_total_job NUMBER,
                                           pn_mod NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );

    PROCEDURE PR_LTC_NAME_PIN_PAR_DOB_LINK( pn_batch_id NUMBER,
                                            pn_total_job NUMBER,
                                            pn_mod NUMBER,
                                            pv_log_dir VARCHAR2,
                                            pv_log_file_name VARCHAR2
                                          );

    PROCEDURE PR_LTC_NAME_SC_AGE_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_AGE_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );

    PROCEDURE PR_LTC_NAME_SC_REL_LINK( pn_batch_id NUMBER,
                                       pn_total_job NUMBER,
                                       pn_mod NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

    PROCEDURE PR_LTC_NAME_PIN_REL_LINK( pn_batch_id NUMBER,
                                        pn_total_job NUMBER,
                                        pn_mod NUMBER,
                                        pv_log_dir VARCHAR2,
                                        pv_log_file_name VARCHAR2
                                      );
    
    PROCEDURE PR_LTC_NAME_COMP_DOB_LINK( pn_batch_id NUMBER,
                                         pv_log_dir VARCHAR2,
                                         pv_log_file_name VARCHAR2
                                       );

    PROCEDURE PR_LTC_PIN_PHONE_LINK( pn_batch_id NUMBER,
                                    pv_log_dir VARCHAR2,
                                    pv_log_file_name VARCHAR2
                                  );

    PROCEDURE PR_LTC_PIN_PART_DOB_LINK( pn_batch_id NUMBER,
                                       pv_log_dir VARCHAR2,
                                       pv_log_file_name VARCHAR2
                                     );

END PK_MATCH_INVOL_ADD_LOAD_V1; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_DUMP_CREATION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_DUMP_CREATION" 
IS

    FUNCTION FN_CREATE_DUMP( pn_batch_id NUMBER,
                             pv_partition_name VARCHAR2,
                             pv_report_id VARCHAR2 DEFAULT NULL,
                             pv_bank_name  VARCHAR2 DEFAULT NULL,
                             pv_cand_seln_type VARCHAR2 DEFAULT NULL,
                             pv_cand_seln_rule VARCHAR2 DEFAULT NULL
                           )
    RETURN VARCHAR2;
    
    PROCEDURE PR_MFI_DUMP( pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_report_id VARCHAR2,
                           pv_bank_name  VARCHAR2,
                           pv_cand_seln_type VARCHAR2,
                           pv_cand_seln_rule VARCHAR2,
                           pv_data_file VARCHAR2,
                           pn_dump_file_seq NUMBER
                         );
                         
    PROCEDURE PR_MFI_DUMP_FILE( pn_batch_id NUMBER,
                               pv_partition_name VARCHAR2,
                               pv_bank_name  VARCHAR2,
                               pv_data_file  VARCHAR2,
                               pv_tbl_name       VARCHAR2,
                               pv_recall_condition VARCHAR2,
                               pn_dump_file_seq NUMBER
                             );

    
END; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_INQ_REPORT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_INQ_REPORT" 
AS 
    
    
PROCEDURE PR_CALL_DP (pv_reporting_member   IN VARCHAR2, 
                      pn_batchid            IN NUMBER, 
                      pv_stage              IN VARCHAR2,
                      pv_file_dir           IN VARCHAR2, 
                      pv_log_file_name      IN VARCHAR2
                      );
PROCEDURE PR_CALL_JAVA_REPORT (pv_process IN VARCHAR2,
                               pv_reporting_member   IN VARCHAR2,
                               pn_batchid IN NUMBER,
                               pv_java_str_replay IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 ,
                               pv_log_file_name IN VARCHAR2);
                               
PROCEDURE PR_CALL_INQ_REPORT;


    EX_NORMAL_RET    EXCEPTION;
    EX_BATCH_FAILED  EXCEPTION;
    EX_SEQ_FAILED    EXCEPTION;
        
     
END PK_MFI_INQ_REPORT; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_INQ_REPORT_NEW
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_INQ_REPORT_NEW" 
AS 
    
    
PROCEDURE PR_CALL_DP (pv_reporting_member   IN VARCHAR2, 
                      pn_batchid            IN NUMBER, 
                      pv_stage              IN VARCHAR2,
                      pv_file_dir           IN VARCHAR2, 
                      pv_log_file_name      IN VARCHAR2
                      );
PROCEDURE PR_CALL_JAVA_REPORT (pv_process IN VARCHAR2,
                               pv_reporting_member   IN VARCHAR2,
                               pn_batchid IN NUMBER,
                               pv_java_str_replay IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 ,
                               pv_log_file_name IN VARCHAR2);
                               
PROCEDURE PR_CALL_INQ_REPORT(gv_from_dt VARCHAR2,
                                gv_to_dt   VARCHAR2,
                                gv_contributor_id VARCHAR2 DEFAULT NULL);


    EX_NORMAL_RET    EXCEPTION;
    EX_BATCH_FAILED  EXCEPTION;
    EX_SEQ_FAILED    EXCEPTION;
        
     
END PK_MFI_INQ_REPORT_NEW; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_INQ_REPORT_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_INQ_REPORT_V1" 
AS 
    
    
PROCEDURE PR_CALL_DP (pv_reporting_member   IN VARCHAR2, 
                      pn_batchid            IN NUMBER, 
                      pv_stage              IN VARCHAR2,
                      pv_file_dir           IN VARCHAR2, 
                      pv_log_file_name      IN VARCHAR2
                      );
PROCEDURE PR_CALL_JAVA_REPORT (pv_process IN VARCHAR2,
                               pv_reporting_member   IN VARCHAR2,
                               pn_batchid IN NUMBER,
                               pv_java_str_replay IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 ,
                               pv_log_file_name IN VARCHAR2);
                               
PROCEDURE PR_CALL_INQ_REPORT(gv_from_dt VARCHAR2,
                                gv_to_dt   VARCHAR2,
                                gv_contributor_id VARCHAR2 DEFAULT NULL);


    EX_NORMAL_RET    EXCEPTION;
    EX_BATCH_FAILED  EXCEPTION;
    EX_SEQ_FAILED    EXCEPTION;
        
     
END PK_MFI_INQ_REPORT_V1; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_INQ_REPORT_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_INQ_REPORT_V2" 
AS 
    
    
PROCEDURE PR_CALL_DP (pv_reporting_member   IN VARCHAR2, 
                      pn_batchid            IN NUMBER, 
                      pv_stage              IN VARCHAR2,
                      pv_file_dir           IN VARCHAR2, 
                      pv_log_file_name      IN VARCHAR2
                      );
PROCEDURE PR_CALL_JAVA_REPORT (pv_process IN VARCHAR2,
                               pv_reporting_member   IN VARCHAR2,
                               pn_batchid IN NUMBER,
                               pv_java_str_replay IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 ,
                               pv_log_file_name IN VARCHAR2);
                               
PROCEDURE PR_CALL_INQ_REPORT(gv_from_dt VARCHAR2,
                                gv_to_dt   VARCHAR2,
                                gv_contributor_id VARCHAR2 DEFAULT NULL);


    EX_NORMAL_RET    EXCEPTION;
    EX_BATCH_FAILED  EXCEPTION;
    EX_SEQ_FAILED    EXCEPTION;
        
     
END PK_MFI_INQ_REPORT_V2; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_OLM_EXECUTION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_OLM_EXECUTION" 
AS 
    PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


    -- PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
    PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);
 
    PROCEDURE PR_OLM_DATA_DELETE(pn_olm_request_id IN NUMBER);

  
    PROCEDURE PR_ALTER_TABLE ( pn_olm_req_id  IN NUMBER,
                               gv_file_dir in VARCHAR2,
                               gv_log_file_name in VARCHAR2
                             );
        gv_sql VARCHAR2(32767) := '';
        gv_file_dir VARCHAR2(100) := 'LOAD_FILE_LOCATION';
        gv_log_file_name VARCHAR2(32767);
        EX_BATCH_FAILED EXCEPTION;
        gn_check NUMBER;
        gn_check1 NUMBER;
        ln_status NUMBER;
        gv_primary_contacts     VARCHAR2(32767) := 'febin.puthur@highmark.in,soumya.ranjan@highmark.in,abhijeet.singh@highmark.in,prashant.verma@highmark.in';  

END PK_MFI_OLM_EXECUTION; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_OLM_MERGE_EXECUTION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_OLM_MERGE_EXECUTION" 
AS
gv_result VARCHAR2(100);
gn_temp_seq VARCHAR2(100);
gv_file_dir VARCHAR2(100) := 'LOAD_FILE_LOCATION';
gv_log_file_name VARCHAR2(1000);
gn_olm_req_id NUMBER;
EC_EXCEPTION EXCEPTION;
EX_NORMAL_RET EXCEPTION;
NO_ACTION_TYPE_FOUND EXCEPTION;
NO_BUREAU_TYPE_FOUND EXCEPTION;
TYPE REF_CUR IS REF CURSOR;
gv_file_name VARCHAR2(100);

gv_data_support VARCHAR2(10000):='datasupport@highmark.in,mfi_operations@highmark.in';
gv_primary_contacts VARCHAR2(10000):='abhijeet.singh@highmark.in,prashant.verma@highmark.in,soumya.ranjan@highmark.in,febin.puthur@highmark.in';
                            
PROCEDURE PR_MFI_BUR_MERGE (pn_req_no IN NUMBER,
                            pv_mfi VARCHAR2,
                            pv_file_dir IN VARCHAR2,
                            pv_log_file_name IN VARCHAR2
                           );
PROCEDURE PR_MFI_BUR_DELETE (pn_cns_key IN NUMBER,
                             pv_mfi VARCHAR2,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                           );  
                           
END PK_MFI_OLM_MERGE_EXECUTION; 

/
--------------------------------------------------------
--  DDL for Package PK_MFI_OLM_MERGE_EXECUTION_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_MFI_OLM_MERGE_EXECUTION_V1" 
AS
gv_result VARCHAR2(100);
gn_temp_seq VARCHAR2(100);
gv_file_dir VARCHAR2(100) := 'LOAD_FILE_LOCATION';
gv_log_file_name VARCHAR2(1000);
gn_olm_req_id NUMBER;
EC_EXCEPTION EXCEPTION;
EX_NORMAL_RET EXCEPTION;
NO_ACTION_TYPE_FOUND EXCEPTION;
NO_BUREAU_TYPE_FOUND EXCEPTION;
TYPE REF_CUR IS REF CURSOR;
gv_file_name VARCHAR2(100);

gv_data_support VARCHAR2(10000):='datasupport@highmark.in,mfi_operations@highmark.in';
gv_primary_contacts VARCHAR2(10000):='abhijeet.singh@highmark.in,prashant.verma@highmark.in,soumya.ranjan@highmark.in,febin.puthur@highmark.in';
                            
PROCEDURE PR_MFI_BUR_MERGE (pv_mfi VARCHAR2,
                            pv_file_dir IN VARCHAR2,
                            pv_log_file_name IN VARCHAR2
                           );
PROCEDURE PR_MFI_BUR_DELETE (pn_cns_key IN NUMBER,
                             pv_mfi VARCHAR2,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2 
                           );  
                           
END PK_MFI_OLM_MERGE_EXECUTION_V1; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION" 
AS
    gv_result                 VARCHAR2(100);
    gn_temp_seq               VARCHAR2(100);
    gv_file_dir               VARCHAR2(100) := 'CIBIL_LOG';
    gn_user_id                NUMBER;
    gv_log_file_name          VARCHAR2(1000);
    gn_olm_req_id             NUMBER;
    EC_EXCEPTION              EXCEPTION;
    EX_NORMAL_RET             EXCEPTION;
    NO_ACTION_TYPE_FOUND      EXCEPTION;
    NO_BUREAU_TYPE_FOUND      EXCEPTION;
    gv_file_name              VARCHAR2(100);
    
    gv_data_support           VARCHAR2(10000):='datasupport@crifhighmark.com,mfi_operations@crifhighmark.com';
    gv_primary_contacts       VARCHAR2(10000):='febin.puthur@crifhighmark.com,prashant.verma@crifhighmark.com,soumya.ranjan@crifhighmark.com';
    
    
    TYPE REF_CUR IS REF CURSOR;
    DUPLICATE_FLAG BOOLEAN:=FALSE;

    
    PROCEDURE PR_INITIATE_OLM ( pv_file_name IN VARCHAR2,
                                pv_result OUT VARCHAR2
                              );
    
    PROCEDURE PR_DISTRIBUTE_OLM_PROCESS;
    
    PROCEDURE PR_START_PROCESS (pv_file_name IN VARCHAR2);
    
    PROCEDURE PR_CREATE_TBL (
                             pv_bureau IN VARCHAR2,
                             pv_action IN VARCHAR2,
                             pv_mfi    IN VARCHAR2
                            );

    PROCEDURE PR_UPDATE_OLM_TRACKING(pn_olm_req_id IN NUMBER,
                                     pv_file_dir IN VARCHAR2,
                                     pv_log_file_name IN VARCHAR2
                                    );  
                                
    PROCEDURE PR_CNS_BUR_MERGE (pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2
                               );
                               
    PROCEDURE PR_CNS_BUR_DELETE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );  
                               
    PROCEDURE PR_COMM_BUR_MERGE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                               
    PROCEDURE PR_CNS_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                                   pv_file_dir IN VARCHAR2,
                                   pv_log_file_name IN VARCHAR2
                                  );
                                  
    PROCEDURE PR_COMM_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                                    pv_file_dir IN VARCHAR2,
                                    pv_log_file_name IN VARCHAR2
                                   );
                                  
    PROCEDURE PR_MFI_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                                   pv_file_dir IN VARCHAR2,
                                   pv_log_file_name IN VARCHAR2
                                  );
                                  
    PROCEDURE PR_START_OLM_JOB (pv_file_name IN VARCHAR2,
                                pv_out_parameter OUT VARCHAR2,
                                pn_user_id IN NUMBER DEFAULT NULL, 
                                pf_flag IN BOOLEAN DEFAULT NULL
                               );
                                
    PROCEDURE PR_UPDATE_MASTER_TRKG (pv_file_name IN VARCHAR2,
                                     pv_status IN VARCHAR,
                                     Pv_ERROR IN VARCHAR2 DEFAULT NULL
                                    );

    PROCEDURE PR_COMM_BUR_DELETE (pn_olm_req_id IN NUMBER,
                                  pv_mfi VARCHAR2,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 ); 
                                 
    PROCEDURE PR_MFI_BUR_DELETE (pn_cns_key IN NUMBER,
                                 pv_mfi IN VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                                
    PROCEDURE PR_MFI_BUR_MERGE (pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2
                               );                                                         

    PROCEDURE PR_MFI_BUR_MERGE_CNS (pn_olm_req_id IN NUMBER,
                                    pv_mfi VARCHAR2,
                                    pv_file_dir IN VARCHAR2,
                                    pv_log_file_name IN VARCHAR2                            
                                   );
                                   
    PROCEDURE PR_CNS_TOTAL_DATA_DELETE (pn_olm_req_id IN NUMBER,
                                        pv_mfi VARCHAR2,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                       ); 
    PROCEDURE PR_DELETE_ANY_TABLE(pv_tab_name IN VARCHAR2,
                                  pv_partition IN VARCHAR2,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 );
                                 
    procedure PR_LTC_STD_CNS_DELETE (pv_tab_name Varchar2,
                                     pn_olm_req_id NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                     );
                                   
    PROCEDURE PR_INQ_IOI_CANDIDATE_DEL_R02(pv_table_name VARCHAR2,
                                           pn_olm_req_id NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                           );                         
                                                                   
    PROCEDURE PR_MFI_DPD_UPDATE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                ); 

    PROCEDURE PR_CNS_DPD_UPDATE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                ); 
                                
    PROCEDURE PR_COMM_DPD_UPDATE (pn_olm_req_id IN NUMBER,
                                  pv_mfi VARCHAR2,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 );
                                  
    PROCEDURE PR_UPDATE_MASTER_OLM_REQ_NBR (pv_file_name IN VARCHAR2,
                                            pn_olm_req_no IN NUMBER);
                                            
    PROCEDURE PR_CNS_ENRICH_OLM (pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                                
    PROCEDURE PR_MFI_ENRICH_OLM (pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                                                                                                                         
    PROCEDURE PR_COMM_ENRICH_OLM (pn_olm_req_id IN NUMBER,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 );
                                              
    PROCEDURE PR_CNS_ENRICH_CLOSED_OLM (pn_olm_req_id IN NUMBER,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                       );
                                       
    PROCEDURE PR_MFI_ENRICH_CLOSED_OLM (pn_olm_req_id IN NUMBER,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                       );
                                                                                                                               
    PROCEDURE PR_COMM_ENRICH_CLOSED_OLM (pn_olm_req_id IN NUMBER,
                                         pv_file_dir IN VARCHAR2,
                                         pv_log_file_name IN VARCHAR2
                                        );
                                        
    PROCEDURE PR_ACT_VAR_MERGE (pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2
                                );  
                                
    PROCEDURE PR_CNS_DPD_UPDATE_AMEX ( 
                                      pn_olm_req_id IN NUMBER,
                                      pv_mfi VARCHAR2,
                                      pv_file_dir IN VARCHAR2,
                                      pv_log_file_name IN VARCHAR2
                                     );
                                     
    PROCEDURE PR_CNS_BUR_SUPPRESS_AMEX (pn_olm_req_id IN NUMBER,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                        );
                                        
    PROCEDURE PR_CNS_ENRICH_CLOSED_OLM_AMEX (pn_olm_req_id IN NUMBER,
                                             pv_file_dir IN VARCHAR2,
                                             pv_log_file_name IN VARCHAR2
                                            );

    PROCEDURE PR_CNS_ENRICH_OLM_AMEX(pn_olm_req_id IN NUMBER,
                                     pv_file_dir IN VARCHAR2,
                                     pv_log_file_name IN VARCHAR2
                                    );                                                                                                                                                                                               
                                                                                                                  
END PK_OLM_EXECUTION; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_1" 
AS
gv_result VARCHAR2(100);
gn_temp_seq VARCHAR2(100);
gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
gv_log_file_name VARCHAR2(1000);
gn_olm_req_id NUMBER;
EC_EXCEPTION EXCEPTION;
EX_NORMAL_RET EXCEPTION;
NO_ACTION_TYPE_FOUND EXCEPTION;
NO_BUREAU_TYPE_FOUND EXCEPTION;
TYPE REF_CUR IS REF CURSOR;
gv_file_name VARCHAR2(100);
DUPLICATE_FLAG BOOLEAN:=FALSE;

gv_data_support VARCHAR2(10000):='abhijeet.singh@highmark.in';
gv_primary_contacts VARCHAR2(10000):='prashant.verma@highmark.in,soumya.ranjan@highmark.in,febin.puthur@highmark.in';
PROCEDURE PR_INITIATE_OLM ( pv_file_name IN VARCHAR2,
                            pv_result OUT VARCHAR2
                          );
PROCEDURE PR_DISTRIBUTE_OLM_PROCESS;
PROCEDURE PR_START_PROCESS (pv_file_name IN VARCHAR2);
PROCEDURE PR_CREATE_TBL (
                                    pv_bureau IN VARCHAR2,
                                    pv_action IN VARCHAR2,
                                    pv_mfi    IN VARCHAR2
                                  );
                                         
PROCEDURE PR_CONSUMER_BUR_UPDATE(pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );               

PROCEDURE PR_COMMERCIAL_BUR_UPDATE(pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );

PROCEDURE PR_MFI_BUR_UPDATE(pn_olm_req_id IN NUMBER,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                            ) ;
PROCEDURE PR_CNS_INSERT_OLM (pn_olm_req_id IN NUMBER,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                            );
PROCEDURE PR_UPDATE_OLM_TRACKING(pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );  
PROCEDURE PR_MFI_INSERT_OLM (pn_olm_req_id IN NUMBER,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                            );
PROCEDURE PR_COMM_INSERT_OLM (pn_olm_req_id IN NUMBER,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                            );
                            
PROCEDURE PR_CNS_BUR_MERGE (pn_olm_req_id IN NUMBER,
                            pv_mfi VARCHAR2,
                            pv_file_dir IN VARCHAR2,
                            pv_log_file_name IN VARCHAR2
                           );
PROCEDURE PR_CNS_BUR_DELETE (pn_olm_req_id IN NUMBER,
                             pv_mfi VARCHAR2,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                           );  
PROCEDURE PR_COMM_BUR_MERGE (pn_olm_req_id IN NUMBER,
                             pv_mfi VARCHAR2,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                           );
PROCEDURE PR_CNS_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                               pv_file_dir IN VARCHAR2,
                               pv_log_file_name IN VARCHAR2
                              );
PROCEDURE PR_COMM_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                               pv_file_dir IN VARCHAR2,
                               pv_log_file_name IN VARCHAR2
                              );
PROCEDURE PR_MFI_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                               pv_file_dir IN VARCHAR2,
                               pv_log_file_name IN VARCHAR2
                              );
PROCEDURE PR_START_OLM_JOB (pv_file_name IN VARCHAR2, 
                             pv_out_parameter OUT VARCHAR2,
                             pf_flag IN BOOLEAN DEFAULT NULL
                            );
PROCEDURE PR_UPDATE_MASTER_TRKG (pv_file_name IN VARCHAR2,
                                 pv_status IN VARCHAR,
                                 Pv_ERROR IN VARCHAR2 DEFAULT NULL
                                );

PROCEDURE PR_COMM_BUR_DELETE (pn_olm_req_id IN NUMBER,
                             pv_mfi VARCHAR2,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                           ); 
PROCEDURE PR_MFI_BUR_DELETE (pn_cns_key IN NUMBER,
                             pv_mfi IN VARCHAR2,
                             pv_file_dir IN VARCHAR2,
                             pv_log_file_name IN VARCHAR2
                           );
PROCEDURE PR_MFI_BUR_MERGE (pn_olm_req_id IN NUMBER,
                            pv_mfi VARCHAR2,
                            pv_file_dir IN VARCHAR2,
                            pv_log_file_name IN VARCHAR2
                           );                                                         

PROCEDURE PR_MFI_BUR_MERGE_CNS (
                                pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2                            
                               );
                               
PROCEDURE PR_CNS_TOTAL_DATA_DELETE ( 
                                     pn_olm_req_id IN NUMBER,
                                     pv_mfi VARCHAR2,
                                     pv_file_dir IN VARCHAR2,
                                     pv_log_file_name IN VARCHAR2
                                    ); 
PROCEDURE PR_DELETE_ANY_TABLE(
                              pv_tab_name IN VARCHAR2,
                              pv_partition IN VARCHAR2,
                              pv_file_dir IN VARCHAR2,
                              pv_log_file_name IN VARCHAR2
                             );
PROCEDURE PR_LTC_STD_CNS_DELETE( pn_olm_req_id NUMBER,
                                 pv_log_dir VARCHAR2,
                                 pv_log_file_name VARCHAR2
                               );
PROCEDURE PR_INQ_MATCH_INVOL_DELETE_R02  ( pn_olm_req_id NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                         );
                               
                             
                                                               
                                                             
                                                          
END PK_OLM_EXECUTION_1; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_AMEX
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_AMEX" 
AS
    gv_result                 VARCHAR2(100);
    gn_temp_seq               VARCHAR2(100);
    gv_file_dir               VARCHAR2(100) := 'CIBIL_LOG';
    gn_user_id                NUMBER;
    gv_log_file_name          VARCHAR2(1000);
    gn_olm_req_id             NUMBER;
    EC_EXCEPTION              EXCEPTION;
    EX_NORMAL_RET             EXCEPTION;
    NO_ACTION_TYPE_FOUND      EXCEPTION;
    NO_BUREAU_TYPE_FOUND      EXCEPTION;
    gv_file_name              VARCHAR2(100);
    
    gv_data_support           VARCHAR2(10000):='datasupport@crifhighmark.com,mfi_operations@crifhighmark.com';
    gv_primary_contacts       VARCHAR2(10000):='febin.puthur@crifhighmark.com,prashant.verma@crifhighmark.com,soumya.ranjan@crifhighmark.com';
    
    
    TYPE REF_CUR IS REF CURSOR;
    DUPLICATE_FLAG BOOLEAN:=FALSE;

    
    PROCEDURE PR_INITIATE_OLM ( pv_file_name IN VARCHAR2,
                                pv_result OUT VARCHAR2
                              );
    
    PROCEDURE PR_DISTRIBUTE_OLM_PROCESS;
    
    PROCEDURE PR_START_PROCESS (pv_file_name IN VARCHAR2);
    
    PROCEDURE PR_CREATE_TBL (
                             pv_bureau IN VARCHAR2,
                             pv_action IN VARCHAR2,
                             pv_mfi    IN VARCHAR2
                            );

    PROCEDURE PR_UPDATE_OLM_TRACKING(pn_olm_req_id IN NUMBER,
                                     pv_file_dir IN VARCHAR2,
                                     pv_log_file_name IN VARCHAR2
                                    );  
                                
    PROCEDURE PR_CNS_BUR_MERGE (pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2
                               );
                               
    PROCEDURE PR_CNS_BUR_DELETE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );  
                               
    PROCEDURE PR_COMM_BUR_MERGE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                               
    PROCEDURE PR_CNS_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                                   pv_file_dir IN VARCHAR2,
                                   pv_log_file_name IN VARCHAR2
                                  );
                                  
    PROCEDURE PR_COMM_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                                    pv_file_dir IN VARCHAR2,
                                    pv_log_file_name IN VARCHAR2
                                   );
                                  
    PROCEDURE PR_MFI_BUR_SUPPRESS (pn_olm_req_id IN NUMBER,
                                   pv_file_dir IN VARCHAR2,
                                   pv_log_file_name IN VARCHAR2
                                  );
                                  
    PROCEDURE PR_START_OLM_JOB (pv_file_name IN VARCHAR2,
                                pv_out_parameter OUT VARCHAR2,
                                pn_user_id IN NUMBER DEFAULT NULL, 
                                pf_flag IN BOOLEAN DEFAULT NULL
                               );
                                
    PROCEDURE PR_UPDATE_MASTER_TRKG (pv_file_name IN VARCHAR2,
                                     pv_status IN VARCHAR,
                                     Pv_ERROR IN VARCHAR2 DEFAULT NULL
                                    );

    PROCEDURE PR_COMM_BUR_DELETE (pn_olm_req_id IN NUMBER,
                                  pv_mfi VARCHAR2,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 ); 
                                 
    PROCEDURE PR_MFI_BUR_DELETE (pn_cns_key IN NUMBER,
                                 pv_mfi IN VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                                
    PROCEDURE PR_MFI_BUR_MERGE (pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2
                               );                                                         

    PROCEDURE PR_MFI_BUR_MERGE_CNS (pn_olm_req_id IN NUMBER,
                                    pv_mfi VARCHAR2,
                                    pv_file_dir IN VARCHAR2,
                                    pv_log_file_name IN VARCHAR2                            
                                   );
                                   
    PROCEDURE PR_CNS_TOTAL_DATA_DELETE (pn_olm_req_id IN NUMBER,
                                        pv_mfi VARCHAR2,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                       ); 
    PROCEDURE PR_DELETE_ANY_TABLE(pv_tab_name IN VARCHAR2,
                                  pv_partition IN VARCHAR2,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 );
                                 
    procedure PR_LTC_STD_CNS_DELETE (pv_tab_name Varchar2,
                                     pn_olm_req_id NUMBER,
                                     pv_log_dir VARCHAR2,
                                     pv_log_file_name VARCHAR2
                                     );
                                   
    PROCEDURE PR_INQ_IOI_CANDIDATE_DEL_R02(pv_table_name VARCHAR2,
                                           pn_olm_req_id NUMBER,
                                           pv_log_dir VARCHAR2,
                                           pv_log_file_name VARCHAR2
                                           );                         
                                                                   
    PROCEDURE PR_MFI_DPD_UPDATE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                ); 

    PROCEDURE PR_CNS_DPD_UPDATE (pn_olm_req_id IN NUMBER,
                                 pv_mfi VARCHAR2,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                ); 
                                
    PROCEDURE PR_COMM_DPD_UPDATE (pn_olm_req_id IN NUMBER,
                                  pv_mfi VARCHAR2,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 );
                                  
    PROCEDURE PR_UPDATE_MASTER_OLM_REQ_NBR (pv_file_name IN VARCHAR2,
                                            pn_olm_req_no IN NUMBER);
                                            
    PROCEDURE PR_CNS_ENRICH_OLM (pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                                
    PROCEDURE PR_MFI_ENRICH_OLM (pn_olm_req_id IN NUMBER,
                                 pv_file_dir IN VARCHAR2,
                                 pv_log_file_name IN VARCHAR2
                                );
                                                                                                                         
    PROCEDURE PR_COMM_ENRICH_OLM (pn_olm_req_id IN NUMBER,
                                  pv_file_dir IN VARCHAR2,
                                  pv_log_file_name IN VARCHAR2
                                 );
                                              
    PROCEDURE PR_CNS_ENRICH_CLOSED_OLM (pn_olm_req_id IN NUMBER,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                       );
                                       
    PROCEDURE PR_MFI_ENRICH_CLOSED_OLM (pn_olm_req_id IN NUMBER,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                       );
                                                                                                                               
    PROCEDURE PR_COMM_ENRICH_CLOSED_OLM (pn_olm_req_id IN NUMBER,
                                         pv_file_dir IN VARCHAR2,
                                         pv_log_file_name IN VARCHAR2
                                        );
                                        
    PROCEDURE PR_ACT_VAR_MERGE (pn_olm_req_id IN NUMBER,
                                pv_mfi VARCHAR2,
                                pv_file_dir IN VARCHAR2,
                                pv_log_file_name IN VARCHAR2
                                );  
                                
    PROCEDURE PR_CNS_DPD_UPDATE_AMEX ( 
                                      pn_olm_req_id IN NUMBER,
                                      pv_mfi VARCHAR2,
                                      pv_file_dir IN VARCHAR2,
                                      pv_log_file_name IN VARCHAR2
                                     );
                                     
    PROCEDURE PR_CNS_BUR_SUPPRESS_AMEX (pn_olm_req_id IN NUMBER,
                                        pv_file_dir IN VARCHAR2,
                                        pv_log_file_name IN VARCHAR2
                                        );
                                        
    PROCEDURE PR_CNS_ENRICH_CLOSED_OLM_AMEX (pn_olm_req_id IN NUMBER,
                                             pv_file_dir IN VARCHAR2,
                                             pv_log_file_name IN VARCHAR2
                                            );

    PROCEDURE PR_CNS_ENRICH_OLM_AMEX(pn_olm_req_id IN NUMBER,
                                     pv_file_dir IN VARCHAR2,
                                     pv_log_file_name IN VARCHAR2
                                    );                                                                                                                                                                                               
                                                                                                                  
END PK_OLM_EXECUTION_AMEX; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_TEST
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_TEST" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

  PROCEDURE PR_ALTER_TABLE ( pn_olm_req_id  IN NUMBER
                          );
  gv_sql VARCHAR2(32767) := '';
  gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
  gv_log_file_name VARCHAR2(32767);
  EX_BATCH_FAILED EXCEPTION;
  gn_check NUMBER;
  gn_check1 NUMBER;
  ln_status NUMBER;

END PK_OLM_EXECUTION_TEST; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_V1
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_V1" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

 PROCEDURE PR_ALTER_TABLE ( pv_schema_name IN VARCHAR2,
                            pv_tbl_name IN  VARCHAR2,
                            pv_act_name IN  VARCHAR2,
                            pv_part_name  IN VARCHAR2
                            );

  gv_file_dir varchar2(100) := 'CIBIL_LOG';
  gv_log_file_name varchar2(32767);
  EX_BATCH_FAILED EXCEPTION;

END PK_OLM_EXECUTION_V1; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_V2
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_V2" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

 PROCEDURE PR_ALTER_TABLE ( pv_schema_name IN VARCHAR2,
                            pv_tbl_name IN  VARCHAR2,
                            pv_act_name IN  VARCHAR2,
                            pv_part_name  IN VARCHAR2
                            );
  gv_sql VARCHAR2(32767) := '';
  gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
  gv_log_file_name VARCHAR2(32767);
  EX_BATCH_FAILED EXCEPTION;
  gn_check NUMBER;
  gn_check1 NUMBER;

END PK_OLM_EXECUTION_V2; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_V3
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_V3" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

  PROCEDURE PR_ALTER_TABLE ( pn_olm_req_id  IN NUMBER
                          );
  gv_sql VARCHAR2(32767) := '';
  gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
  gv_log_file_name VARCHAR2(32767);
  EX_BATCH_FAILED EXCEPTION;
  gn_check NUMBER;
  gn_check1 NUMBER;

END PK_OLM_EXECUTION_V3; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_V5
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_V5" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

  PROCEDURE PR_ALTER_TABLE ( pn_olm_req_id  IN NUMBER
                          );
  gv_sql VARCHAR2(32767) := '';
  gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
  gv_log_file_name VARCHAR2(32767);
  EX_BATCH_FAILED EXCEPTION;
  gn_check NUMBER;
  gn_check1 NUMBER;
  ln_status NUMBER;

END PK_OLM_EXECUTION_V5; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_V6
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_V6" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

  
 PROCEDURE PR_ALTER_TABLE ( pn_olm_req_id  IN NUMBER,
                            gv_file_dir in VARCHAR2,
                            gv_log_file_name in VARCHAR2
                          );
  gv_sql VARCHAR2(32767) := '';
  gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
  gv_log_file_name VARCHAR2(32767);
  EX_BATCH_FAILED EXCEPTION;
  gn_check NUMBER;
  gn_check1 NUMBER;
  ln_status NUMBER;

END PK_OLM_EXECUTION_v6; 

/
--------------------------------------------------------
--  DDL for Package PK_OLM_EXECUTION_V7
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_OLM_EXECUTION_V7" 
AS 
 PROCEDURE PR_OLM_EXEC_START (pn_olm_request_id IN NUMBER);


 PROCEDURE PR_OLM_EXEC (pn_olm_request_id IN NUMBER);
 
 PROCEDURE PR_CREATE_BACKUP_TBL_OLM(pn_olm_request_id IN NUMBER);

  
 PROCEDURE PR_ALTER_TABLE ( pn_olm_req_id  IN NUMBER,
                            gv_file_dir in VARCHAR2,
                            gv_log_file_name in VARCHAR2
                          );
  gv_sql VARCHAR2(32767) := '';
  gv_file_dir VARCHAR2(100) := 'CIBIL_LOG';
  gv_log_file_name VARCHAR2(32767);
  EX_BATCH_FAILED EXCEPTION;
  gn_check NUMBER;
  gn_check1 NUMBER;
  ln_status NUMBER;

END PK_OLM_EXECUTION_V7; 

/
--------------------------------------------------------
--  DDL for Package PK_PIN_PROXIMITY
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_PIN_PROXIMITY" 
AS

TYPE CUR_SELECT IS REF CURSOR;

PROCEDURE PR_PIN_PROXIMITY;

PROCEDURE PR_PIN_PROXIMITY_DUMP(pv_partition_name IN VARCHAR2);

END PK_PIN_PROXIMITY; 

/
--------------------------------------------------------
--  DDL for Package PK_PNP_COUNT_CALL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_PNP_COUNT_CALL" 
IS
    
    GN_LN_COUNT_PIN NUMBER;

    TYPE CUR_VAL IS REF CURSOR;
    
    
    
    TYPE CUR_MATCH   IS REF CURSOR;
    TYPE CUR_UNMATCH IS REF CURSOR;
    

    PROCEDURE PR_PNP_COUNT ( 
                              pn_user_id                    IN VARCHAR2,
                              pv_cust_id                    IN VARCHAR2,
                              pv_product_id                 IN NUMBER,
                              pv_state_district_name        IN VARCHAR2,
                              pv_flag                       IN VARCHAR2,
                              CUR_SEL                       OUT CUR_VAL,

                              pn_trail_volume               OUT VARCHAR2,
                              pn_trial_mode_total_used      OUT VARCHAR2,
                              pn_trail_price                OUT VARCHAR2,
                              pn_trail_fresh_request        OUT VARCHAR2,
                                                                                                                
                              pn_fixed_volume               OUT VARCHAR2,
                              pn_fixed_mode_total_used      OUT VARCHAR2,
                              pn_fixed_price                OUT VARCHAR2,
                              pn_fixed_fresh_request        OUT VARCHAR2,
                                                                                                                
                              pn_normal_volume              OUT VARCHAR2,
                              pn_normal_mode_total_used     OUT VARCHAR2,
                              pn_normal_price               OUT VARCHAR2,
                              pn_normal_fresh_request       OUT VARCHAR2,
                              
                              pn_number_of_request          OUT VARCHAR2                                                                                  
                         ) ;
                         
    PROCEDURE PR_PINCODES_LIST (  
                                   pv_state_district_name        IN VARCHAR2,
                                   pv_flag                       IN VARCHAR2,
                                   pn_cid                        NUMBER,
                                   CUR_MATCH                     OUT CUR_VAL,
                                   CUR_UNMATCH                   OUT CUR_VAL
                                );          


END PK_PNP_COUNT_CALL; 

/
--------------------------------------------------------
--  DDL for Package PK_REVIEW_DUMP_CREATION
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_REVIEW_DUMP_CREATION" 
IS

    FUNCTION FN_CREATE_DUMP( pn_batch_id NUMBER,
                             pv_partition_name VARCHAR2,
                             pv_bureau VARCHAR2,
                             pv_report_id VARCHAR2 DEFAULT NULL,
                             pv_cand_seln_type VARCHAR2 DEFAULT NULL,
                             pv_cand_seln_rule VARCHAR2 DEFAULT NULL
                           )
    RETURN VARCHAR2;
    
    PROCEDURE PR_MFI_DUMP( pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_report_id VARCHAR2,
                           pv_cand_seln_type VARCHAR2,
                           pv_cand_seln_rule VARCHAR2,
                           pv_data_file VARCHAR2,
                           pn_dump_file_seq NUMBER
                         );
                         
    PROCEDURE PR_MFI_DUMP_FILE( pn_batch_id NUMBER,
                               pv_partition_name VARCHAR2,
                               pv_data_file  VARCHAR2,
                               pv_tbl_name       VARCHAR2,
                               pv_recall_condition VARCHAR2,
                               pn_dump_file_seq NUMBER
                             );

    PROCEDURE PR_CNS_DUMP( pn_batch_id NUMBER,
                           pv_partition_name VARCHAR2,
                           pv_report_id VARCHAR2,
                           pv_cand_seln_type VARCHAR2,
                           pv_cand_seln_rule VARCHAR2,
                           pv_data_file VARCHAR2,
                           pn_dump_file_seq NUMBER
                         );
                         
    PROCEDURE PR_CNS_DUMP_FILE( pn_batch_id NUMBER,
                               pv_partition_name VARCHAR2,
                               pv_data_file  VARCHAR2,
                               pv_tbl_name       VARCHAR2,
                               pv_recall_condition VARCHAR2,
                               pn_dump_file_seq NUMBER
                             );    
END; 

/
--------------------------------------------------------
--  DDL for Package PK_UTILITIES
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_UTILITIES" 
AS

--GIREESH
    PROCEDURE pr_log_file_manage (pv_ind    IN VARCHAR2,
                                  pv_dir    IN VARCHAR2,
                                  pv_fname  IN VARCHAR2,
                                  pv_data   IN VARCHAR2 DEFAULT NULL
                                  );

    PROCEDURE PR_CREATE_INDEX (pv_index_type IN VARCHAR2,
                               pv_schema_name IN VARCHAR2,
                               pv_index_name IN VARCHAR2,
                               pv_table_name IN VARCHAR2,
                               pv_column_name IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 DEFAULT NULL,
                               pv_log_file_name IN VARCHAR2 DEFAULT NULL
                               );

    PROCEDURE PR_DROP_INDEX (pv_schema_name IN VARCHAR2,
                             pv_object_name IN VARCHAR2,
                             pv_file_dir IN VARCHAR2 DEFAULT NULL,
                             pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                             pb_table       IN BOOLEAN DEFAULT TRUE
                             );

    PROCEDURE PR_ANALYZE_TABLE (pn_estimate_percent IN NUMBER,
                                pv_part_name   IN VARCHAR2,
                                pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_REBUILD_INDEX (pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_CREATE_PARTITION ( pv_schema_name IN VARCHAR2,
                                    pv_table_name  IN VARCHAR2,
                                    pn_batchid     IN NUMBER,
                                    pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                    pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                    );
    
    PROCEDURE PR_MAKE_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_table IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_MAKE_PROD_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                            pv_table_name  IN VARCHAR2,
                                            pv_mfi         IN VARCHAR2,
                                            pb_table IN BOOLEAN DEFAULT TRUE,
                                            pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                            pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                          );

    PROCEDURE PR_REBUILD_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_REBUILD_PR_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_mfi     IN VARCHAR2,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DROP_PARTITION 
                                     ( pn_batchid     IN NUMBER,
                                       pn_keep_till   IN NUMBER,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                                       pv_table         IN VARCHAR2 DEFAULT NULL
                                     );

END PK_UTILITIES; 

/
--------------------------------------------------------
--  DDL for Package PK_UTILITIES_4
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_UTILITIES_4" 
AS
    PROCEDURE pr_log_file_manage (pv_ind    IN VARCHAR2,
                                  pv_dir    IN VARCHAR2,
                                  pv_fname  IN VARCHAR2,
                                  pv_data   IN VARCHAR2 DEFAULT NULL
                                  );

    PROCEDURE PR_CREATE_INDEX (pv_index_type IN VARCHAR2,
                               pv_schema_name IN VARCHAR2,
                               pv_index_name IN VARCHAR2,
                               pv_table_name IN VARCHAR2,
                               pv_column_name IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 DEFAULT NULL,
                               pv_log_file_name IN VARCHAR2 DEFAULT NULL
                               );

    PROCEDURE PR_DROP_INDEX (pv_schema_name IN VARCHAR2,
                             pv_object_name IN VARCHAR2,
                             pv_file_dir IN VARCHAR2 DEFAULT NULL,
                             pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                             pb_table       IN BOOLEAN DEFAULT TRUE
                             );

    PROCEDURE PR_ANALYZE_TABLE (pn_estimate_percent IN NUMBER,
                                pv_part_name   IN VARCHAR2,
                                pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_REBUILD_INDEX (pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_CREATE_PARTITION ( pv_schema_name IN VARCHAR2,
                                    pv_table_name  IN VARCHAR2,
                                    pn_batchid     IN NUMBER,
                                    pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                    pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                    );
    
    PROCEDURE PR_MAKE_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_table IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_MAKE_PROD_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                            pv_table_name  IN VARCHAR2,
                                            pv_mfi         IN VARCHAR2,
                                            pb_table IN BOOLEAN DEFAULT TRUE,
                                            pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                            pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                          );

    PROCEDURE PR_REBUILD_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_REBUILD_PR_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_mfi     IN VARCHAR2,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DROP_PARTITION 
                                     ( pn_batchid     IN NUMBER,
                                       pn_keep_till   IN NUMBER,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                                       pv_table         IN VARCHAR2 DEFAULT NULL
                                     );

END PK_UTILITIES_4; 

/
--------------------------------------------------------
--  DDL for Package PK_UTILITIES_CNS_BUREAU
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_UTILITIES_CNS_BUREAU" 
AS

--GIREESH
    PROCEDURE pr_log_file_manage (pv_ind    IN VARCHAR2,
                                  pv_dir    IN VARCHAR2,
                                  pv_fname  IN VARCHAR2,
                                  pv_data   IN VARCHAR2 DEFAULT NULL
                                  );

    PROCEDURE PR_CREATE_INDEX (pv_index_type IN VARCHAR2,
                               pv_schema_name IN VARCHAR2,
                               pv_index_name IN VARCHAR2,
                               pv_table_name IN VARCHAR2,
                               pv_column_name IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 DEFAULT NULL,
                               pv_log_file_name IN VARCHAR2 DEFAULT NULL
                               );

    PROCEDURE PR_DROP_INDEX (pv_schema_name IN VARCHAR2,
                             pv_object_name IN VARCHAR2,
                             pv_file_dir IN VARCHAR2 DEFAULT NULL,
                             pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                             pb_table       IN BOOLEAN DEFAULT TRUE
                             );

    PROCEDURE PR_ANALYZE_TABLE (pn_estimate_percent IN NUMBER,
                                pv_part_name   IN VARCHAR2,
                                pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_REBUILD_INDEX (pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_CREATE_PARTITION ( pv_schema_name IN VARCHAR2,
                                    pv_table_name  IN VARCHAR2,
                                    pn_batchid     IN NUMBER,
                                    pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                    pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                    );
    
    PROCEDURE PR_MAKE_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_table IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_MAKE_PROD_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                            pv_table_name  IN VARCHAR2,
                                            pv_mfi         IN VARCHAR2,
                                            pb_table IN BOOLEAN DEFAULT TRUE,
                                            pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                            pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                          );

    PROCEDURE PR_REBUILD_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_REBUILD_PR_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_mfi     IN VARCHAR2,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DROP_PARTITION 
                                     ( pn_batchid     IN NUMBER,
                                       pn_keep_till   IN NUMBER,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                                       pv_table         IN VARCHAR2 DEFAULT NULL
                                     );

END PK_UTILITIES_CNS_BUREAU; 

/
--------------------------------------------------------
--  DDL for Package PK_UTILITIES_GIR
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_UTILITIES_GIR" 
AS

--GIREESH
    PROCEDURE pr_log_file_manage (pv_ind    IN VARCHAR2,
                                  pv_dir    IN VARCHAR2,
                                  pv_fname  IN VARCHAR2,
                                  pv_data   IN VARCHAR2 DEFAULT NULL
                                  );

    PROCEDURE PR_CREATE_INDEX (pv_index_type IN VARCHAR2,
                               pv_schema_name IN VARCHAR2,
                               pv_index_name IN VARCHAR2,
                               pv_table_name IN VARCHAR2,
                               pv_column_name IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 DEFAULT NULL,
                               pv_log_file_name IN VARCHAR2 DEFAULT NULL
                               );

    PROCEDURE PR_DROP_INDEX (pv_schema_name IN VARCHAR2,
                             pv_object_name IN VARCHAR2,
                             pv_file_dir IN VARCHAR2 DEFAULT NULL,
                             pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                             pb_table       IN BOOLEAN DEFAULT TRUE
                             );

    PROCEDURE PR_ANALYZE_TABLE (pn_estimate_percent IN NUMBER,
                                pv_part_name   IN VARCHAR2,
                                pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_REBUILD_INDEX (pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_CREATE_PARTITION ( pv_schema_name IN VARCHAR2,
                                    pv_table_name  IN VARCHAR2,
                                    pn_batchid     IN NUMBER,
                                    pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                    pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                    );
    
    PROCEDURE PR_MAKE_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_table IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_MAKE_PROD_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                            pv_table_name  IN VARCHAR2,
                                            pv_mfi         IN VARCHAR2,
                                            pb_table IN BOOLEAN DEFAULT TRUE,
                                            pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                            pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                          );

    PROCEDURE PR_REBUILD_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_REBUILD_PR_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_mfi     IN VARCHAR2,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DROP_PARTITION 
                                     ( pn_batchid     IN NUMBER,
                                       pn_keep_till   IN NUMBER,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                                       pv_table         IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DL_SEND_EMAIL(
                                                pv_subject IN VARCHAR2,
                                                pv_message IN VARCHAR2,
                                                pv_from IN VARCHAR2,
                                                pv_to   IN VARCHAR2,
                                                pv_cc   IN VARCHAR2,
                                                pv_bcc  IN VARCHAR2,
                                                pv_file_dir IN VARCHAR2,
                                                pv_log_file_name IN VARCHAR2
                                               );
    PROCEDURE PR_START_JOB (pv_jobs_sqls      IN VARCHAR2,
                            pv_file_dir       IN VARCHAR2,
                            pv_log_file_name  IN VARCHAR2
                           );
    PROCEDURE PR_PARTITION (pv_partition_type IN VARCHAR2,  
                            pv_table_name     IN VARCHAR2,
                            pv_part_name      IN VARCHAR2,
                            pv_values         IN NUMBER DEFAULT NULL,
                            pv_file_dir       IN VARCHAR2 DEFAULT NULL,
                            pv_log_file_name  IN VARCHAR2 DEFAULT NULL
                           );                        
END PK_UTILITIES_GIR; 

/
--------------------------------------------------------
--  DDL for Package PK_UTILITIES_ROBOT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "HMCORE"."PK_UTILITIES_ROBOT" 
AS

--GIREESH
    PROCEDURE pr_log_file_manage (pv_ind    IN VARCHAR2,
                                  pv_dir    IN VARCHAR2,
                                  pv_fname  IN VARCHAR2,
                                  pv_data   IN VARCHAR2 DEFAULT NULL
                                  );

    PROCEDURE PR_CREATE_INDEX (pv_index_type IN VARCHAR2,
                               pv_schema_name IN VARCHAR2,
                               pv_index_name IN VARCHAR2,
                               pv_table_name IN VARCHAR2,
                               pv_column_name IN VARCHAR2,
                               pv_file_dir IN VARCHAR2 DEFAULT NULL,
                               pv_log_file_name IN VARCHAR2 DEFAULT NULL
                               );

    PROCEDURE PR_DROP_INDEX (pv_schema_name IN VARCHAR2,
                             pv_object_name IN VARCHAR2,
                             pv_file_dir IN VARCHAR2 DEFAULT NULL,
                             pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                             pb_table       IN BOOLEAN DEFAULT TRUE
                             );

    PROCEDURE PR_ANALYZE_TABLE (pn_estimate_percent IN NUMBER,
                                pv_part_name   IN VARCHAR2,
                                pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pn_parallel_degree NUMBER DEFAULT 1000,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL                                                                 
                                );

    PROCEDURE PR_REBUILD_INDEX (pv_schema_name IN VARCHAR2,
                                pv_table_name  IN VARCHAR2,
                                pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                );

    PROCEDURE PR_CREATE_PARTITION ( pv_schema_name IN VARCHAR2,
                                    pv_table_name  IN VARCHAR2,
                                    pn_batchid     IN NUMBER,
                                    pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                    pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                    );
    
    PROCEDURE PR_MAKE_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pn_batchid     IN NUMBER,
                                       pb_table IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_MAKE_PROD_INDEX_UNUSABLE ( pv_schema_name IN VARCHAR2,
                                            pv_table_name  IN VARCHAR2,
                                            pv_mfi         IN VARCHAR2,
                                            pb_table IN BOOLEAN DEFAULT TRUE,
                                            pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                            pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                          );

    PROCEDURE PR_REBUILD_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_REBUILD_PR_INDEX_PARTITION 
                                     ( pv_schema_name IN VARCHAR2,
                                       pv_table_name  IN VARCHAR2,
                                       pv_mfi     IN VARCHAR2,
                                       pb_rebuild_all IN BOOLEAN DEFAULT TRUE,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DROP_PARTITION 
                                     ( pn_batchid     IN NUMBER,
                                       pn_keep_till   IN NUMBER,
                                       pv_file_dir IN VARCHAR2 DEFAULT NULL,
                                       pv_log_file_name IN VARCHAR2 DEFAULT NULL,
                                       pv_table         IN VARCHAR2 DEFAULT NULL
                                     );

    PROCEDURE PR_DL_SEND_EMAIL(
                                                pv_subject IN VARCHAR2,
                                                pv_message IN VARCHAR2,
                                                pv_from IN VARCHAR2,
                                                pv_to   IN VARCHAR2,
                                                pv_cc   IN VARCHAR2,
                                                pv_bcc  IN VARCHAR2,
                                                pv_file_dir IN VARCHAR2,
                                                pv_log_file_name IN VARCHAR2
                                               );
    PROCEDURE PR_START_JOB (pv_jobs_sqls      IN VARCHAR2,
                            pv_file_dir       IN VARCHAR2,
                            pv_log_file_name  IN VARCHAR2
                           );
    PROCEDURE PR_PARTITION (pv_partition_type IN VARCHAR2,  
                            pv_table_name     IN VARCHAR2,
                            pv_part_name      IN VARCHAR2,
                            pv_values         IN NUMBER DEFAULT NULL,
                            pv_file_dir       IN VARCHAR2 DEFAULT NULL,
                            pv_log_file_name  IN VARCHAR2 DEFAULT NULL
                           );                        
END PK_UTILITIES_robot; 

/
