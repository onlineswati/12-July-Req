--------------------------------------------------------
--  File created - Wednesday-July-12-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Synonymn DELETE_USER4
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."DELETE_USER4" FOR "HMRACPROD"."DELETE_USER4";
--------------------------------------------------------
--  DDL for Synonymn HM_ACT_CNS
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."HM_ACT_CNS" FOR "HMRACPROD"."HM_ACT_CNS";
--------------------------------------------------------
--  DDL for Synonymn HM_INQ_REPORT_ALL_CONTRI_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."HM_INQ_REPORT_ALL_CONTRI_LOG" FOR "HMRACSTAGE"."HM_INQ_REPORT_ALL_CONTRI_LOG";
--------------------------------------------------------
--  DDL for Synonymn HM_INQ_REPORT_BATCH_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."HM_INQ_REPORT_BATCH_LOG" FOR "HMRACSTAGE"."HM_INQ_REPORT_BATCH_LOG";
--------------------------------------------------------
--  DDL for Synonymn HM_MFI_ACCOUNT
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."HM_MFI_ACCOUNT" FOR "HMRACPROD"."HM_MFI_ACCOUNT";
--------------------------------------------------------
--  DDL for Synonymn HM_MFI_ACCOUNT_GL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."HM_MFI_ACCOUNT_GL" FOR "HMRACPROD"."HM_MFI_ACCOUNT_GL";
--------------------------------------------------------
--  DDL for Synonymn HM_SYS_USER_ROLES_AUDIT_LOG
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."HM_SYS_USER_ROLES_AUDIT_LOG" FOR "HMRACPROD"."HM_SYS_USER_ROLES_AUDIT_LOG";
--------------------------------------------------------
--  DDL for Synonymn PROF_LOG_KEY_SEQ
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."PROF_LOG_KEY_SEQ" FOR "HMRACSTAGE"."PROF_LOG_KEY_SEQ";
--------------------------------------------------------
--  DDL for Synonymn UTL_MAIL
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."UTL_MAIL" FOR "SYS"."UTL_MAIL";
--------------------------------------------------------
--  DDL for Synonymn V$SESSION
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."V$SESSION" FOR "SYS"."V_$SESSION";
--------------------------------------------------------
--  DDL for Synonymn V$SQLAREA
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."V$SQLAREA" FOR "SYS"."V_$SQLAREA";
--------------------------------------------------------
--  DDL for Synonymn V$SQL_WORKAREA_ACTIVE
--------------------------------------------------------

  CREATE OR REPLACE SYNONYM "HMCORE"."V$SQL_WORKAREA_ACTIVE" FOR "SYS"."V_$SQL_WORKAREA_ACTIVE";
