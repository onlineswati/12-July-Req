--------------------------------------------------------
--  File created - Wednesday-July-12-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Type GEN_STR_TBL
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."GEN_STR_TBL" IS TABLE OF VARCHAR2(32767); 

/
-- Unable to render TYPE DDL for object HMCORE.SYS_PLSQL_101852_155_1 with DBMS_METADATA attempting internal generator.
CREATE TYPE          SYS_PLSQL_101852_155_1 as object (PN01 VARCHAR2(4000 BYTE),
PN02 VARCHAR2(4000 BYTE),
PN03 VARCHAR2(4000 BYTE),
PN04 VARCHAR2(4000 BYTE),
PN05 VARCHAR2(4000 BYTE),
PN07 VARCHAR2(4000 BYTE),
PN08 VARCHAR2(4000 BYTE),
PN09 VARCHAR2(4000 BYTE),
PN10 VARCHAR2(4000 BYTE),
PN11 VARCHAR2(4000 BYTE),
PN12 VARCHAR2(4000 BYTE),
PN13 VARCHAR2(4000 BYTE),
PA01 VARCHAR2(4000 BYTE),
PA02 VARCHAR2(4000 BYTE),
PA03 VARCHAR2(4000 BYTE),
PA04 VARCHAR2(4000 BYTE),
PA05 VARCHAR2(4000 BYTE),
PA06 VARCHAR2(4000 BYTE),
PA07 VARCHAR2(4000 BYTE),
PI01 VARCHAR2(4000 BYTE),
CUST_ID NUMBER,
APP_ID NUMBER,
MEM_REF_NO VARCHAR2(25 BYTE),
MEM_CODE VARCHAR2(10 BYTE),
INQ_PASSWORD VARCHAR2(5 BYTE),
INQ_PURPOSE NUMBER,
INQ_AMT NUMBER);
-- Unable to render TYPE DDL for object HMCORE.SYS_PLSQL_101852_339_1 with DBMS_METADATA attempting internal generator.
CREATE TYPE          SYS_PLSQL_101852_339_1 as table of "HMCORE"."SYS_PLSQL_101852_155_1";
-- Unable to render TYPE DDL for object HMCORE.SYS_PLSQL_101852_DUMMY_1 with DBMS_METADATA attempting internal generator.
CREATE TYPE          SYS_PLSQL_101852_DUMMY_1 as table of number;
--------------------------------------------------------
--  DDL for Type TYP_KEY_VAL
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_KEY_VAL" AS TABLE OF VARCHAR2(500); 

/
--------------------------------------------------------
--  DDL for Type TYP_NAME_COLL
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_NAME_COLL" is table of TYP_NAME_OBJ ; 

/
--------------------------------------------------------
--  DDL for Type TYP_NAME_OBJ
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_NAME_OBJ" as object 
(PARSE_KEY VARCHAR2(4000),PARSE_VALUE VARCHAR2(4000)); 

/
--------------------------------------------------------
--  DDL for Type TYP_PKG_INQ_CANDIDATES
--------------------------------------------------------

  CREATE OR REPLACE TYPE "HMCORE"."TYP_PKG_INQ_CANDIDATES" AS TABLE OF VARCHAR2(4000); 

/
