--------------------------------------------------------
--  File created - Wednesday-July-12-2017   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for DB Link HMCORE.SCOTT_REMOTE22
--------------------------------------------------------

  CREATE DATABASE LINK "HMCORE.SCOTT_REMOTE22"
   CONNECT TO "HMCORE" IDENTIFIED BY VALUES ':1'
   USING '10.1.1.121';
--------------------------------------------------------
--  DDL for DB Link HMCORE.SCOTT_REMOTE23
--------------------------------------------------------

  CREATE DATABASE LINK "HMCORE.SCOTT_REMOTE23"
   CONNECT TO "HMCORE" IDENTIFIED BY VALUES ':1'
   USING '10.1.1.121:1521';
--------------------------------------------------------
--  DDL for DB Link HMCORE.SCOTT_REMOTE24
--------------------------------------------------------

  CREATE DATABASE LINK "HMCORE.SCOTT_REMOTE24"
   CONNECT TO "SCOTT" IDENTIFIED BY VALUES ':1'
   USING '(DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = CSPDESK0010.ext.crifnet.com)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = XE)
    )
  )';
--------------------------------------------------------
--  DDL for DB Link HMCORE.SCOTT_REMOTE25
--------------------------------------------------------

  CREATE DATABASE LINK "HMCORE.SCOTT_REMOTE25"
   CONNECT TO "SCOTT" IDENTIFIED BY VALUES ':1'
   USING '(DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 10.1.1.121)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = orcl)
    )
  )';
--------------------------------------------------------
--  DDL for DB Link HMCORE.SCOTT_REMOTE26
--------------------------------------------------------

  CREATE DATABASE LINK "HMCORE.SCOTT_REMOTE26"
   CONNECT TO "HMCORE" IDENTIFIED BY VALUES ':1'
   USING '(DESCRIPTION =
    (ADDRESS = (PROTOCOL = TCP)(HOST = 10.1.1.121)(PORT = 1521))
    (CONNECT_DATA =
      (SERVER = DEDICATED)
      (SERVICE_NAME = orcl)
    )
  )';
